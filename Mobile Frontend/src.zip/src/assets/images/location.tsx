import * as React from 'react';
import Svg, {Path} from 'react-native-svg';

const SvgComponent = () => (
  <Svg width={20} height={20} fill="none">
    <Path
      d="M10 1.25a6.883 6.883 0 0 0-6.875 6.875c0 5.882 6.25 10.326 6.516 10.512a.627.627 0 0 0 .717 0c.266-.186 6.517-4.63 6.517-10.512A6.883 6.883 0 0 0 10 1.25Zm0 4.375a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5Z"
      fill="#FF4242"
    />
  </Svg>
);

export default SvgComponent;
