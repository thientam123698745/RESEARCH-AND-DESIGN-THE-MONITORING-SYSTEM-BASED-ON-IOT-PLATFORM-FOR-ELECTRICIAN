import {BottomRouter} from 'src/types/BottomRouter';

export const btRouters: BottomRouter = {
  MAP_COMPONENT: 'MapComponent',
  BOOK_CAR: 'BookCar',
  HOMEPAGE: 'Homepage',
};
