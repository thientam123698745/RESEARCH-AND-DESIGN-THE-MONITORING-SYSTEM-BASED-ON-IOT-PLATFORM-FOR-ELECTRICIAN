export const input_texts = {
  FULL_NAME: 'full_name',
};
