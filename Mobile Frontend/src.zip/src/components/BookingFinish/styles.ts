import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: MetricSizes.P_40,
    borderTopWidth: 1,
    borderColor: colors.grey,
    backgroundColor: colors.white,
    paddingHorizontal: MetricSizes.P_20,
  },
  noticeTitleView: {
    paddingVertical: MetricSizes.P_20,
  },
  finishCloseButtonView: {
    paddingVertical: MetricSizes.P_20,
  },
  finishCloseButton: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  finishAvtImageView: {
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
  },
  finsihAvtImage: {
    width: MetricSizes.P_40 * 2,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  finishFeedbackTitle: {
    paddingVertical: MetricSizes.P_10,
  },
  ratingView: {
    paddingVertical: MetricSizes.P_10,
  },
  feedbackTextInputView: {
    justifyContent: 'center',
    // paddingVertical: MetricSizes.P_10,
    borderBottomWidth: 1,
    borderColor: colors.grey,
  },
  rating: {
    // width: '80%',
  },
  shipmentPriceTextView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    paddingVertical: MetricSizes.P_10,
    marginTop: MetricSizes.P_40,
    borderColor: colors.grey,
  },
});
