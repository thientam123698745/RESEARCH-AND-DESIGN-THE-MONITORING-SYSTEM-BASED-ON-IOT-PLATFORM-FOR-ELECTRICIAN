import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
import TextInput from '@components/common/TextInput/TextInput';
const BookingFinish = () => {
  return (
    <View style={styles.container}>
      <TransStatusBar color="dark-content" />
      <View style={styles.finishCloseButtonView}>
        <Image source={Images.CLOSE_BUTTON} style={styles.finishCloseButton} />
      </View>
      <View style={styles.noticeTitleView}>
        <Text type="regular" color={colors.primary} isCenter>
          shipment_success
        </Text>
        <Text type="small" color={colors.blackText} isCenter>
          request_feedback
        </Text>
      </View>
      <View style={styles.finishAvtImageView}>
        <Image source={Images.USER_ICON} style={styles.finsihAvtImage} />
      </View>
      <View style={styles.finishFeedbackTitle}>
        <Text type="regular" isCenter color={colors.blackText}>
          question_rating_driver
        </Text>
      </View>
      <View style={styles.ratingView}>
        {/* <Rating imageSize={30} style={styles.rating} /> */}
      </View>
      <View style={styles.feedbackTextInputView}>
        <TextInput placeholder="input_rating" />
      </View>
      <View style={styles.shipmentPriceTextView}>
        <Text type="small" color={colors.grey}>
          shipment_fee
        </Text>
        <Text type="small" isBold>
          shipment_fee_value
        </Text>
      </View>
    </View>
  );
};
export default BookingFinish;
