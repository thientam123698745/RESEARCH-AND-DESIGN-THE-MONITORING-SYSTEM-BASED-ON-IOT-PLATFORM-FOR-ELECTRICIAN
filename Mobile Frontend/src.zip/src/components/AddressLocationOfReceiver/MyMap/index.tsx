import {Image, PermissionsAndroid, TouchableOpacity, View} from 'react-native';
import React from 'react';
import MapView, {LatLng, MapEvent, Marker} from 'react-native-maps';
import styles from './style';
import Geolocation from 'react-native-geolocation-service';
import {Images} from '@assets/constants/images';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import useNavigate from '@hooks/useNavigate';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import * as AuthSlice from '@store/auth/shared/slice';
import {selectDisplayLocation} from '@store/bookingTruckOrder/shared/selector';
const MyMap = () => {
  useBookingInjector();
  const navigation = useNavigate();
  const displayAddress = useSelector(selectDisplayLocation);
  const {coord} = displayAddress;
  const {latitude, longitude} = coord;
  const dispatch = useDispatch();
  const INIT_LOCATION = {
    latitude: latitude,
    longitude: longitude,
    latitudeDelta: 0.001,
    longitudeDelta: 0.001,
  };
  function onMapPress(event: MapEvent) {
    const tmpCoord = event.nativeEvent.coordinate;
    dispatch(BookingTruckOrderSlice.actions.setDisplayCoord(tmpCoord));
  }
  async function requestLocationPermission() {
    const granted = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
      {
        title: '365 REQUEST LOCATION PERMISSION',
        message: '365 Truck need access to your location ',
        buttonPositive: '',
      },
    );
    return granted;
  }
  function handleGetCurrentLocation() {
    if (requestLocationPermission()) {
      Geolocation.getCurrentPosition(
        //Will give you the current location
        position => {
          //getting the Longitude from the location json
          const currentLongitude = position.coords.longitude;

          //getting the Latitude from the location json
          const currentLatitude = position.coords.latitude;
          let tmpCoord: LatLng = {latitude: null, longitude: null};
          tmpCoord.latitude = currentLatitude;
          tmpCoord.longitude = currentLongitude;
          setCoord(tmpCoord);
        },
        error => {
          const data = {
            error: error,
            indeX: 2,
          };
          dispatch(AuthSlice.actions.openNotification(data));
        },
        {
          enableHighAccuracy: true,
          timeout: 20000,
          maximumAge: 1000,
        },
      );
    }
  }
  function setCoord(tmpCoord: LatLng) {
    dispatch(BookingTruckOrderSlice.actions.setDisplayCoord(tmpCoord));
  }

  return (
    <View style={styles.container}>
      <MapView
        showsMyLocationButton
        onPress={e => onMapPress(e)}
        style={styles.mapWrapper}
        region={INIT_LOCATION}>
        <Marker coordinate={coord} draggable>
          <View style={styles.markerView}>
            <Image source={Images.LOCATION2} style={styles.markerImage} />
          </View>
        </Marker>
      </MapView>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.returnButton}>
        <Image style={styles.image} source={Images.CARET_RIGHT} />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={handleGetCurrentLocation}
        style={styles.currentButton}>
        <Image style={styles.image} source={Images.YOUR_LOCATION} />
      </TouchableOpacity>
    </View>
  );
};

export default MyMap;
