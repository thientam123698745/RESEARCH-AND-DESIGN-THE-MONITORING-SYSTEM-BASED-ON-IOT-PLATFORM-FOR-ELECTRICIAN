import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import * as BookingTruckOrderSelector from '@store/bookingTruckOrder/shared/selector';
import {routers} from '@assets/constants/routers';
import useNavigate from '@hooks/useNavigate';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyMapInfo = () => {
  useBookingInjector();
  const address = useSelector(BookingTruckOrderSelector.selectDisplayLocation);
  const {shortAddress, detailAddress} = address;
  function handleAddAddress() {
    navigation.navigate(routers.ADDRESS_INFORMATION_OF_RECEIVER);
  }
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <View style={styles.view1}>
        <View style={styles.view1_1}>
          <View style={styles.view3}>
            <Image style={styles.image} source={Images.LOCATION_DOT2} />
          </View>
          <View style={styles.view4}>
            <Text type="small" isBold isCenter={false}>
              {shortAddress ? shortAddress : 'find_in_map.short_address'}
            </Text>
            <Text type="tiny" isCenter={false}>
              {detailAddress ? detailAddress : 'find_in_map.detail_address'}
            </Text>
          </View>
        </View>
      </View>
      <View style={styles.view2}>
        <TouchableOpacity onPress={handleAddAddress} style={styles.button}>
          <Text type="small" isBold color={colors.white}>
            find_in_map.confirm_recipient
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default MyMapInfo;
