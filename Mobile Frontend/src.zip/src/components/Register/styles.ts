import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
    flex: 1,
    paddingHorizontal: MetricSizes.P_20,
  },
  strongText: {
    fontWeight: 'bold',
    color: colors.blackGrey,
    textDecorationLine: 'underline',
  },
});
export default styles;
