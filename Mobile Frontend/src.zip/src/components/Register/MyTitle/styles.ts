import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  title: {
    flex: 1,
    // justifyContent: 'center',
    // borderWidth: 1,
    paddingBottom: MetricSizes.P_20,
  },

  titleText: {
    textAlign: 'center',
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_24,
    fontWeight: 'bold',
  },
});
export default styles;
