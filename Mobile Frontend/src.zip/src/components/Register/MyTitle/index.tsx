import {View} from 'react-native';
import React from 'react';
import styles from './styles';
import Text from '@components/common/Texts/Text';
const MyTitle = () => {
  return (
    <View style={styles.title}>
      <Text type="regular" isCenter>
        sign_up.title
      </Text>
      <Text type="small" isCenter>
        sign_up.content
      </Text>
    </View>
  );
};

export default MyTitle;
