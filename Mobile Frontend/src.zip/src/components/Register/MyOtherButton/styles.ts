import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  OtherWrapper: {
    flex: 2,
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '100%',
  },

  otherAccountItemsWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '50%',
  },

  icon: {},
});
export default styles;
