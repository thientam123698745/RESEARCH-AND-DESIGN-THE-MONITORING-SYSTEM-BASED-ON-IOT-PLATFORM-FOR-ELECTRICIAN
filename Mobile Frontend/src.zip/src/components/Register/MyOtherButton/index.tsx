import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import styles from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const MyOtherButton = () => {
  return (
    <View style={styles.OtherWrapper}>
      <Text isCenter type="tiny">
        sign_up.notice
      </Text>
      <Text color={colors.grey} type="small">
        sign_up.sign_up_button
      </Text>
      <View style={styles.otherAccountItemsWrapper}>
        <TouchableOpacity>
          <Image style={styles.icon} source={Images.FACEBOOK} />
        </TouchableOpacity>
        <TouchableOpacity>
          <Image style={styles.icon} source={Images.GOOGLE} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity>
        <Text type="small" color={colors.primary}>
          sign_up.login_button
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default MyOtherButton;
