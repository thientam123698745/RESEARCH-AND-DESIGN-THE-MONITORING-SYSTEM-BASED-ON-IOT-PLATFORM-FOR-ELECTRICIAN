import {View} from 'react-native';
import React, {useEffect} from 'react';
import styles from './styles';
import {useForm} from 'react-hook-form';
import {useDispatch, useSelector} from 'react-redux';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import * as AuthSelector from '@store/auth/shared/selector';
import {AuthSaga} from '@store/auth/shared/saga';
import Input from '@components/common/Input';
import {REGEX_LIST} from '@assets/constants';
import {error_sign_up_code} from '@assets/constants/error_msg';
import {useTranslation} from 'react-i18next';
import Button from '@components/common/Button/Button';
const NUMBER_OF_VALUE = 4;
const MySignUpFormWrapper = () => {
  const {t} = useTranslation();
  const {control, setError, handleSubmit, formState} = useForm();
  const dispatch = useDispatch();
  const error = useSelector(AuthSelector.selectSignUpError);

  useEffect(() => {
    if (error) {
      const message = error.message;
      if (message === error_sign_up_code.DUPLICATE_PHONE + '') {
        setError('phone_number', {
          type: 'exist',
          message: t('error.duplicate_phone'),
        });
      }
      if (message === error_sign_up_code.DUPLICATE_USERNAME + '') {
        setError('user_name', {
          type: 'exist',
          message: t('error.duplicate_username'),
        });
      }
    }
  }, [error, setError, t]);

  const handleSignUpClick = (data: any) => {
    if (data !== undefined) {
      dispatch(AuthSlice.actions.checkUser(data));
    }
  };
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_VALUE;
  return (
    <View style={styles.formWrapper}>
      <Input
        name="full_name"
        label={t('placeholder.fullname')}
        control={control}
        isPassword={false}
        errMsg={t('error.full_name')}
        rules={{
          required: true,
          minLength: 8,
          pattern: REGEX_LIST.FULL_NAME,
        }}
      />
      <Input
        name="phone_number"
        label={t('placeholder.phone_number')}
        control={control}
        isPassword={false}
        errMsg={t('error.phone_number')}
        rules={{
          required: true,
          minLength: 10,
          pattern: REGEX_LIST.PHONE,
        }}
      />
      <Input
        name="user_name"
        label={t('placeholder.email')}
        control={control}
        isPassword={false}
        errMsg={t('error.email')}
        rules={{
          required: true,
          minLength: 8,
          pattern: REGEX_LIST.EMAIL,
        }}
      />
      <Input
        name="password"
        control={control}
        label={t('placeholder.password')}
        isPassword={true}
        errMsg={t('error.password')}
        rules={{
          required: true,
          minLength: 8,
          maxLength: 16,
          pattern: REGEX_LIST.PASSWORD,
        }}
      />
      <Button
        disabled={countAtt}
        type="solid"
        onPress={handleSubmit(handleSignUpClick)}>
        button.sign_up
      </Button>
    </View>
  );
};

export default MySignUpFormWrapper;
