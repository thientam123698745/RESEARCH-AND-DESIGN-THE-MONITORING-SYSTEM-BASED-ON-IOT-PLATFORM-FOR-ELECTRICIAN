import React, {useEffect} from 'react';
import styles from './styles';
import MyOtherButton from './MyOtherButton';
import MyTitle from './MyTitle';
import {useSelector} from 'react-redux';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import {AuthSaga} from '@store/auth/shared/saga';
import * as AuthSelector from '@store/auth/shared/selector';
import {SafeAreaView} from 'react-native-safe-area-context';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {routers} from '@assets/constants/routers';
import LoadingPage from '@components/common/LoadingPage';
import MySignUpFormWrapper from './MySignUpFormWrapper';
const Register = () => {
  const navigation = useNavigate();
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const reg_user = useSelector(AuthSelector.selectRegisterUser);
  const loading = useSelector(AuthSelector.selectLoading);
  useEffect(() => {
    if (reg_user.full_name) {
      navigation.navigate(routers.OTP_PAGE);
    }
  }, [reg_user, navigation]);

  return loading ? (
    <LoadingPage message="" />
  ) : (
    <SafeAreaView style={styles.container}>
      <TransStatusBar />
      <MyTitle />
      <MySignUpFormWrapper />
      <MyOtherButton />
    </SafeAreaView>
  );
};

export default Register;
