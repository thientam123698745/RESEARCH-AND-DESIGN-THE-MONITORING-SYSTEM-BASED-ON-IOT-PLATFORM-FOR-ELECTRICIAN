import {View} from 'react-native';
import React from 'react';
import styles from './style';
import MyMap from './MyMap';
import MyMapInfo from './MyMapInfo';
const AddressLocationOfSender = () => {
  return (
    <View style={styles.container}>
      <MyMap />
      <MyMapInfo />
    </View>
  );
};

export default AddressLocationOfSender;
