import {View, ScrollView} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import BookingShipmentDetailCode from '@components/BookingShipmentDetail/BookingShipmentDetailCode/BookingShipmentDetailCode';
import BookingShipmentDetailAddress from '@components/BookingShipmentDetail/BookingShipmentDetailAddress/BookingShipmentDetailAddress';
import BookingShipmentDetailInfo from '@components/BookingShipmentDetail/BookingShipmentDetailInfo/BookingShipmentDetailInfo';
import BookingShipmentDetailTrucks from '@components/BookingShipmentDetail/BookingShipmentDetailTrucks/BookingShipmentDetailTrucks';
import BookingShipmentDetailPayment from '@components/BookingShipmentDetail/BookingShipmentDetailPayment/BookingShipmentDetailPayment';
const BookingShipmentDetail = () => {
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <ScrollView>
        <MediumLogoHeader text="Thông Tin Đơn Hàng" navigation={navigation} />
        <BookingShipmentDetailCode />
        <BookingShipmentDetailAddress />
        <BookingShipmentDetailInfo />
        <BookingShipmentDetailTrucks />
        <BookingShipmentDetailPayment />
      </ScrollView>
    </View>
  );
};
export default BookingShipmentDetail;
