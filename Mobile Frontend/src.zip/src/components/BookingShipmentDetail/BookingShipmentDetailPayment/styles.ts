import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // alignItems: 'center',
    // borderWidth: 1,
    padding: MetricSizes.P_20,
  },
  titleView: {
    paddingVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
  },
  codeTextView: {
    flexGrow: 1,
    paddingHorizontal: MetricSizes.P_10,
  },
  codeImageView: {
    // justifyContent: 'center',
    alignItems: 'center',
  },
  codeImage: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  view: {
    marginTop: MetricSizes.P_10,
    backgroundColor: colors.white,
  },
});
