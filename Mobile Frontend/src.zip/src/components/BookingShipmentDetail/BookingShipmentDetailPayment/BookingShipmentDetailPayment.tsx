import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const BookingShipmentDetailPayment = () => {
  return (
    <View style={styles.view}>
      <View style={styles.titleView}>
        <Text type="regular" color={colors.blackText}>
          payment_method
        </Text>
      </View>
      <View style={styles.container}>
        <View style={styles.codeImageView}>
          <Image source={Images.ORDER_HEADER} style={styles.codeImage} />
        </View>
        <View style={styles.codeTextView}>
          <Text type="small" isBold color={colors.blackText}>
            shipment_code
          </Text>
          <Text type="small" color={colors.blackText}>
            shipment_date
          </Text>
          <Text type="tiny" isBold color={colors.blackText}>
            is_shipping
          </Text>
        </View>
        <TouchableOpacity style={styles.codeImageView}>
          <Image source={Images.COPY_CODE} style={styles.codeImage} />
        </TouchableOpacity>
      </View>
    </View>
  );
};
export default BookingShipmentDetailPayment;
