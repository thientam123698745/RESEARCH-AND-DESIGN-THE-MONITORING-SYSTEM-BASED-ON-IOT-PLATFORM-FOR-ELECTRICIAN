import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const BookingShipmentDetailTrucks = () => {
  return (
    <View style={styles.view}>
      <View style={styles.titleView}>
        <Text type="regular" color={colors.blackText}>
          transport
        </Text>
      </View>
      <View style={styles.container}>
        <View style={styles.codeImageView}>
          <Image source={Images.TRUCK_TYPE} style={styles.codeImage} />
        </View>
        <View style={styles.codeTextView}>
          <Text type="small" isBold color={colors.blackText}>
            shipping_truck
          </Text>
          <Text type="small" color={colors.grey}>
            shipping_truck_detail
          </Text>
        </View>
      </View>
    </View>
  );
};
export default BookingShipmentDetailTrucks;
