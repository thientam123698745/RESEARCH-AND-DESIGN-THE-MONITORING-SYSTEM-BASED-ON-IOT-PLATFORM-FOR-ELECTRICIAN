import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const BookingShipmentDetailAddress = () => {
  return (
    <View style={styles.view}>
      <View style={styles.container}>
        <View style={styles.codeImageView}>
          <Image source={Images.LOCATION_DOT2} style={styles.codeImage} />
        </View>
        <View style={styles.codeTextView}>
          <Text type="small" isBold color={colors.blackText}>
            sender_information
          </Text>
          <Text type="small" isBold color={colors.blackText}>
            customer_name
          </Text>
          <Text type="small" color={colors.blackText}>
            phone_number
          </Text>
          <Text type="tiny" color={colors.blackText}>
            address
          </Text>
        </View>
      </View>
    </View>
  );
};
export default BookingShipmentDetailAddress;
