import {View} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';
import Input from '@components/common/Input';
import {REGEX_LIST} from '@assets/constants';
import {useForm} from 'react-hook-form';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import * as ProfileSelector from '@store/profile/shared/selector';
import * as ProfileSlice from '@store/profile/shared/slice';
import {useDispatch, useSelector} from 'react-redux';
import LoadingPage from '@components/common/LoadingPage';
import Button from '@components/common/Button/Button';
import Text from '@components/common/Texts/Text';
const NUMBER_OF_TEXT_INPUT = 1;
const ChangeNickname = () => {
  useProfileInjector();
  const {control, handleSubmit, formState} = useForm();
  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_TEXT_INPUT;
  const nickName = useSelector(ProfileSelector.selectNickName);
  const phone = useSelector(ProfileSelector.selectPhone);
  const loading = useSelector(ProfileSelector.selectLoading);
  const dispatch = useDispatch();
  const handleSave = (data: any) => {
    const requestData = {
      phone_number: phone,
      nick_name_new: data.nickname,
    };

    dispatch(ProfileSlice.actions.changeNickName(requestData));
  };

  const navigation = useNavigate();
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="NICKNAME" />
      <View style={styles.body}>
        <Text type="small" color={colors.blackText} isBold>
          nick_name
        </Text>
        <Text type="small" color={colors.blackText}>
          error.nickname
        </Text>
        <View style={styles.pad}>
          <Input
            control={control}
            label="placeholder.nickname"
            input_value={nickName}
            rules={{
              required: true,
              minLength: 6,
              pattern: REGEX_LIST.NICKNAME,
            }}
            name="placeholder.nickname"
            errMsg="error.nickname"
          />
        </View>
        <Button
          type="solid"
          disabled={countAtt}
          onPress={handleSubmit(handleSave)}>
          button.save_changes
        </Button>
      </View>
    </View>
  );
};

export default ChangeNickname;
