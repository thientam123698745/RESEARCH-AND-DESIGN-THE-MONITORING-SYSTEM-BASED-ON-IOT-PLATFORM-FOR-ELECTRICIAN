import React, {useState} from 'react';
import {TextInput, View} from 'react-native';
import {colors} from '@assets/colors';
import styles from './styles';
import {REGEX_LIST} from '@assets/constants';
import * as ProfileSlice from '@store/profile/shared/slice';
import {ProfileSaga} from '@store/profile/shared/saga';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import {useTranslation} from 'react-i18next';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const ForgotPasswordPage = () => {
  const {t} = useTranslation();
  const [phone, setPhone] = useState();
  const [errorText, setErrorText] = useState('');
  const [isValid, setValid] = useState(false);
  useInjectReducer({
    key: ProfileSlice.sliceKey,
    reducer: ProfileSlice.reducer,
  });
  useInjectSaga({
    key: ProfileSlice.sliceKey,
    saga: ProfileSaga,
  });
  const validPhone = (tmp_phone: string) => {
    var re = REGEX_LIST.PHONE;

    return re.test(tmp_phone);
  };
  const handleSubmit = () => {
    if (isValid) {
    }
  };
  const handleOnChange = (text: any) => {
    setPhone(text);
    const isCorrect = validPhone(text);
    if (isCorrect) {
      setValid(true);
      setErrorText('');
    } else {
      setValid(false);
      setErrorText(t('error.phone_number'));
    }
  };
  return (
    <View style={styles.container}>
      <Text type="regular" isCenter>
        placeholder.phone_number
      </Text>
      <View style={styles.notice}>
        <Text isCenter type="small">
          otp.text
        </Text>
      </View>
      <View style={styles.wrapper}>
        <View style={styles.codeWrapper}>
          <Text type="small" style={styles.text}>
            placeholder.phone_head
          </Text>
        </View>
        <TextInput
          onChangeText={handleOnChange}
          value={phone}
          keyboardType="numeric"
          style={styles.input}
          placeholder={t('placeholder.phone_number')}
        />
      </View>
      <Text type="small" color={colors.red}>
        {errorText}
      </Text>
      <View style={styles.btnWrapper}>
        <Button type="solid" disabled={!isValid} onPress={handleSubmit}>
          button.get_password_back
        </Button>
      </View>
      <View style={styles.notice}>
        <Text type="small" isCenter>
          forgot_password.notice
        </Text>
      </View>
    </View>
  );
};

export default ForgotPasswordPage;
