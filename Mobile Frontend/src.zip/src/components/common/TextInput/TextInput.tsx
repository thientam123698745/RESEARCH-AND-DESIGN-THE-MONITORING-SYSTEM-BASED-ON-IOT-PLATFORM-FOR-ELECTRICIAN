import {TextInputProps, TextInput as RNTextInput} from 'react-native';
import React from 'react';
import {useTranslation} from 'react-i18next';
interface Props extends TextInputProps {
  placeholder: any;
  option?: any;
}
const TextInput = ({placeholder, option, ...props}: Props) => {
  const {t} = useTranslation();
  return <RNTextInput placeholder={t(placeholder, option)} {...props} />;
};
export default TextInput;
