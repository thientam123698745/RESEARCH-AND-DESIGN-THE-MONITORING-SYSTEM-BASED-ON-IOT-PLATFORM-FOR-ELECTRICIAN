import {View, ActivityIndicator} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const LoadingPage = ({message}: {message: string}) => {
  return (
    <View style={styles.container}>
      <ActivityIndicator size={'large'} color={colors.blackText} />
      <Text type="regular">{message}</Text>
    </View>
  );
};

export default LoadingPage;
