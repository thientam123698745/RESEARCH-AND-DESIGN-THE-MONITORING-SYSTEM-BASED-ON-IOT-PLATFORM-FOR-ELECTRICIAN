import {fonts, fontSize} from 'assets/fonts';
import MetricSizes from 'assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    marginTop: MetricSizes.P_10,
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_16,
  },
});
