import React from 'react';
import DatePicker from 'react-native-date-picker';
const Input = ({
  setOpen,
  setDate,
  open,
  date,
}: {
  name: any;
  control: any;
  rules: any;
  input_value?: string;
  setOpen: any;
  setDate: any;
  open: any;
  date: any;
}) => {
  const handleOnConfirm = (tmpDate: any) => {
    setOpen(false);
    setDate(tmpDate);
  };
  const handleOnCancel = () => {
    setOpen(false);
  };
  return (
    <DatePicker
      modal
      open={open}
      mode="date"
      date={date}
      onConfirm={handleOnConfirm}
      onCancel={handleOnCancel}
    />
  );
};

export default Input;
