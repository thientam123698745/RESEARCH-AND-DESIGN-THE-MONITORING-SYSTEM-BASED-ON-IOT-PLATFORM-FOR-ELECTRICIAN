import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    // marginVertical: MetricSizes.P_10,
  },
  textInput: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.borderGray,
    backgroundColor: colors.greyLine,
    paddingHorizontal: MetricSizes.P_10 * 1.5,
    // width: 20,
    // height: WINDOW_HEIGHT * 0.07,
    // fontSize: fontSize.FS_10 * 1.3,
  },
});
