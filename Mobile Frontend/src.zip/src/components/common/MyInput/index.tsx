import React from 'react';
import {TextInput} from 'react-native-paper';
import {colors} from 'assets/colors';

const MyInput = ({
  label,
  register,
  required,
}: {
  label: any;
  register: any;
  required: any;
}) => (
  <>
    <TextInput
      activeUnderlineColor={colors.blackText}
      activeOutlineColor={colors.white}
      mode="flat"
      label={label}
      {...register(label, {required})}
    />
  </>
);

export default MyInput;
