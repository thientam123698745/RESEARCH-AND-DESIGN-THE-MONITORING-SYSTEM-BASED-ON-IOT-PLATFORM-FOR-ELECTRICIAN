import {WINDOW_HEIGHT, WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  imageItemSlideshow: {
    width: '100%',
    height: '100%',
    resizeMode: 'stretch',
  },
  paginationContainer: {
    zIndex: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideShowWrapper: {},
  paginationDot: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_10 * 0.3,
    // marginHorizontal: -20,
  },
  inactiveDot: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10 * 0.3,
    marginHorizontal: -MetricSizes.P_40,
  },
  touchableWrapper: {
    width: '100%',
    height: '100%',
    borderRadius: MetricSizes.small,
  },
  paginationWrapper: {
    width: WINDOW_WIDTH,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2,
    position: 'absolute',
    top: WINDOW_HEIGHT * 0.14,
  },
  imageButton: {
    height: undefined,
    width: WINDOW_WIDTH - MetricSizes.P_10 * 2,
    aspectRatio: 326 / 120,
  },
  carouselWrapper: {
    marginVertical: MetricSizes.P_20,
  },
});

export default styles;
