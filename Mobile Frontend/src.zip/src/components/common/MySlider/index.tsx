import Carousel, {Pagination} from 'react-native-snap-carousel';
import {ImageBackground, View} from 'react-native';
import React, {useState} from 'react';

import {colors} from '@assets/colors';
import styles from './styles';
import {WINDOW_WIDTH} from '@assets/constants';
import {TouchableRipple} from 'react-native-paper';
import MetricSizes from '@assets/constants/MetricSizes';

const SLIDER_1_FIRST_ITEM = 1;
const MySlider = ({data}: {data: any}) => {
  const handleVoucher = () => {};
  const [images] = useState(data);
  const _renderItem = ({item}: {item: any}) => {
    return (
      <ImageBackground
        source={item}
        style={styles.imageButton}
        imageStyle={styles.imageItemSlideshow}>
        <TouchableRipple
          borderless
          rippleColor={colors.white}
          onPress={handleVoucher}
          style={styles.touchableWrapper}>
          <></>
        </TouchableRipple>
      </ImageBackground>
    );
  };
  const [Slideshow, setSlideshow] = useState(SLIDER_1_FIRST_ITEM);
  return (
    <View style={styles.slideShowWrapper}>
      <Carousel
        data={images}
        renderItem={_renderItem}
        sliderWidth={WINDOW_WIDTH}
        itemWidth={WINDOW_WIDTH - MetricSizes.P_10 * 2}
        containerCustomStyle={styles.carouselWrapper}
        inactiveSlideOpacity={0.5}
        loop={true}
        loopClonesPerSide={2}
        // autoplay={true}
        // autoplayDelay={500}
        // autoplayInterval={2000}
        layout={'default'}
        onSnapToItem={index => setSlideshow(index)}
        firstItem={SLIDER_1_FIRST_ITEM}
        inactiveSlideScale={2}
      />
      <View style={styles.paginationWrapper}>
        <Pagination
          dotsLength={images.length}
          activeDotIndex={Slideshow}
          containerStyle={styles.paginationContainer}
          dotColor={colors.white}
          dotStyle={styles.paginationDot}
          inactiveDotColor={colors.grey}
          inactiveDotOpacity={0.5}
          inactiveDotScale={0.6}
          inactiveDotStyle={styles.inactiveDot}
        />
      </View>
    </View>
  );
};

export default MySlider;
