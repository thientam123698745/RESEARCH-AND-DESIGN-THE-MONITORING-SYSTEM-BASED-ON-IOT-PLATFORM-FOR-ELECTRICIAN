import {Image, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';
import {Images} from '@assets/constants/images';

import {RouterParamList} from 'src/types/RouterParamList';
type routerProps = NativeStackNavigationProp<RouterParamList>;
const LogoHeader = () => {
  const navigation = useNavigation<routerProps>();
  const handleReturn = () => {
    navigation.goBack();
  };
  return (
    <View style={styles.container}>
      <Image source={Images.LOGO} style={styles.logo} />
      <TouchableOpacity onPress={handleReturn} style={styles.return}>
        <Image style={styles.image} source={Images.CARET_RIGHT} />
      </TouchableOpacity>
    </View>
  );
};

export default LogoHeader;
