import {WINDOW_WIDTH} from 'assets/constants';
import MetricSizes from 'assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    width: WINDOW_WIDTH,
    flexDirection: 'row',
  },
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  return: {
    position: 'absolute',
    left: MetricSizes.P_20,
  },
  logo: {
    width: '40%',
    height: undefined,
    aspectRatio: 6 / 1,
    resizeMode: 'stretch',
  },
});
