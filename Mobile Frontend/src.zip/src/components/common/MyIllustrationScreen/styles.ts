import {StyleSheet} from 'react-native';
import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {WINDOW_WIDTH} from 'assets/constants';

export const styles = StyleSheet.create({
  pageItem: {
    borderRadius: 10,
    margin: MetricSizes.P_10 / 2,
    backgroundColor: colors.grey,
    flex: 1,
  },
  pageMainItem: {
    borderRadius: 10,
    margin: MetricSizes.P_10 / 2,
    backgroundColor: colors.primary,
    flex: 3,
  },
  paginationWrapper: {
    height: '10%',
    width: '30%',
    position: 'absolute',
    top: MetricSizes.P_10,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  splashScreensButtonContainer: {
    flex: 1,
    alignSelf: 'center',
    flexDirection: 'column',
    width: WINDOW_WIDTH,
    paddingHorizontal: MetricSizes.P_20,
    justifyContent: 'space-around',
    backgroundColor: colors.white,
  },
  paginationInactiveDot: {
    width: MetricSizes.P_20 * 0.4,
  },
  paginationDot: {
    width: MetricSizes.P_20 * 1.5,
  },

  paginationContainer: {
    alignSelf: 'center',
    position: 'absolute',
    top: '40%',
  },
  slideshowContainer: {
    // height: WINDOW_HEIGHT * 0.7,
    // borderWidth: 1,
  },
  slideItemWrapper: {
    height: '100%',
    backgroundColor: colors.violet,
  },
  slideItemImage: {
    width: WINDOW_WIDTH,
    // resizeMode: 'cover',
    flex: 2,
  },
  slideItemTextWrapper: {
    flex: 2,
    // height: '30%',
    paddingTop: '20%',
    backgroundColor: colors.white,
    flexGrow: 1,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    alignItems: 'center',
    paddingHorizontal: MetricSizes.P_20,
    textAlign: 'center',
  },
});
