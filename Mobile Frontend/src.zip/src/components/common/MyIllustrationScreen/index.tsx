import {Image, Text, View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import PaginationBarWrapper from './PaginationBarWrapper';
import ButtonPageWrapper from './ButtonPage';
const MyIllustrationScreen = ({
  data,
  navigation,
  pageIndex,
}: {
  data: any;
  navigation: any;
  pageIndex: number;
}) => {
  return (
    <View style={styles.slideItemWrapper}>
      <Image style={styles.slideItemImage} source={data[pageIndex].image} />
      <View style={styles.slideItemTextWrapper}>
        <PaginationBarWrapper />
        <Text>{data[pageIndex].title}</Text>
        <Text>{data[pageIndex].content}</Text>
      </View>
      <ButtonPageWrapper pageIndex={pageIndex} navigation={navigation} />
    </View>
  );
};

export default MyIllustrationScreen;
