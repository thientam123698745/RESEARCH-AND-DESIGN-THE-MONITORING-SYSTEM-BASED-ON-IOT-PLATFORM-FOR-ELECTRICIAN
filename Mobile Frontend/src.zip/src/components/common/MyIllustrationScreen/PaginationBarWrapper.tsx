import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';

const PaginationBarWrapper = () => {
  return (
    <View style={styles.paginationWrapper}>
      <View style={styles.pageMainItem} />
      <View style={styles.pageItem} />
      <View style={styles.pageItem} />
    </View>
  );
};

export default PaginationBarWrapper;
