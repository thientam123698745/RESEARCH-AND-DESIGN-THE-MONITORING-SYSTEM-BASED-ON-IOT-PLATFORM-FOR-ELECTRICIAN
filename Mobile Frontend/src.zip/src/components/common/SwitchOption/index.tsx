import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Switch} from 'react-native-paper';
import Text from '@components/common/Texts/Text';
const SwitchOption = ({
  index,
  text,
  note,
}: {
  index?: any;
  text: string;
  note?: string;
}) => {
  const [isSwitchOn, setIsSwitchOn] = React.useState(false);

  const onToggleSwitch = () => setIsSwitchOn(!isSwitchOn);

  return (
    <View style={styles.container} key={index}>
      <View>
        <Text type="small" isBold color={colors.blackText}>
          {text}
        </Text>
        {note ? (
          <Text type="tiny" color={colors.grey}>
            {note}
          </Text>
        ) : (
          <></>
        )}
      </View>
      <View style={styles.swtWrapper}>
        <Switch value={isSwitchOn} onValueChange={onToggleSwitch} />
      </View>
    </View>
  );
};

export default SwitchOption;
