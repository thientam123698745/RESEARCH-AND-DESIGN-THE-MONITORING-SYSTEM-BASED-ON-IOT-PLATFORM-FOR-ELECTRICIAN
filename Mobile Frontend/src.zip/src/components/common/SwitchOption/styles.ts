import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    padding: MetricSizes.P_20,

    flexDirection: 'row',
    alignItems: 'center',
  },
  imgWrapper: {
    paddingRight: MetricSizes.P_20,
  },
  img: {
    width: MetricSizes.P_20 * 1.5,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  swtWrapper: {
    position: 'absolute',
    right: MetricSizes.P_20,
  },
});
