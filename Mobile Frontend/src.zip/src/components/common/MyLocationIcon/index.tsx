import {View, Image} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';

import styles from './style';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyLocationIcon = ({
  index,
  length,
  showDot,
  isSender,
}: {
  index: number;
  length: number;
  showDot?: boolean;
  isSender: boolean;
}) => {
  const image = isSender
    ? index % 2 === 0
      ? Images.SENDER_LOCATION
      : Images.SENDER_LOCATION_1
    : index % 2 === 0
    ? Images.LOCATION
    : Images.LOCATION2;
  const color = isSender
    ? index % 2 === 0
      ? colors.primary
      : colors.green
    : index % 2 === 0
    ? colors.orange
    : colors.red;
  return (
    <View style={styles.container}>
      <View style={styles.iconWrapper}>
        <Image source={image} style={styles.iconImage} />
      </View>
      {showDot ? (
        index === length - 1 && !isSender ? (
          <></>
        ) : (
          <View style={styles.downIconWrapper}>
            <Image source={Images.DOT_LINE} style={styles.downIconImage} />
          </View>
        )
      ) : (
        <></>
      )}
      <View style={styles.indexWrapper}>
        <Text color={color} type="tiny" style={styles.indexText}>
          {`${index + 1}`}
        </Text>
      </View>
    </View>
  );
};

export default MyLocationIcon;
