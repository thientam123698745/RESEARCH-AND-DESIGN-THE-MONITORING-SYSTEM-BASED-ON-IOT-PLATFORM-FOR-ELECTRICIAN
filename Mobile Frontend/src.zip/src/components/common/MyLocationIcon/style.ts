import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconImage: {
    resizeMode: 'contain',
    width: MetricSizes.big * 1.5,
    height: undefined,
    aspectRatio: 1,
  },
  downIconWrapper: {
    position: 'absolute',
  },
  downIconImage: {
    resizeMode: 'contain',
    width: MetricSizes.P_20,
    height: undefined,
    bottom: -MetricSizes.P_20 * 1.5,
    aspectRatio: 1,
  },
  indexWrapper: {
    position: 'absolute',
    right: MetricSizes.regular,
    bottom: -MetricSizes.regular,
  },
  indexText: {},
});
export default styles;
