import {StyleSheet} from 'react-native';
import {colors} from 'assets/colors';
import {WINDOW_HEIGHT} from 'assets/constants';
import {fonts} from 'assets/fonts';
import MetricSizes from 'assets/constants/MetricSizes';

export const styles = StyleSheet.create({
  truckItemBadgeBackground: {
    borderRadius: 5,
    padding: WINDOW_HEIGHT * 0.005,
  },
  truckItemBadgeText: {
    color: colors.white,
    fontFamily: 'WorkSans-Medium',
    fontSize: 11,
  },
  truckItemWrapper: {
    backgroundColor: colors.white,
    borderRadius: 10,
    margin: WINDOW_HEIGHT * 0.01,
  },
  truckItemImage: {
    width: '100%',
    borderRadius: 10,
    flex: 1,
  },
  truckItemHeaderWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  truckItemStatusButton: {},
  truckItemBadgeWrapper: {
    // backgroundColor: 'red',
    // borderRadius: 8,
    // padding: height * 0.002,
  },
  truckItemBrandText: {
    fontFamily: fonts.SF_PRO_BOLD,
  },
  truckItemNameText: {
    fontFamily: fonts.SF_PRO_BOLD,
    paddingVertical: MetricSizes.P_10,
  },
  truckItemPriceText: {
    color: colors.primary,
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: 15,
  },
  truckItemMilageText: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: 10,
    color: colors.grey,
  },
  truckListMasonryListWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    alignSelf: 'center',
    width: '100%',
  },
  truckItemBadgeImage: {
    borderRadius: 8,
  },
  truckItemBodyWrapper: {
    padding: WINDOW_HEIGHT * 0.01,
  },
});
