import {Image, ImageBackground, TouchableOpacity, View} from 'react-native';

import MasonryList from '@react-native-seoul/masonry-list';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

import useGetImageStatusPost from '@hooks/useGetImageStatusPost';
import Text from '@components/common/Texts/Text';

const MyPaginationTruckList = ({truckList}: {truckList: any}) => {
  const _renderItem = ({item}: {item: any}) => {
    const bgTruckItem = useGetImageStatusPost(item.truck_state);
    return (
      <TouchableOpacity style={styles.truckItemWrapper}>
        <Image style={styles.truckItemImage} source={Images.ITEM1} />
        <View style={styles.truckItemBodyWrapper}>
          <View style={styles.truckItemHeaderWrapper}>
            <TouchableOpacity style={styles.truckItemBadgeWrapper}>
              <ImageBackground
                style={styles.truckItemBadgeBackground}
                imageStyle={styles.truckItemBadgeImage}
                source={bgTruckItem}>
                <Text type="small" style={styles.truckItemBadgeText}>
                  {item.truck_state}
                </Text>
              </ImageBackground>
            </TouchableOpacity>
            {/* <Text variant="body2" style={styles.truckItemBrandText}></Text> */}
          </View>
          <Text type="small" style={styles.truckItemNameText}>
            Huyndai - {item.truck_name}
          </Text>
          <Text
            type="small"
            style={styles.truckItemPriceText}>{`${item.price} đ`}</Text>
          <Text type="small" style={styles.truckItemMilageText}>
            Đã đi {item.MetricSizes} km
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  return truckList ? (
    <MasonryList
      data={truckList}
      keyExtractor={item => item.truck_id}
      numColumns={2}
      showsVerticalScrollIndicator={false}
      renderItem={_renderItem}
    />
  ) : (
    <Text type="small">nothing</Text>
  );
};

export default MyPaginationTruckList;
