import {StatusBar, StatusBarStyle} from 'react-native';
import React from 'react';

const TransStatusBar = ({color}: {color?: StatusBarStyle}) => {
  return (
    <StatusBar barStyle={color} translucent backgroundColor={'transparent'} />
  );
};

export default TransStatusBar;
