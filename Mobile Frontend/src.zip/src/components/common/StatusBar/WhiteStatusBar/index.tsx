import {StatusBar} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';

const WhiteStatusBar = () => {
  return (
    <StatusBar
      barStyle="dark-content"
      // translucent
      backgroundColor={colors.white}
    />
  );
};

export default WhiteStatusBar;
