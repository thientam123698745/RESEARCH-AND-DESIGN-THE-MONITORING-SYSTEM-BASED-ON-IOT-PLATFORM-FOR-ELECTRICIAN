import {View, Modal, Image, TouchableOpacity} from 'react-native';
import React, {useEffect} from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import {useAuthInjector} from '@hooks/useInjector/useAuthInjector';
import {useDispatch, useSelector} from 'react-redux';
import * as AuthSlice from '@store/auth/shared/slice';
import * as ProfileSlice from '@store/profile/shared/slice';
import {
  selectError,
  selectIndex,
  selectLoginError,
  selectSignUpError,
  selectVisible,
} from '@store/auth/shared/selector';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import {selectSearchError} from '@store/bookingTruckOrder/shared/selector';
import {
  selectIsSuccess,
  selectProfileError,
} from '@store/profile/shared/selector';
import {NOTIFICATION_KIND} from '@assets/constants';
import {error_code} from '@assets/constants/error_msg';
import Text from '@components/common/Texts/Text';
const NotificationModal = () => {
  useAuthInjector();
  const visible = useSelector(selectVisible);
  const index = useSelector(selectIndex);
  const error = useSelector(selectError);
  const dataList = [
    {
      id: 0,
      image: Images.MODAL_COMING_SOON,
      color: colors.orange,
      title: 'Tính năng đang cập nhật',
      content:
        'Tính năng này hiện đang trong quá trình phát triển. Xin lỗi quý khách về sự bất tiện này',
    },
    {
      id: 1,
      image: Images.ERR_ILL,
      color: colors.red,
      title: 'ĐĂNG NHẬP THẤT BẠI!',
      content:
        'Tài khoản hoặc mật khẩu của bạn không đúng. Vui lòng nhập đăng nhập lại.',
    },
    {
      id: 2,
      image: Images.ERR_ILL,
      color: colors.red,
      title: 'ĐÃ XẢY RA LỖI !',
      content: error ? error.message : '',
    },
    {
      id: 3,
      image: Images.SUCCESS_ILL,
      color: colors.orange,
      title: 'CẬP NHẬT THÀNH CÔNG',
      content: 'Chúc mừng! thông tin của bạn đã được cập thành công',
    },
  ];
  const data = dataList[index] || {
    id: -1,
    image: Images.ERR_ILL,
    color: colors.orange,
    title: 'Đã xảy ra lỗi',
    content: 'Thông báo này đã bị lỗi ',
  };

  const dispatch = useDispatch();
  function handleChangeVisible() {
    dispatch(AuthSlice.actions.closeNotification());
  }
  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      statusBarTranslucent>
      <View style={styles.container}>
        <View style={styles.view}>
          <View style={styles.modalImageView}>
            <Image source={data.image} style={styles.modalImage} />
          </View>
          <View style={styles.modalTitleView}>
            <Text type="regular" color={colors.orange} isCenter>
              {data.title}
            </Text>
            <Text type="small" color={colors.blackText} isCenter>
              {data.content}
            </Text>
          </View>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={handleChangeVisible}
            style={styles.modalCloseButtonView}>
            <Image
              source={Images.CLOSE_MODAL_BUTTON}
              style={styles.modalCloseButton}
            />
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
export const useCheckError = () => {
  useBookingInjector();
  useAuthInjector();
  useProfileInjector();
  const loginError = useSelector(selectLoginError);
  const signupError = useSelector(selectSignUpError);
  const profileError = useSelector(selectProfileError);
  const searchError = useSelector(selectSearchError);
  const profileSuccess = useSelector(selectIsSuccess);
  const dispatch = useDispatch();

  useEffect(() => {
    function handleAuthorized(error: Error) {
      if (error.message === error_code.UNAUTHORIZED) {
        dispatch(AuthSlice.actions.clearToken());
        return true;
      }
      return false;
    }
    if (profileError) {
      const isAuthorized = handleAuthorized(profileError);
      if (!isAuthorized) {
        dispatch(
          AuthSlice.actions.openNotification({
            index: NOTIFICATION_KIND.ERROR,
            error: profileError,
          }),
        );
      }
      dispatch(ProfileSlice.actions.resetError());
    }
    if (searchError) {
      const isAuthorized = handleAuthorized(searchError);
      if (!isAuthorized) {
        dispatch(
          AuthSlice.actions.openNotification({
            index: NOTIFICATION_KIND.ERROR,
            error: profileError,
          }),
        );
      }
      dispatch(ProfileSlice.actions.resetError());
    }
    if (loginError) {
      const isAuthorized = handleAuthorized(loginError);
      if (!isAuthorized) {
        dispatch(
          AuthSlice.actions.openNotification({
            index: NOTIFICATION_KIND.ERROR,
            error: loginError,
          }),
        );
      }
      dispatch(
        AuthSlice.actions.openNotification({
          index: NOTIFICATION_KIND.LOGIN_FAILED,
          error: loginError,
        }),
      );
    }
    if (signupError) {
      dispatch(
        AuthSlice.actions.openNotification({
          index: NOTIFICATION_KIND.ERROR,
          error: signupError,
        }),
      );
    }
    if (profileSuccess) {
      dispatch(
        AuthSlice.actions.openNotification({index: NOTIFICATION_KIND.SUCCESS}),
      );
      dispatch(ProfileSlice.actions.resetError());
    }
  }, [
    dispatch,
    loginError,
    profileError,
    profileSuccess,
    searchError,
    signupError,
  ]);
};
export default NotificationModal;
