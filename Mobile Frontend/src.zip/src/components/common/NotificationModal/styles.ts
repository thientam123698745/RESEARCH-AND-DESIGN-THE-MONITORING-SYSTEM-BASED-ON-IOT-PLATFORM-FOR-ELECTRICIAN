import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.modal,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view: {
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.white,
    width: '80%',
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_10,
  },
  modalImage: {
    width: '60%',
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 1,
  },
  modalImageView: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalTitleView: {},
  modalCloseButton: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  modalCloseButtonView: {
    top: -5,
    position: 'absolute',
    right: -5,
  },
});
