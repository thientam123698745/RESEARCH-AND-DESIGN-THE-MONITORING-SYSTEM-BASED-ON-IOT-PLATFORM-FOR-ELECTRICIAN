import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {},
  tinyText: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
  },
  smallText: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_14,
  },
  regularText: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_24,
  },
  bigText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_32,
  },
});
