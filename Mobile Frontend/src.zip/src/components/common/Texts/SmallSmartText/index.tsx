import {StyleSheet, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {fonts, fontSize} from '@assets/fonts';

const SmallSmartText = ({
  center,
  text,
  color,
  onPress,
  underlined,
  bold,
}: {
  center?: boolean;
  underlined?: boolean;
  text: string;
  color: string;
  onPress: any;
  bold?: boolean;
}) => {
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
      <Text
        style={[
          styles.text,
          {
            color: color,
            textAlign: center ? 'center' : 'auto',
            textDecorationLine: underlined ? 'underline' : 'none',
            fontWeight: bold ? 'bold' : 'normal',
          },
        ]}>
        {text}
      </Text>
    </TouchableOpacity>
  );
};

export default SmallSmartText;

const styles = StyleSheet.create({
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_14,
  },
});
