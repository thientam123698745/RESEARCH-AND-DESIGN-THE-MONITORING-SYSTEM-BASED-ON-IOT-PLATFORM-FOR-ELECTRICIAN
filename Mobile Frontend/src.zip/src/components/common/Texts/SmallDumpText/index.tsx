import {StyleSheet} from 'react-native';
import React from 'react';
import {fonts, fontSize} from '@assets/fonts';
import Text from '@components/common/Texts/Text';
const SmallDumpText = ({
  center,
  text,
  color,
  underlined,
  italic,
  bold,
  isTruncated,
}: {
  center?: boolean;
  underlined?: boolean;
  text: string;
  color: string;
  italic?: boolean;
  bold?: boolean;
  isTruncated?: boolean;
}) => {
  return (
    <Text
      type="small"
      numberOfLines={isTruncated ? 1 : null}
      style={[
        styles.text,
        {
          color: color,
          textAlign: center ? 'center' : 'auto',
          textDecorationLine: underlined ? 'underline' : 'none',
          fontStyle: italic ? 'italic' : 'normal',
          fontWeight: bold ? 'bold' : 'normal',
        },
      ]}>
      {text}
    </Text>
  );
};

export default SmallDumpText;

const styles = StyleSheet.create({
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_14,
  },
});
