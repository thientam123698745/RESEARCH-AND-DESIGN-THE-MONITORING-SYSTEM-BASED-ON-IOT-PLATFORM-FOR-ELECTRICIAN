import {StyleSheet, Text} from 'react-native';
import React from 'react';
import {fonts, fontSize} from '@assets/fonts';
const TinyDumpText = ({
  center,
  text,
  color,
  underlined,
  italic,
  bold,
  truncated,
}: {
  center?: boolean;
  underlined?: boolean;
  text: string;
  color: string;
  italic?: boolean;
  bold?: boolean;
  truncated?: boolean;
}) => {
  return (
    <Text
      numberOfLines={truncated ? 1 : null}
      style={[
        styles.text,
        {
          color: color,
          textAlign: center ? 'center' : 'auto',
          textDecorationLine: underlined ? 'underline' : 'none',
          fontStyle: italic ? 'italic' : 'normal',
          fontWeight: bold ? 'bold' : 'normal',
        },
      ]}>
      {text}
    </Text>
  );
};

export default TinyDumpText;

const styles = StyleSheet.create({
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
  },
});
