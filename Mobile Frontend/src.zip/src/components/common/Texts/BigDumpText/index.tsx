import {StyleSheet, Text} from 'react-native';
import React from 'react';
import {fonts, fontSize} from '@assets/fonts';
const BigDumpText = ({
  center,
  text,
  color,
  underlined,
}: {
  center?: boolean;
  underlined?: boolean;
  text: string;
  color: string;
}) => {
  return (
    <Text
      style={[
        styles.text,
        {
          color: color,
          textAlign: center ? 'center' : 'auto',
          textDecorationLine: underlined ? 'underline' : 'none',
        },
      ]}>
      {text}
    </Text>
  );
};

export default BigDumpText;

const styles = StyleSheet.create({
  text: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_32,
  },
});
