import {View, Text as RNText, TextProps} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {useTranslation} from 'react-i18next';
import {colors} from '@assets/colors';
interface Props extends TextProps {
  isCenter?: boolean;
  children: any;
  option?: any;
  color?: string;
  isUnderlined?: boolean;
  isItalic?: boolean;
  isBold?: boolean;
  isTruncated?: boolean;
  type: 'tiny' | 'small' | 'regular' | 'big';
  style?: any;
}
const Text = ({
  isCenter = false,
  children,
  option,
  color = colors.blackText,
  isUnderlined = false,
  isItalic = false,
  isBold = false,
  isTruncated = false,
  type,
  style,
  ...props
}: Props) => {
  const {t} = useTranslation();
  let textStyle = styles.tinyText;
  switch (type) {
    case 'small':
      style = styles.smallText;
      break;
    case 'regular':
      style = styles.regularText;
      break;
    case 'big':
      style = styles.bigText;
      break;
  }

  return (
    <View style={styles.container}>
      <RNText
        numberOfLines={isTruncated ? 1 : null}
        style={[
          {
            textAlign: isCenter ? 'center' : 'auto',
            fontStyle: isItalic ? 'italic' : 'normal',
            fontWeight: isBold ? 'bold' : 'normal',
            color: color,
            textDecorationLine: isUnderlined ? 'underline' : 'none',
          },
          textStyle,
          style,
        ]}
        {...props}>
        {t(children, option)}
      </RNText>
    </View>
  );
};

export default Text;
