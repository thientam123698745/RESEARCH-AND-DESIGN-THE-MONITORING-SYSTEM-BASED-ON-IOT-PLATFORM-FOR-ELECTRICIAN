import {WINDOW_WIDTH} from '@assets/constants/index';
import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    margin: MetricSizes.P_10,
    width: WINDOW_WIDTH * 0.8,
    height: undefined,
    borderWidth: 1,
    padding: MetricSizes.P_20,
    textAlign: 'center',
    borderRadius: MetricSizes.P_20,
  },
  modal: {
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1,
    backgroundColor: colors.modal,
  },
  imgWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  img: {
    width: WINDOW_WIDTH * 0.4,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  padding: {
    paddingTop: MetricSizes.P_20,
  },
});
