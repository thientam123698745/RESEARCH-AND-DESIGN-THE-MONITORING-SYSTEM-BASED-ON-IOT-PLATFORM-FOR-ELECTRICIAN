import {View, Modal, Button, Image} from 'react-native';
import React, {useEffect, useState} from 'react';
import SmallDumpText from '@components/common/Texts/SmallDumpText';
import {colors} from '@assets/colors';
import {styles} from './styles';
import MediumDumpText from '@components/common/Texts/MediumLabelText';
import SmallSmartText from '@components/common/Texts/SmallSmartText';
import {Images} from '@assets/constants/images';

const NotifyModal = ({
  error,
  isSuccess,
  resetError,
}: {
  error?: Error;
  isSuccess?: boolean;
  resetError: any;
}) => {
  const [visible, setVisible] = useState(false);
  const message = isSuccess
    ? '200'
    : error
    ? error.message
    : 'Something went wrong';
  const handleClose = () => {
    resetError();
    setVisible(!visible);
  };
  const title = isSuccess ? 'SUCCESS' : 'ERROR';

  const successModal = (
    <View style={styles.modal}>
      <View style={styles.container}>
        <SmallDumpText
          center
          color={colors.orange}
          text="CẬP NHẬT THÀNH CÔNG"
          bold
        />
        <SmallDumpText
          center
          color={colors.blackText}
          text="Chúc mừng! thông tin của bạn đã được cập thành công"
        />
        <View style={styles.imgWrapper}>
          <Image style={styles.img} source={Images.SUCCESS_ILL} />
        </View>
        <View style={styles.padding}>
          <SmallSmartText
            center
            onPress={handleClose}
            color={colors.orange}
            text="TÔI ĐÃ HIỂU"
            underlined
          />
        </View>
      </View>
    </View>
  );
  const errorModal = (
    <View style={styles.modal}>
      <View style={styles.container}>
        <SmallDumpText color={colors.blackText} center text={title} />
        <MediumDumpText color={colors.red} center text={message} />
        <Button onPress={handleClose} title="Close" />
      </View>
    </View>
  );
  const data = isSuccess ? successModal : errorModal;

  useEffect(() => {
    if (error) {
      setVisible(true);
    }
    if (isSuccess) {
      setVisible(true);
    }
  }, [setVisible, error, isSuccess]);

  return (
    <Modal
      animationType="fade"
      transparent={true}
      visible={visible}
      onRequestClose={handleClose}>
      {data}
    </Modal>
  );
};

export default NotifyModal;
