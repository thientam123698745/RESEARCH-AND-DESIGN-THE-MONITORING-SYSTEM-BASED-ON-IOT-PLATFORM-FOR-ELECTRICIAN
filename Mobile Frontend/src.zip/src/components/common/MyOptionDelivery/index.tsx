import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import {Text} from '@react-native-material/core';
const MyOptionDelivery = ({
  disabled,
  image,
  title,
  content,
  onClick,
}: {
  disabled: boolean;
  onClick?: any;
  image: any;
  title: string;
  content: string;
}) => {
  return (
    <TouchableOpacity
      disabled={disabled}
      onPress={() => onClick(true)}
      style={styles.container}>
      <View style={styles.view1}>
        <View style={styles.view4}>
          <Image style={styles.icon} source={image} />
        </View>
        <View style={styles.view3}>
          <Text variant="body2" style={styles.text1}>
            {title}
          </Text>
        </View>
        <View style={styles.view4}>
          <Image style={styles.icon} source={Images.CARET_LEFT} />
        </View>
      </View>
      <View style={styles.view2}>
        <Text style={styles.text2} variant="body2">
          {content}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

export default MyOptionDelivery;
