import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts} from 'assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderColor: colors.greyLine,
    width: '100%',
    paddingVertical: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view1: {
    flexDirection: 'row',
    // justifyContent: 'space-around',
  },
  view2: {
    width: '80%',
    paddingHorizontal: MetricSizes.P_10,
  },
  view3: {
    width: '80%',
    paddingHorizontal: MetricSizes.P_10,
  },
  view4: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
  },
  icon: {
    width: MetricSizes.P_20 * 1.25,
    height: MetricSizes.P_20 * 1.25,
    resizeMode: 'stretch',
  },
  text1: {
    fontFamily: fonts.SF_PRO_BOLD,
  },
  text2: {
    fontFamily: fonts.SF_PRO_LIGHT,
  },
});
export default styles;
