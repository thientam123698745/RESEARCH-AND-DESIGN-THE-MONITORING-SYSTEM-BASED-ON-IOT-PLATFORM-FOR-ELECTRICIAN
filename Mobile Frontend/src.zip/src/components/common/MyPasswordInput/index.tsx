import React, {useState} from 'react';
import {colors} from 'assets/colors';
import {TextInput} from 'react-native-paper';

const MyInputPassword = ({
  label,
  register,
  required,
}: {
  label: any;
  register: any;
  required: any;
}) => {
  const [isSecureTextEntry, setSecureTextEntry] = useState(true);
  return (
    <TextInput
      activeUnderlineColor={colors.blackText}
      activeOutlineColor={colors.white}
      mode="flat"
      label={label}
      secureTextEntry={isSecureTextEntry}
      {...register(label, {required})}
      right={
        isSecureTextEntry ? (
          <TextInput.Icon
            onPress={() => setSecureTextEntry(false)}
            name="eye-off"
          />
        ) : (
          <TextInput.Icon onPress={() => setSecureTextEntry(true)} name="eye" />
        )
      }
    />
  );
};

export default MyInputPassword;
