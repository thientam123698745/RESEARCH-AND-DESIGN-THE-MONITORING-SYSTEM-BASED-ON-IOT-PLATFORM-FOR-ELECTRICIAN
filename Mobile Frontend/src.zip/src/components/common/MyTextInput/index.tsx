import {View} from 'react-native';
import React from 'react';
import {TextInput} from 'react-native-paper';
import MyLocationIcon from '../MyLocationIcon';
import styles from './style';
import {colors} from '@assets/colors';
import {Address} from '@store/models/BookingOrder.model';

const MyTextInput = ({
  label,
  address,
  onClose,
  index,
  length,
  isSenderAddress,
  isEditable,
  disabled,
}: {
  index?: number;
  label: string;
  address: Address;
  onClose?: Function;
  length?: number;
  isSenderAddress: boolean;
  isEditable: boolean;
  disabled: boolean;
}) => {
  const rightComponent = isEditable ? (
    <TextInput.Icon
      onPress={() => {
        onClose(index);
      }}
      name="close"
    />
  ) : (
    <></>
  );

  return (
    <View style={styles.container}>
      <View style={styles.view1}>
        <MyLocationIcon
          isSender={isSenderAddress}
          index={index}
          length={length}
        />
      </View>
      <View style={styles.view2}>
        <TextInput
          selection={{start: 0, end: 0}}
          multiline={true}
          disabled={disabled !== undefined ? true : disabled}
          activeUnderlineColor={colors.grey}
          style={styles.textInput}
          label={`${label} ${index + 1}`}
          right={rightComponent}
          value={address.shortAddress}
        />
      </View>
    </View>
  );
};

export default MyTextInput;
