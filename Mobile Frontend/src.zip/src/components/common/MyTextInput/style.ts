import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  textInput: {
    color: colors.blackText,
    backgroundColor: colors.transparent,
  },
  container: {
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view1: {
    width: '15%',
  },
  view2: {
    width: '85%',
    height: '100%',
  },
});
export default styles;
