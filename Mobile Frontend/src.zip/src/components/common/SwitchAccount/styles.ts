import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // justifyContent: 'center',
    // borderWidth: 1,
    backgroundColor: colors.white,
    marginVertical: MetricSizes.P_10,
    padding: MetricSizes.P_20 * 0.7,
    paddingHorizontal: MetricSizes.P_20,
    flexDirection: 'row',
    alignItems: 'center',
  },
  imgWrapper: {
    paddingRight: MetricSizes.P_20,
  },
  img: {
    width: MetricSizes.P_20 * 1.5,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  swtWrapper: {
    position: 'absolute',
    right: MetricSizes.P_20,
  },
});
