import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Switch} from 'react-native-paper';
import Text from '@components/common/Texts/Text';
const SwitchAccount = ({
  index,
  image,
  text,
}: {
  index: any;
  image: any;
  text: string;
}) => {
  const [isSwitchOn, setIsSwitchOn] = React.useState(false);

  const onToggleSwitch = () => setIsSwitchOn(!isSwitchOn);

  return (
    <View style={styles.container} key={index}>
      <View style={styles.imgWrapper}>
        <Image style={styles.img} source={image} />
      </View>

      <Text type="small" color={colors.blackText} isBold>
        {text}
      </Text>
      <View style={styles.swtWrapper}>
        <Switch value={isSwitchOn} onValueChange={onToggleSwitch} />
      </View>
    </View>
  );
};

export default SwitchAccount;
