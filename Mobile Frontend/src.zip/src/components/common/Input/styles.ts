import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {},
  textInput: {
    bottom: -1.5,
    backgroundColor: colors.greyLine,
    // color: colors.blackText,
  },
  inputWrapper: {
    backgroundColor: colors.greyLine,
    borderColor: colors.grey,
    borderWidth: 2,
    borderRadius: 10,
    paddingHorizontal: MetricSizes.P_10,
  },
});
