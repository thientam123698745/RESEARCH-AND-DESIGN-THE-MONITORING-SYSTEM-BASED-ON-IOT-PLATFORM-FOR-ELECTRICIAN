import React from 'react';
import {HelperText, TextInput} from 'react-native-paper';
import {useController} from 'react-hook-form';
import {View} from 'react-native';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {useTranslation} from 'react-i18next';
const Input = ({
  disabled,
  name,
  control,
  label,
  isPassword,
  rules,
  errMsg,
  input_value,
}: {
  disabled?: boolean;
  name: any;
  control?: any;
  label: any;
  isPassword?: boolean;
  rules?: any;
  errMsg?: string;
  input_value?: string;
}) => {
  const [isShow, setIsShow] = React.useState(true);

  const {t} = useTranslation();

  const {
    field: {onChange, value},
    fieldState: {invalid, error},
  } = useController({
    name,
    control,
    rules,
    defaultValue: input_value,
  });
  let message = '';
  if (error) {
    message = t(errMsg);
    if (error.type === 'valueAsNumber') {
      message = `${label} bắt buộc dữ liệu phải là số`;
    }
    if (error.type === 'required') {
      message = `${label} chưa có dữ liệu`;
    }
    if (error.type === 'minLength') {
      message = `${label} cần phải nhập tối thiểu ${rules.minLength} kí tự`;
    }
    if (error.type === 'maxLength') {
      message = `${label} cần phải nhập tối đa ${rules.maxLength} kí tự`;
    }
    if (error.type === 'exist') {
      message = `${label} đã tồn tại . Xin hãy chọn tên khác`;
    }
    if (error.type === 'confirm') {
      message = t('error.confirm');
    }
  }
  return (
    <View style={styles.container}>
      <View
        style={[
          styles.inputWrapper,
          {borderColor: invalid ? colors.red : colors.greyLine},
        ]}>
        <TextInput
          disabled={disabled}
          style={styles.textInput}
          activeUnderlineColor={invalid ? colors.red : colors.grey}
          underlineColor={invalid ? colors.red : colors.grey}
          selectionColor={colors.blackText}
          value={value}
          onChangeText={onChange}
          mode="flat"
          label={t(label)}
          secureTextEntry={isShow && isPassword}
          right={
            isPassword ? (
              isShow ? (
                <TextInput.Icon
                  color={colors.blackText}
                  onPress={() => setIsShow(false)}
                  name="eye"
                />
              ) : (
                <TextInput.Icon
                  onPress={() => setIsShow(true)}
                  color={colors.borderGray}
                  name="eye-off"
                />
              )
            ) : (
              <></>
            )
          }
        />
      </View>
      <HelperText type="error" visible={invalid}>
        {message}
      </HelperText>
    </View>
  );
};

export default Input;
