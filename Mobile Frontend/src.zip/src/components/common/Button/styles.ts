import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  linearView: {
    padding: MetricSizes.P_20,
    borderRadius: MetricSizes.P_10,
  },
  blueOutlineButtonActive: {
    borderColor: colors.grey,
    borderWidth: 1,
    borderRadius: MetricSizes.P_10,
  },
  blueButtonActive: {
    borderRadius: MetricSizes.P_10,
  },
});
