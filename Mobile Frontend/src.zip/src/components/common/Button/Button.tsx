import {TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import Text from '@components/common/Texts/Text';
import LinearGradient from 'react-native-linear-gradient';
import {colors, linear_gradient} from '@assets/colors';
interface Props {
  onPress: any;
  children: any;
  option?: any;
  disabled?: boolean;
  type: 'solid' | 'outline';
}
const Button = ({onPress, children, option, disabled = false, type}: Props) => {
  const style =
    type === 'solid' ? styles.blueButtonActive : styles.blueOutlineButtonActive;
  const colorText = disabled
    ? colors.white
    : type === 'solid'
    ? colors.white
    : colors.grey;
  const colorButton = disabled
    ? linear_gradient.grey
    : type === 'solid'
    ? linear_gradient.blue
    : linear_gradient.transparent;
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onPress}
      disabled={disabled}
      style={style}>
      <LinearGradient
        style={styles.linearView}
        angle={180}
        colors={colorButton}>
        <Text isCenter type="small" color={colorText} option={option}>
          {children}
        </Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};
export default Button;
