import {StyleSheet, Text, TouchableOpacity} from 'react-native';
import React from 'react';
import LinearGradient from 'react-native-linear-gradient';
import {linear_gradient, colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
const BlueBtn = ({
  label,
  onPress,
  disabled,
}: {
  label: any;
  onPress: any;
  disabled?: boolean;
}) => {
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress} disabled={disabled}>
      <LinearGradient
        style={styles.button}
        angle={180}
        colors={
          disabled ? linear_gradient.disabled : linear_gradient.blueWhite
        }>
        <Text style={styles.text}>{label}</Text>
      </LinearGradient>
    </TouchableOpacity>
  );
};

export default BlueBtn;

const styles = StyleSheet.create({
  button: {
    borderRadius: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10 * 1.5,
  },
  text: {
    textAlign: 'center',
    color: colors.white,
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_14,
  },
});
