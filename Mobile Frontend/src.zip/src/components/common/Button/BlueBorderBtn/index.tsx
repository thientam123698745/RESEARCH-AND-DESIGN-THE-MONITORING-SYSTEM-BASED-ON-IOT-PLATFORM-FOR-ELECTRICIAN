import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
const BlueBorderBtn = ({label, onPress}: {label: string; onPress: any}) => {
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
      <View style={styles.button}>
        <Text style={styles.text}>{label}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default BlueBorderBtn;

const styles = StyleSheet.create({
  button: {
    borderRadius: MetricSizes.P_10,
    borderColor: colors.grey,
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
    borderWidth: 1,
  },
  text: {
    color: colors.grey,
    textAlign: 'center',
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_14,
  },
});
