import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const Address = ({
  name,
  phone,
  address,
  isDefaultAddress,
}: {
  name: string;
  phone: string;
  address: string;
  isDefaultAddress: boolean;
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.view1}>
        <View style={styles.view3}>
          <View style={styles.view5}>
            <View style={styles.view7}>
              <Text type="regular" color={colors.blackText}>
                {name}
              </Text>
            </View>
            <View style={styles.view8}>
              <Text type="regular" color={colors.blackText}>
                {phone}
              </Text>
            </View>
          </View>
          <View style={styles.view6}>
            <Text type="regular" color={colors.blackText}>
              {address}
            </Text>
          </View>
        </View>
        <TouchableOpacity style={styles.view4}>
          <Image style={styles.img} source={Images.MORE} />
        </TouchableOpacity>
      </View>
      {isDefaultAddress ? (
        <View style={styles.view2}>
          <View style={styles.imgWrapper}>
            <Image style={styles.flag} source={Images.FLAG} />
          </View>
          <Text type="small" color={colors.red}>
            default_address
          </Text>
        </View>
      ) : (
        <></>
      )}
    </View>
  );
};

export default Address;
