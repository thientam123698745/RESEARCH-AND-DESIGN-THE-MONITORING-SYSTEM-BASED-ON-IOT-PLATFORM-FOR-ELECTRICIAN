import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    // borderWidth: 1,
    marginVertical: 10,
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.white,
    paddingVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
  },
  view1: {
    flexDirection: 'row',
    alignItems: 'center',
    width: '100%',
    // borderWidth: 1,
  },
  view3: {
    // borderWidth: 1,
    width: '80%',
  },
  view5: {
    // borderWidth: 1,
    flexDirection: 'row',
    width: '100%',
  },
  view7: {
    // width: '40%',
    paddingRight: MetricSizes.P_10,
  },
  view8: {
    // width: '70%',
    borderLeftWidth: 1,
    paddingLeft: MetricSizes.P_10,
  },
  view6: {
    paddingVertical: MetricSizes.P_10,
  },
  view4: {
    // width: '20%',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    right: 0,
  },
  view2: {
    flexDirection: 'row',
    // borderWidth: 1,
    alignItems: 'center',
  },
  img: {
    width: MetricSizes.P_20 * 1.5,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  imgWrapper: {
    // paddingVertical: MetricSizes.P_10,
    paddingRight: MetricSizes.P_10,
  },
  flag: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
});
