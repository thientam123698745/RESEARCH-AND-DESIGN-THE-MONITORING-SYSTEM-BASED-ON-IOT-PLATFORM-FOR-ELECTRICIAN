import {Image, View} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';
import * as Components from '@components/index';
import {BottomRouterParamList} from 'src/types';
import {styles} from './styles';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {btRouters} from '@assets/constants/btRouters';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectRecipients} from '@store/bookingTruckOrder/shared/selector';
import 'src/translations';
import {colors} from '@assets/colors';
import {useTranslation} from 'react-i18next';
import {fonts, fontSize} from '@assets/fonts';
import {TouchableRipple} from 'react-native-paper';

const Tab = createBottomTabNavigator<BottomRouterParamList>();
const MyBottomTabs = () => {
  const {t} = useTranslation();
  useBookingInjector();
  const recipientAddresses = useSelector(selectRecipients);
  const isEmpty = recipientAddresses.length === 0;
  function handleRedirect(navigation: any, name: string) {
    navigation.navigate(name);
  }
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          height: 76,
        },
        tabBarBackground() {
          return (
            <View style={styles.bgWrapper}>
              <Image
                source={Images.BOTTOM_TAB_BACKGROUND}
                style={styles.bgImage}
              />
            </View>
          );
        },
      }}>
      <Tab.Screen
        name={btRouters.HOMEPAGE}
        component={Components.HomePage}
        options={({navigation}) => ({
          tabBarLabelStyle: {display: 'none'},
          tabBarIcon: ({focused}) => (
            <>
              <TouchableRipple
                borderless
                onPress={() => handleRedirect(navigation, 'Homepage')}
                style={styles.activeBar}>
                {focused ? (
                  <>
                    <View style={styles.iconWrapper}>
                      <Image
                        source={Images.HOME_FILL}
                        style={styles.homeImage}
                      />
                    </View>
                    <View style={styles.activeWrapper}>
                      <Image
                        source={Images.ACTIVE_BAR}
                        style={styles.activeImage}
                      />
                    </View>
                  </>
                ) : (
                  <View style={styles.iconWrapper}>
                    <Image
                      source={Images.HOME_FILL_2}
                      style={styles.homeImage}
                    />
                  </View>
                )}
              </TouchableRipple>
            </>
          ),
        })}
      />
      <Tab.Screen
        name={btRouters.BOOK_CAR}
        component={
          isEmpty ? Components.AddressSearchingOfReceiver : Components.OrderMenu
        }
        options={({navigation}) => ({
          tabBarStyle: {display: 'none'},
          tabBarShowLabel: true,
          tabBarLabel: t('bottom_bar'),
          tabBarLabelStyle: {
            fontFamily: fonts.SF_PRO_BOLD,
            fontWeight: 'bold',
            fontSize: fontSize.FS_16,
            color: colors.orange,
          },
          tabBarIcon() {
            return (
              <View style={styles.bookCarWrapper}>
                <TouchableRipple
                  style={styles.bookCarImageWrapper}
                  borderless
                  onPress={() => handleRedirect(navigation, 'BookCar')}>
                  <Image
                    source={Images.BOOK_CAR_TRUCK}
                    style={styles.bookCarImage}
                  />
                </TouchableRipple>
              </View>
            );
          },
        })}
      />
      <Tab.Screen
        name={btRouters.MAP_COMPONENT}
        component={Components.MapComponent}
        options={({navigation}) => ({
          tabBarLabelStyle: {display: 'none'},
          tabBarIcon: ({focused}) => (
            <TouchableRipple
              onPress={() => handleRedirect(navigation, 'MapComponent')}
              style={styles.activeBar}>
              {focused ? (
                <>
                  <View style={styles.iconWrapper}>
                    <Image source={Images.MAP_ICON} style={styles.homeImage} />
                  </View>
                  <View style={styles.activeWrapper}>
                    <Image
                      source={Images.ACTIVE_BAR_2}
                      style={styles.activeImage}
                    />
                  </View>
                </>
              ) : (
                <View style={styles.iconWrapper}>
                  <Image
                    source={Images.MAP_ICON_DISABLE}
                    style={styles.homeImage}
                  />
                </View>
              )}
            </TouchableRipple>
          ),
        })}
      />
    </Tab.Navigator>
  );
};

export default MyBottomTabs;
