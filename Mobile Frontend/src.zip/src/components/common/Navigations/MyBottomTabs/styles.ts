import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  activeBar: {
    width: '100%',
    alignItems: 'center',
  },
  activeImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  iconWrapper: {
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  homeImage: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'contain',
  },
  activeWrapper: {
    width: '100%',
    position: 'absolute',
    bottom: 0,
    height: '20%',
  },
  bgWrapper: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 100,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 5,
    },
    shadowOpacity: 0.34,
    shadowRadius: 6.27,

    elevation: 10,
  },
  bgImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'stretch',
  },
  bookCarWrapper: {
    alignItems: 'center',
    width: '100%',
    bottom: 15,
    justifyContent: 'center',
  },
  bookCarImage: {
    resizeMode: 'stretch',
    width: '100%',
    height: '100%',
  },
  bookCarImageWrapper: {
    width: '40%',
    height: undefined,
    borderRadius: 1000,
    aspectRatio: 1 / 1,
  },
});
