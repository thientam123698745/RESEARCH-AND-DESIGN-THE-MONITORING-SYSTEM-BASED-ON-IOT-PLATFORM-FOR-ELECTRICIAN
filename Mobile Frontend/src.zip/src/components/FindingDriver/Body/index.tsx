import {View, Image, Text as RNText} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
interface Props {
  time: number;
}
const Body = ({time}: Props) => {
  return (
    <View style={styles.container}>
      <View style={styles.title}>
        <Text type="regular" color={colors.blackText}>
          finding_driver
        </Text>
      </View>
      <View style={styles.content}>
        <Text type="small" color={colors.blackText}>
          is_finding_driver
        </Text>
      </View>
      <View style={styles.loadingImage}>
        <Image source={Images.FINDING_DRIVER} style={styles.image} />
        <RNText style={styles.text}>
          <Text type="small" isCenter color={colors.blackText}>
            time_finding
          </Text>
          <Text type="small" isCenter color={colors.primary}>
            {` ${time} s`}
          </Text>
        </RNText>
      </View>
      <View style={styles.closeBtn}>
        <Button type="solid" onPress={() => {}}>
          cancel
        </Button>
      </View>
    </View>
  );
};
export default Body;
