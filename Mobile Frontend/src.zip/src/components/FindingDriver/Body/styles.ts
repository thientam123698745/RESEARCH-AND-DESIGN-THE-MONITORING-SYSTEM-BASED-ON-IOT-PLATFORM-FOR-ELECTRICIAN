import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 4,
    zIndex: -1,
    backgroundColor: colors.white,
    justifyContent: 'space-around',
    alignItems: 'center',
    // paddingVertical: MetricSizes.P_20,
  },
  title: {},
  content: {},
  loadingImage: {
    paddingVertical: MetricSizes.P_10,
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    width: '80%',
    height: undefined,
    aspectRatio: 2 / 1,
    resizeMode: 'center',
  },
  text: {
    alignItems: 'center',
    position: 'absolute',
    bottom: 0,
  },
  closeBtn: {
    width: '80%',
  },
});
