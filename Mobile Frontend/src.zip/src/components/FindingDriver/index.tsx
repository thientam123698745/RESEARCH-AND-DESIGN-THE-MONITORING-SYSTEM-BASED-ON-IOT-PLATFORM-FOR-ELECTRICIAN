import {View} from 'react-native';
import React, {useEffect, useState} from 'react';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import DetailOrder from '@components/FindingDriver/DetailOrder';
import Header from '@components/FindingDriver/Header';
import Body from '@components/FindingDriver/Body';
import {styles} from './styles';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
const FindingDriver = () => {
  const navigaiton = useNavigate();
  const [second, setSecond] = useState(0);

  useEffect(() => {
    setTimeout(() => {
      navigaiton.navigate(routers.BOOKING_TRACKING_DRIVER);
    }, 5000);
  }, []);
  useEffect(() => {
    setTimeout(() => {
      setSecond(second + 1);
    }, 1000);
  }, [second]);

  return (
    <View style={styles.container}>
      <TransStatusBar color="dark-content" />
      <Header />
      <Body time={second} />
      <DetailOrder />
    </View>
  );
};
export default FindingDriver;
