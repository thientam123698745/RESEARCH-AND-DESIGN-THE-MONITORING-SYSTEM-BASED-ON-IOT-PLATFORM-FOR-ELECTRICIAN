import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
const Header = () => {
  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>{/* <Text>Header</Text> */}</View>
    </View>
  );
};
export default Header;
