import {View, Modal, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const FoundModal = ({
  visible,
  handleVisible,
  handleContinue,
}: {
  visible: boolean;
  handleVisible: any;
  handleContinue: Function;
}) => {
  return (
    <Modal visible={visible} transparent statusBarTranslucent>
      <View style={styles.container}>
        <View style={styles.modalContainer}>
          <View style={styles.imageWrapper}>
            <TouchableOpacity onPress={handleVisible}>
              <Image source={Images.CLOSE_BUTTON} style={styles.image} />
            </TouchableOpacity>
          </View>
          <View>
            <Text type="regular" color={colors.blackText} isCenter>
              already_finding_driver
            </Text>
          </View>
          <View>
            <Text type="small" isCenter color={colors.blackText}>
              already_finding_driver_notice
            </Text>
          </View>
          <View style={styles.btnWrapper}>
            <Button type="solid" onPress={handleContinue}>
              view_detail
            </Button>
          </View>
        </View>
      </View>
    </Modal>
  );
};
export default FoundModal;
