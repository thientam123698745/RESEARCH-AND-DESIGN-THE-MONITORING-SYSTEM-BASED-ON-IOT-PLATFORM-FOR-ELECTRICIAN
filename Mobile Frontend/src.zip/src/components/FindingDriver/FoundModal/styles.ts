import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.modal,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_10,
    width: '80%',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 8 / 6,
  },
  btnWrapper: {
    width: '100%',
  },
  image: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  imageWrapper: {
    alignSelf: 'flex-end',
  },
});
