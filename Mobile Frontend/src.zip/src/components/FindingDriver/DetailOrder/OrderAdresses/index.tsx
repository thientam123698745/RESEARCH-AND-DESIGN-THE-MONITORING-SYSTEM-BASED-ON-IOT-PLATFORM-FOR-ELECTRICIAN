import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import MyLocationIcon from '@components/common/MyLocationIcon';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import Text from '@components/common/Texts/Text';
const OrderAddresses = () => {
  useBookingInjector();
  return (
    <View style={styles.container}>
      <View>
        <Text type="small" color={colors.blackText} isBold>
          order_detail
        </Text>
      </View>
      <View style={styles.address}>
        <View style={styles.image}>
          <MyLocationIcon
            isSender={false}
            index={-1}
            showDot={true}
            length={1}
          />
        </View>
        <View style={styles.text}>
          <Text type="small" color={colors.blackText} isBold>
            customer_name
          </Text>
          <Text type="small" color={colors.blackText} isTruncated>
            address
          </Text>
        </View>
      </View>
    </View>
  );
};
export default OrderAddresses;
