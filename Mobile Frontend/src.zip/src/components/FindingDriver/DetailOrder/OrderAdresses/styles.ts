import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 9,
    paddingHorizontal: MetricSizes.P_20,
    backgroundColor: colors.white,
    marginTop: MetricSizes.P_10,
    justifyContent: 'space-around',
  },
  title: {
    paddingHorizontal: MetricSizes.P_20,
  },
  address: {
    width: '100%',
    flexDirection: 'row',
  },
  image: {
    width: '20%',
  },
  text: {
    width: '80%',
    paddingVertical: MetricSizes.P_10,
  },
});
