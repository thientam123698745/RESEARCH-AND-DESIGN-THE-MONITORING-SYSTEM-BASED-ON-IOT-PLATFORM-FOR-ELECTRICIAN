import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const OrderTotal = () => {
  return (
    <View style={styles.container}>
      <View style={styles.bill}>
        <View style={styles.text}>
          <Text type="small" color={colors.blackText} isBold>
            total
          </Text>
          <Text type="small" color={colors.blackText} isBold>
            300.000.000 d
          </Text>
        </View>
        <View style={styles.textUnderlined}>
          <Text type="small" color={colors.blackText}>
            fee
          </Text>
          <Text type="small" color={colors.blackText}>
            300.000.000 d
          </Text>
        </View>
        <View style={styles.text}>
          <Text type="small" color={colors.blackText}>
            payment_method
          </Text>
          <Text type="small" color={colors.primary}>
            wallet
          </Text>
        </View>
      </View>
    </View>
  );
};
export default OrderTotal;
