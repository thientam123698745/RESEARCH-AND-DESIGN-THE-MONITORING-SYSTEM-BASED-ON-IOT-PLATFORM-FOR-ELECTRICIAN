import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import OrderAddresses from '@components/FindingDriver/DetailOrder/OrderAdresses';
import OrderTotal from '@components/FindingDriver/DetailOrder/OrderTotal';
const DetailOrder = () => {
  return (
    <View style={styles.container}>
      <OrderAddresses />
      <OrderTotal />
    </View>
  );
};
export default DetailOrder;
