import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 4,
  },
  title: {},
  address: {
    width: '100%',
    flexDirection: 'row',
  },
  image: {
    width: '20%',
  },
  text: {
    width: '80%',
    // paddingVertical: MetricSizes.P_10,
  },
});
