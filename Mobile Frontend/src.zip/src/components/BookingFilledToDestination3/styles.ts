import {colors} from 'assets/colors';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1.2,
    backgroundColor: colors.white,
  },
  subContainer: {
    flex: 7.6,
  },
});
export default styles;
