import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  receiverTitleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
  },
  receiverTitleImage: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    marginRight: MetricSizes.P_10,
  },
  receiverTitleText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
  mapWrapper: {width: '100%', height: '100%'},
  container: {
    flex: 7,
    justifyContent: 'center',
  },
  textInput: {
    width: '100%',
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    padding: -10,
  },
  icon: {
    width: MetricSizes.P_10 * 1.5,
    height: MetricSizes.P_10 * 1.5,
    marginRight: MetricSizes.P_10,
  },
  bodyWrapper: {
    flex: 1,
    marginHorizontal: MetricSizes.P_20,
    marginVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_10 * 0.5,
    paddingTop: MetricSizes.P_10 * 0.5,
    borderRadius: MetricSizes.P_10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  bodyMapWrapper: {
    borderRadius: MetricSizes.P_10,
    height: WINDOW_HEIGHT * 0.2,
  },
  bodyInfoWrapper: {
    flex: 4,
    paddingHorizontal: MetricSizes.P_10,
    paddingTop: MetricSizes.P_10,
  },
  bodyButtonWrapper: {
    flex: 1,
  },
  bodyInfoTItle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  bodyInfoTItleButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    // paddingVertical: MetricSizes.P_10 * 0.5,
    paddingHorizontal: MetricSizes.P_10 * 0.8,
    borderRadius: MetricSizes.P_10 * 0.5,
    backgroundColor: colors.lightBlue,
  },
  bodyInfoTitleButtonText: {
    color: colors.primary,
    fontSize: MetricSizes.P_10,
    padding: MetricSizes.P_10 * 0.5,
  },
  bodyInfoTitleText: {
    flexGrow: 1,
    fontSize: fontSize.FS_16,
    fontWeight: 'bold',
    fontFamily: fonts.SF_PRO_REGULAR,
  },
  bodyInfoTitleIcon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    marginRight: MetricSizes.P_10,
  },
  bodyInfoAddress: {
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
    borderBottomWidth: 0.5,
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    borderColor: colors.grey,
  },
  bodyInfoApartment: {
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderColor: colors.grey,
    flexDirection: 'row',
    flex: 1,
    paddingVertical: MetricSizes.P_10,
  },
  bodyInfoNote: {
    flex: 1,
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderColor: colors.grey,
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
  },
  bodyInfoButton: {
    color: colors.primary,
    fontSize: fontSize.FS_16,
    paddingVertical: MetricSizes.P_10,
    fontWeight: 'bold',
    fontFamily: fonts.SF_PRO_BOLD,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bodyInfoButtonWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    flex: 1.5,
  },
});
export default styles;
