import {Image, TextInput, TouchableOpacity, View} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import MapView from 'react-native-maps';
import {Text} from '@react-native-material/core';
// import MapView from 'react-native-maps';

const MyBody = () => {
  return (
    <View style={styles.container}>
      <View style={styles.receiverTitleWrapper}>
        <Image
          source={Images.LOCATION_DOT2}
          style={styles.receiverTitleImage}
        />
        <Text variant="subtitle1" style={styles.receiverTitleText}>
          Địa chỉ Người Gửi
        </Text>
      </View>
      <View style={styles.bodyWrapper}>
        <View style={styles.bodyMapWrapper}>
          <MapView
            style={styles.mapWrapper}
            region={{
              latitude: 42.78825,
              longitude: -122.4324,
              latitudeDelta: 0.2,
              longitudeDelta: 0.1,
            }}
            initialRegion={{
              latitude: 40.78825,
              longitude: -122.4324,
              latitudeDelta: 0.02,
              longitudeDelta: 0.02,
            }}
          />
        </View>
        <View style={styles.bodyInfoWrapper}>
          <View style={styles.bodyInfoTItle}>
            <Image
              style={styles.bodyInfoTitleIcon}
              source={Images.CURRENT_LOCATION}
            />
            <Text variant="subtitle1" style={styles.bodyInfoTitleText}>
              123 Đ.Nguyễn Xí
            </Text>
            <TouchableOpacity style={styles.bodyInfoTItleButton}>
              <Text variant="subtitle1" style={styles.bodyInfoTitleButtonText}>
                Thay đỏi
              </Text>
            </TouchableOpacity>
          </View>
          <Text variant="body2" style={styles.bodyInfoAddress}>
            123 Nguyễn Xí, Phường 13, Quận Bình Thạnh, Thành phố Hồ Chí Minh,
            Việt Nam
          </Text>
          <View style={styles.bodyInfoApartment}>
            <Image style={styles.icon} source={Images.HOME} />
            <TextInput
              placeholder="Thêm số tầng hoặc số căn hộ"
              style={styles.textInput}
            />
          </View>
          <View style={styles.bodyInfoNote}>
            <Image style={styles.icon} source={Images.NOTE} />
            <TextInput
              placeholder="Thêm chỉ dẫn giao hàng"
              style={styles.textInput}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default MyBody;
