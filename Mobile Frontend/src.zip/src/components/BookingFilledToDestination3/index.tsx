import React from 'react';
import {ScrollView, View} from 'react-native';
import MyBody from './MyBody';
import MyButton from './MyButton';
import MyHeader from './MyHeader';
import MyReceiver from './MyReceiver';
import styles from './styles';

const BookingFilledToDestination3 = () => {
  return (
    <View style={styles.container}>
      <MyHeader />
      <View style={styles.subContainer}>
        <ScrollView>
          <MyBody />
          <MyReceiver />
        </ScrollView>
      </View>
      <MyButton />
    </View>
  );
};

export default BookingFilledToDestination3;
