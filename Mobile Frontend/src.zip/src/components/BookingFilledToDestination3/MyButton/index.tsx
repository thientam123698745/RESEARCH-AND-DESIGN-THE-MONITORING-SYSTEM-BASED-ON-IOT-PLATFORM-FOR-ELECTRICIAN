import {View, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './style';
import useNavigate from '@hooks/useNavigate';
import Text from '@components/common/Texts/Text';
import {routers} from '@assets/constants/routers';
const MyButton = () => {
  const navigation = useNavigate();
  return (
    <View style={styles.buttonWrapper}>
      <TouchableOpacity
        onPress={() => navigation.navigate(routers.ORDER_MENU)}
        style={styles.button}>
        <Text type="small" style={styles.buttonText}>
          button.continue
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default MyButton;
