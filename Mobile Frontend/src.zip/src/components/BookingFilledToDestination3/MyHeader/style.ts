import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts} from 'assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  headerWrapper: {
    backgroundColor: colors.primary,
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: MetricSizes.P_20,
    paddingTop: MetricSizes.P_40 * 0.5,
  },
  headerImage: {
    marginRight: MetricSizes.P_20,
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  headerText: {
    color: colors.white,
    fontFamily: fonts.SF_PRO_BOLD,
  },
});
export default styles;
