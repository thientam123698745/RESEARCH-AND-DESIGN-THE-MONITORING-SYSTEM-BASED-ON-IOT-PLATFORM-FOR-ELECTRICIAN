import {Image, ImageBackground, TouchableOpacity} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';

import styles from './style';
import {Text} from '@react-native-material/core';
import useNavigate from '@hooks/useNavigate';
const MyHeader = () => {
  const navigation = useNavigate();
  return (
    <ImageBackground
      source={Images.BG_BOOKING_FILLED}
      style={styles.headerWrapper}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Image style={styles.headerImage} source={Images.TT_RETURN} />
      </TouchableOpacity>
      <Text variant="subtitle1" style={styles.headerText}>
        Lấy hàng tại
      </Text>
    </ImageBackground>
  );
};

export default MyHeader;
