import {View, Image, TextInput} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import {Text} from '@react-native-material/core';
const MyReceiver = () => {
  return (
    <View style={styles.receiverWrapper}>
      <View style={styles.receiverTitleWrapper}>
        <Image
          source={Images.LOCATION_DOT2}
          style={styles.receiverTitleImage}
        />
        <Text variant="subtitle1" style={styles.receiverTitleText}>
          Thông Tin Người Gửi
        </Text>
      </View>
      <View style={styles.receiverBodyWrapper}>
        <TextInput style={styles.textInput} placeholder="Ten nguoi gui" />
        <TextInput style={styles.textInput} placeholder="So dien thoai" />
        <View style={styles.noteView}>
          <Image source={Images.NOTEBOOK} style={styles.note} />
          <TextInput
            style={styles.textInput_note}
            placeholder="Ghi chú cho tài xế"
          />
        </View>
      </View>
    </View>
  );
};

export default MyReceiver;
