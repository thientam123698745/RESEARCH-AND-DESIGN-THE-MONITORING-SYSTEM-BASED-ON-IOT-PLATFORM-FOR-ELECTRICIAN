import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts, fontSize} from 'assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  receiverWrapper: {
    flex: 3,
    paddingHorizontal: MetricSizes.P_20,
    justifyContent: 'center',
  },
  receiverButtonWrapper: {},
  receiverTitleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  receiverTitleImage: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    marginRight: MetricSizes.P_10,
  },
  receiverTitleText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
  receiverBodyWrapper: {
    justifyContent: 'flex-start',
  },
  note: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
    marginRight: MetricSizes.P_20,
  },
  noteView: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    // paddingVertical: MetricSizes.P_10,
  },
  textInput_note: {
    fontFamily: fonts.SF_PRO_REGULAR,
    alignItems: 'center',
    borderColor: colors.grey,
    flexGrow: 1,
    // marginTop: MetricSizes.P_10 * 0.5,
    fontSize: fontSize.FS_16 * 0.9,
    // borderWidth: 1,
  },
  textInput: {
    fontFamily: fonts.SF_PRO_REGULAR,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    flexGrow: 1,
    paddingVertical: MetricSizes.P_10,
    marginTop: MetricSizes.P_10 * 0.5,
    fontSize: fontSize.FS_16,
  },
  icon: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    resizeMode: 'stretch',
  },
  receiverBodyNoteWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    justifyContent: 'center',
  },
});
export default styles;
