import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
import {fonts, fontSize} from '@assets/fonts';

export const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    borderColor: colors.grey,
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: MetricSizes.P_10 * 1.6,
  },
  selectLabel: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10 * 1.2,
    color: colors.blackText,
  },
  iconWrapper: {},
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
});
