import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';

const MySelectionItem = ({
  label,
  navigateLink,
}: {
  label: any;
  navigateLink: any;
}) => {
  const navigation = useNavigate();
  const handleNavigate = () => {
    navigation.navigate(navigateLink);
  };
  return (
    <TouchableOpacity onPress={handleNavigate} style={styles.container}>
      <Text style={styles.selectLabel}>{label}</Text>
      <View style={styles.iconWrapper}>
        <Image source={Images.CARET_LEFT} style={styles.image} />
      </View>
    </TouchableOpacity>
  );
};

export default MySelectionItem;
