import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MySelectionItem from './MySelectionItem';
import {routers} from '@assets/constants/routers';
const MySelectionList = () => {
  const data = [
    {
      label: 'Thong tin tai khoan',
      navigate: routers.DETAIL_USER_ACCOUNT,
    },
    {
      label: 'Kết nối mạng xã hội',
      navigate: routers.CONNECT_SOCIAL,
    },
    {
      label: 'Sổ địa chỉ',
      navigate: routers.ADDRESS_INFORMATION,
    },
    {
      label: 'Thiết lập thông báo',
      navigate: routers.SETTING_NOTIFICATION,
    },
  ];
  return (
    <View style={styles.container}>
      {data.map((item, index) => {
        return (
          <MySelectionItem
            key={index}
            navigateLink={item.navigate}
            label={item.label}
          />
        );
      })}
    </View>
  );
};

export default MySelectionList;
