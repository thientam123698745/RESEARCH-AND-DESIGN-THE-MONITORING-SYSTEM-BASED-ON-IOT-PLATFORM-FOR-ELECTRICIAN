import {fonts, fontSize} from '@assets/fonts';
import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: colors.red,
    width: '90%',
    borderRadius: MetricSizes.P_10,
    marginBottom: MetricSizes.P_20,
  },
  text: {
    color: colors.red,
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
});
