import {Text, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {removeValue} from '@store/auth/service/accessToken';
import {useDispatch} from 'react-redux';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import {AuthSaga} from '@store/auth/shared/saga';

const MyLogoutButton = () => {
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const dispatch = useDispatch();
  const removeDataValue = async () => {
    removeValue().then(() => {
      dispatch(AuthSlice.actions.logOut());
    });
  };
  const handleLogout = () => {
    removeDataValue();
  };
  return (
    <TouchableOpacity onPress={handleLogout} style={styles.container}>
      <Text style={styles.text}>ĐĂNG XUẤT</Text>
    </TouchableOpacity>
  );
};

export default MyLogoutButton;
