import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

import useNavigate from '@hooks/useNavigate';
const MyHeader = () => {
  const navigation = useNavigate();
  const handleReturn = () => {
    navigation.goBack();
  };
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleReturn} style={styles.imageWrapper}>
        <Image source={Images.CARET_RIGHT} style={styles.image} />
      </TouchableOpacity>
      <View style={styles.labelWrapper}>
        <Text style={styles.labelText}>Thiet Lap Tai Khoan</Text>
      </View>
    </View>
  );
};

export default MyHeader;
