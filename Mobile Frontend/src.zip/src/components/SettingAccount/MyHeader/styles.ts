import MetricSizes from 'assets/constants/MetricSizes';
import {colors} from 'assets/colors';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    alignContent: 'center',
    flexDirection: 'row',

    borderWidth: 1,

    width: '100%',
    backgroundColor: colors.primary,
  },
  imageWrapper: {
    position: 'absolute',
    left: MetricSizes.P_10,
  },
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  labelWrapper: {},
  labelText: {
    color: colors.white,
  },
});
