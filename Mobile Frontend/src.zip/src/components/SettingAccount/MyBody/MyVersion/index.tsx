import {View, Text} from 'react-native';
import React from 'react';
import {styles} from './styles';
const MyVersion = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.text}>Phien Ban</Text>
      <Text style={styles.version}>1.0.1</Text>
    </View>
  );
};

export default MyVersion;
