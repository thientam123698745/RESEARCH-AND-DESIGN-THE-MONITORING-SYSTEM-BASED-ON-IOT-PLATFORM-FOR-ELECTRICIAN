import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts, fontSize} from 'assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    padding: MetricSizes.P_10 * 1.5,
    marginTop: MetricSizes.P_10,
    borderBottomWidth: 1,
    borderColor: colors.grey,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10 * 1.4,
    color: colors.blackText,
  },
  version: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10 * 1.4,
    color: colors.grey,
  },
});
