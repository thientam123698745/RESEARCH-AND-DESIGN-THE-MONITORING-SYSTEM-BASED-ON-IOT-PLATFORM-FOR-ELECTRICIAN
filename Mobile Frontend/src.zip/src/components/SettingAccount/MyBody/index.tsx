import {View} from 'react-native';
import React from 'react';
import MySelectionList from '../MySelectionList';
import {styles} from './styles';
import MyVersion from './MyVersion';
const MyBody = () => {
  return (
    <View style={styles.container}>
      <MySelectionList />
      <MyVersion />
    </View>
  );
};

export default MyBody;
