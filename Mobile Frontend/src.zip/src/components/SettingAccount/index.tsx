import React from 'react';
import {styles} from './styles';
import MyHeader from './MyHeader';
import {SafeAreaView} from 'react-native-safe-area-context';
import MyBody from './MyBody';
import MyLogoutButton from './MyLogoutButton';

const SettingAccount = () => {
  return (
    <SafeAreaView style={styles.container}>
      <MyHeader />
      <MyBody />
      <MyLogoutButton />
    </SafeAreaView>
  );
};

export default SettingAccount;
