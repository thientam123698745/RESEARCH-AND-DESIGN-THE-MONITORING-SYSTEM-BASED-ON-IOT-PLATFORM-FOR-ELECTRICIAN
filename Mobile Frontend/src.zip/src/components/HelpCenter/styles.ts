import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {},
  title: {
    height: WINDOW_HEIGHT * 0.1,
    borderWidth: 1,
    justifyContent: 'center',
    borderColor: colors.grey,
    paddingHorizontal: MetricSizes.P_10,
  },
});
