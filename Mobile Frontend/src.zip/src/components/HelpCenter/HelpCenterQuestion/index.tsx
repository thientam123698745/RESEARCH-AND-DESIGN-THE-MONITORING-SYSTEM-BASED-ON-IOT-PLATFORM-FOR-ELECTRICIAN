import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';

const HelpCenterQuestion = ({text}: {text: string}) => {
  const navigation = useNavigate();
  const handleNavigate = () => {
    navigation.navigate(routers.HELP_CENTER_DETAIL);
  };
  return (
    <TouchableOpacity onPress={handleNavigate} style={styles.container}>
      <View style={styles.textWrapper}>
        <Text type="small" color={colors.blackText}>
          {text}
        </Text>
      </View>

      <View style={styles.imgWrapper}>
        <Image style={styles.img} source={Images.CARET_LEFT} />
      </View>
    </TouchableOpacity>
  );
};

export default HelpCenterQuestion;
