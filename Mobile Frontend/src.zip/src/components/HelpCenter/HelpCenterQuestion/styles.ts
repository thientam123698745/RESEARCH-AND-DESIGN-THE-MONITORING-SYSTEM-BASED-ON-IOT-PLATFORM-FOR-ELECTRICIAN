import MetricSizes from '@assets/constants/MetricSizes';
import {WINDOW_HEIGHT} from '@assets/constants';
import {StyleSheet} from 'react-native';
import {colors} from '@assets/colors';

export const styles = StyleSheet.create({
  container: {
    height: WINDOW_HEIGHT * 0.1,
    borderWidth: 1,
    borderColor: colors.grey,
    flexDirection: 'row',
    alignItems: 'center',
  },
  textWrapper: {
    width: '90%',
  },
  imgWrapper: {
    width: '10%',
  },
  img: {
    width: MetricSizes.P_20 * 1.5,
    height: MetricSizes.P_20 * 1.5,
    resizeMode: 'stretch',
  },
});
