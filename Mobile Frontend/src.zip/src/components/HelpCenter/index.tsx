import {View, ScrollView} from 'react-native';
import React from 'react';
import {styles} from './styles';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import SquareHeader from '@components/Header/SquareHeader';
import {colors} from '@assets/colors';
import HelpCenterQuestion from './HelpCenterQuestion';
import Text from '@components/common/Texts/Text';
const HelpCenter = () => {
  const data = [
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
    {
      text: '[Lorem ipsum] dolor sit amet, consectetur adipiscing elit. Turpis erat id ut at?',
    },
  ];
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <SquareHeader navigation={navigation} text="help_privacy" />

      <ScrollView>
        <View style={styles.title}>
          <Text type="small" color={colors.blackText} isBold>
            question_popular
          </Text>
        </View>
        {data.map((item, index) => (
          <HelpCenterQuestion key={index} text={item.text} />
        ))}
      </ScrollView>
    </View>
  );
};

export default HelpCenter;
