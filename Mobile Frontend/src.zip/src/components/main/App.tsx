import React, {useEffect} from 'react';
import SplashScreen from 'react-native-splash-screen';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import * as Components from '@components/index';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import * as AuthSelector from '@store/auth/shared/selector';
import {AuthSaga} from '@store/auth/shared/saga';
import {useSelector} from 'react-redux';
import 'src/translations';
import {RouterParamList} from 'src/types/RouterParamList';
import {routers} from '@assets/constants/routers';
import {options} from '@assets/constants/options';
import MyBottomTabs from '@components/common/Navigations/MyBottomTabs';
import NotificationModal, {
  useCheckError,
} from '@components/common/NotificationModal/NotificationModal';

const Stack = createNativeStackNavigator<RouterParamList>();
export default function App() {
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });

  const token = useSelector(AuthSelector.selectToken);
  useEffect(() => {
    SplashScreen.hide();
  }, []);
  useCheckError();
  return (
    <>
      <NavigationContainer>
        <Stack.Navigator initialRouteName={routers.SPLASH_SCREEN}>
          {token === null ? (
            <>
              <Stack.Screen
                name={routers.SPLASH_SCREEN}
                component={Components.SplashScreen}
                options={options.HIDE_LABEL}
              />
              <Stack.Screen
                name={routers.LOGIN_PAGE}
                component={Components.LoginPage}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.WELCOME_PAGE}
                component={Components.WelcomePage}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.REGISTER}
                component={Components.Register}
                options={options.SHOW_HEADER}
              />
              <Stack.Screen
                name={routers.FORGOT_PASSWORD_PAGE_ENTER_PHONE}
                component={Components.ForgotPasswordPageEnterPhone}
                options={options.SHOW_HEADER}
              />
              <Stack.Screen
                name={routers.FORGOT_PASSWORD_PAGE}
                component={Components.ForgotPasswordPage}
                options={options.SHOW_HEADER}
              />
              <Stack.Screen
                name={routers.OTP_FORGOT_PASSWORD_PAGE}
                component={Components.OTPForgotPasswordPage}
                options={options.SHOW_HEADER}
              />
              <Stack.Screen
                name={routers.OTP_PAGE}
                component={Components.OTPPage}
                options={options.SHOW_HEADER}
              />
            </>
          ) : (
            <>
              <Stack.Screen
                name={routers.BOTTOM_TABS}
                component={MyBottomTabs}
                options={options.HIDE_HEADER}
              />

              <Stack.Screen
                name={routers.ADDRESS_SEARCHING_OF_RECEIVER}
                component={Components.AddressSearchingOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_SEARCHING_OF_SENDER}
                component={Components.AddressSearchingOfSender}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_SEARCHING_UPDATE_OF_RECEIVER}
                component={Components.AddressSearchingUpdateOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_SEARCHING_UPDATE_OF_SENDER}
                component={Components.AddressSearchingUpdateOfSender}
                options={options.HIDE_HEADER}
              />

              <Stack.Screen
                name={routers.ADDRESS_LOCATION_OF_RECEIVER}
                component={Components.AddressLocationOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_LOCATION_OF_SENDER}
                component={Components.AddressLocationOfSender}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_LOCATION_UPDATE_OF_RECEIVER}
                component={Components.AddressLocationUpdateOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_LOCATION_UPDATE_OF_SENDER}
                component={Components.AddressLocationUpdateOfSender}
                options={options.HIDE_HEADER}
              />

              <Stack.Screen
                name={routers.ADDRESS_INFORMATION_OF_RECEIVER}
                component={Components.AddressInformationOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_INFORMATION_OF_SENDER}
                component={Components.AddressInformationOfSender}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_INFORMATION_UPDATE_OF_RECEIVER}
                component={Components.AddressInformationUpdateOfReceiver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_INFORMATION_UPDATE_OF_SENDER}
                component={Components.AddressInformationUpdateOfSender}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ORDER_MENU}
                component={Components.OrderMenu}
                options={options.HIDE_HEADER}
              />

              <Stack.Screen
                name={routers.BOOKING_TRACKING_DRIVER}
                component={Components.BookingTrackingDriver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.BOOKING_FINISH}
                component={Components.BookingFinish}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.BOOKING_SHIPMENT_DETAIL}
                component={Components.BookingShipmentDetail}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.BOOKING_SUCCESS}
                component={Components.BookingSuccess}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_EMAIL}
                component={Components.ChangeEmail}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.PAYMENT_METHOD}
                component={Components.PaymentMethod}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.INTRODUCE_FRIENDS}
                component={Components.IntroduceFriends}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.SECURITY_CENTER}
                component={Components.SecurityCenter}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CONNECT_SOCIAL}
                component={Components.ConnectSocial}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.ADDRESS_INFORMATION}
                component={Components.AddressInformation}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_FULL_NAME}
                component={Components.ChangeFullName}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.BILLING_DETAIL}
                component={Components.BillingDetail}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.FINDING_DRIVER}
                component={Components.FindingDriver}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_NICK_NAME}
                component={Components.ChangeNickname}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_BIRTH}
                component={Components.ChangeBirth}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_GENDER}
                component={Components.ChangeGender}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_PHONE}
                component={Components.ChangePhone}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.CHANGE_PASSWORD}
                component={Components.ChangePassword}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.DETAIL_USER_ACCOUNT}
                component={Components.DetailUserAccount}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.SETTING_ACCOUNT}
                component={Components.SettingAccount}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.SETTING_NOTIFICATION}
                component={Components.SettingNotification}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.HELP_CENTER}
                component={Components.HelpCenter}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.HELP_CENTER_DETAIL}
                component={Components.HelpCenterDetail}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.PROFILE_PAGE}
                component={Components.ProfilePage}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.TRANSFER_TRUCK_PAGE}
                component={Components.TransferTruckPage}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.PREVIEW_PAGE}
                component={Components.PreviewPage}
                options={options.HIDE_HEADER}
              />
              <Stack.Screen
                name={routers.SELL_PAGE}
                component={Components.SellPage}
                options={options.HIDE_HEADER}
              />
            </>
          )}
        </Stack.Navigator>
      </NavigationContainer>
      <NotificationModal />
    </>
  );
}
