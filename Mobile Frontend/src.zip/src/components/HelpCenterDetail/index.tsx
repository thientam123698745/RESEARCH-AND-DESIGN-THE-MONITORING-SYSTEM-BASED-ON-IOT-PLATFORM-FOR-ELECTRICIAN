import {View} from 'react-native';
import React from 'react';
import SquareHeader from '@components/Header/SquareHeader';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';

const HelpCenterDetail = () => {
  const navigation = useNavigate();
  return (
    <View>
      <TransStatusBar />
      <SquareHeader navigation={navigation} text="Chính sách trợ giúp" />
    </View>
  );
};

export default HelpCenterDetail;
