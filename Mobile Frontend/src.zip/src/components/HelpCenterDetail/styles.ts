import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    padding: MetricSizes.P_10,
    justifyContent: 'space-evenly',
  },
  option: {
    borderRadius: 15,
    borderWidth: 1,
    width: '45%',
    marginVertical: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_10,
  },
  optionWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  reaction: {
    flexDirection: 'row',
  },
  react: {
    borderRadius: 15,
    borderWidth: 1,
    width: '25%',
    marginRight: MetricSizes.P_10,
    marginVertical: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_10,
  },
});
