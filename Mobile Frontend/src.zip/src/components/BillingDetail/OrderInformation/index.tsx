import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {
  selectType,
  selectOption,
  selectWeight,
  selectTime,
} from '@store/bookingTruckOrder/shared/selector';
import {useSelector} from 'react-redux';
import Text from '@components/common/Texts/Text';
import OrderInformationItem from '@components/BillingDetail/OrderInformation/OrderInformationItem';
const OrderInformation = () => {
  const type = useSelector(selectType);
  const option = useSelector(selectOption);
  const weight = useSelector(selectWeight);
  const time = useSelector(selectTime);

  return (
    <View style={styles.container}>
      <Text type="small">Hello</Text>
      <OrderInformationItem title={type} content={type} />
    </View>
  );
};

export default OrderInformation;
