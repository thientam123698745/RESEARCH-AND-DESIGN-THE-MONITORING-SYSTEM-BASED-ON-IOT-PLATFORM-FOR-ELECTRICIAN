import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import Text from '@components/common/Texts/Text';
interface Props {
  title: string;
  content: string;
}
const OrderInformationItem = ({title, content}: Props) => {
  return (
    <View style={styles.container}>
      <Text type="small">{title}</Text>
      <Text type="small">{content}</Text>
    </View>
  );
};
export default OrderInformationItem;
