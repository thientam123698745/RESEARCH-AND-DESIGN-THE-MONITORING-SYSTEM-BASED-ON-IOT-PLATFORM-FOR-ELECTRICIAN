import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';

const WarningMessage = () => {
  return (
    <View style={styles.container}>
      <View style={styles.warning}>
        <Text type="small" isBold>
          billing_detail.warning
        </Text>
        <View style={styles.context}>
          <Text color={colors.grey} type="tiny">
            billing_detail.warning_2
          </Text>
        </View>
      </View>
      <Text type="small" style={styles.text}>
        billing_detail.privacy
      </Text>
    </View>
  );
};

export default WarningMessage;
