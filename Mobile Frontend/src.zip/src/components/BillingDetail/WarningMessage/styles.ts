import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    paddingVertical: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10,
    marginTop: MetricSizes.P_10,
    backgroundColor: colors.white,
  },
  warning: {
    borderRadius: MetricSizes.P_10,
    paddingVertical: MetricSizes.P_10,
  },
  context: {},
  text: {
    paddingTop: MetricSizes.P_10,
  },
});
