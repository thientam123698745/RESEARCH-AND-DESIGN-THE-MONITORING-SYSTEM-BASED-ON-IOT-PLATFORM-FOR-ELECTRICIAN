import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {},
  titleWrapper: {
    padding: MetricSizes.small,
  },
  titleText: {},
  dotWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  textWrapper: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: MetricSizes.regular,
  },
  titleImage: {
    width: MetricSizes.big,
    height: undefined,
    aspectRatio: 1,
    resizeMode: 'contain',
    alignItems: 'center',
  },
  headerView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  userWrapper: {
    padding: MetricSizes.small,
    flexDirection: 'row',
    alignItems: 'center',
  },
  userAvtWrapper: {
    width: '10%',
  },
  userAvtImage: {
    width: '100%',
    height: undefined,
    aspectRatio: 1,
    resizeMode: 'stretch',
  },
  userTextWrapper: {
    paddingHorizontal: MetricSizes.big,
  },
  addressView: {
    padding: MetricSizes.small,
  },
  addressTitleView: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  addressContentView: {},
  noteAddress: {
    padding: MetricSizes.small,
    flexDirection: 'row',
    alignItems: 'center',
  },
  noteTextView: {
    paddingHorizontal: MetricSizes.regular,
  },
});
