import {Image, View} from 'react-native';
import React from 'react';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {
  selectRecipients,
  selectSenderAddress,
} from '@store/bookingTruckOrder/shared/selector';
import {styles} from './styles';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
import {TouchableRipple} from 'react-native-paper';
import {Images} from '@assets/constants/images';
interface Props {
  type: 'sender' | 'receiver';
}

const AddressList = ({type}: Props) => {
  useBookingInjector();
  const [open, setOpen] = React.useState(false);
  const arr_type = type === 'receiver' ? selectRecipients : selectSenderAddress;
  const address = useSelector(arr_type)[0];
  function handleOpen() {
    setOpen(!open);
  }
  return (
    <View style={styles.container}>
      <TouchableRipple
        onPress={handleOpen}
        rippleColor={colors.blackText}
        style={styles.titleWrapper}>
        <View style={styles.headerView}>
          <View style={styles.dotWrapper}>
            <Image source={Images.LOCATION_DOT} style={styles.titleImage} />
          </View>
          <View style={styles.textWrapper}>
            <Text
              type="small"
              color={colors.primary}
              isBold
              style={styles.titleText}>
              {type === 'receiver'
                ? 'address_title_sender'
                : 'address_title_receiver'}
            </Text>
          </View>
          <View style={styles.dotWrapper}>
            <Image
              source={open ? Images.CARET_DOWN : Images.CARET_UP}
              style={styles.titleImage}
            />
          </View>
        </View>
      </TouchableRipple>
      <View style={styles.userWrapper}>
        <View style={styles.userAvtWrapper}>
          <Image source={Images.USER_ICON} style={styles.userAvtImage} />
        </View>
        <View style={styles.userTextWrapper}>
          <Text type="regular" isBold>
            {address ? address.recName : ''}
          </Text>
          <Text type="small">{address ? address.phone : ''}</Text>
        </View>
      </View>
      {open ? (
        <View>
          <View style={styles.addressView}>
            <View style={styles.addressTitleView}>
              <Image source={Images.ADDRESS_ICON} style={styles.titleImage} />
              <View style={styles.noteTextView}>
                <Text type="small" isBold>
                  where_to_get
                </Text>
              </View>
            </View>
            <View style={styles.addressContentView}>
              <Text type="small" isTruncated>
                {address ? address.shortAddress : ''}
              </Text>
            </View>
          </View>
          <View style={styles.noteAddress}>
            <Image source={Images.NOTEBOOK} style={styles.titleImage} />
            <View style={styles.noteTextView}>
              <Text type="small" isTruncated>
                {address ? address.noteAddress : ''}
              </Text>
            </View>
          </View>
        </View>
      ) : (
        <></>
      )}
    </View>
  );
};

export default AddressList;
