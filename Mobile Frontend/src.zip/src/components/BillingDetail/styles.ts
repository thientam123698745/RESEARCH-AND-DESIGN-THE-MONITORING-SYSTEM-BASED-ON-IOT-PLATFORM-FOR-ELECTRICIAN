import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
import {WINDOW_HEIGHT} from '@assets/constants';

export const styles = StyleSheet.create({
  background: {
    height: WINDOW_HEIGHT * 0.3,
    justifyContent: 'flex-end',
  },
  headerWrapper: {
    backgroundColor: '#ffc206',
  },
  wrapper: {margin: MetricSizes.P_20},
  img: {
    height: '100%',
  },
  container: {
    height: '100%',
    backgroundColor: colors.white,
  },
  informationWrapper: {
    paddingHorizontal: MetricSizes.big * 2,
    minHeight: WINDOW_HEIGHT * 0.8,
    padding: MetricSizes.regular,
  },
  linearWrapper: {
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_20,
  },
  imageWrapper: {
    width: '20%',
  },
  nowImage: {
    width: '100%',
    height: undefined,
    aspectRatio: 1,
    resizeMode: 'contain',
  },
  button: {
    paddingHorizontal: MetricSizes.regular,
  },
});
