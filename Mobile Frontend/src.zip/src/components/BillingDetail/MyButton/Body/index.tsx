import {View, Image, Text as RNText} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import {TouchableOpacity} from 'react-native';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {
  selectPickedTrucks,
  selectVoucher,
} from '@store/bookingTruckOrder/shared/selector';
import {useTranslation} from 'react-i18next';
import Text from '@components/common/Texts/Text';
import formatMoney from 'src/utils/formatMoney';
const Body = () => {
  useBookingInjector();
  const {t} = useTranslation();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const total =
    pickedTrucks.reduce(
      (pac: any, a: any) => pac + a.truck.price * a.quantity,
      0,
    ) * 1000;
  const voucher = useSelector(selectVoucher) * total;

  const [visible, setVisible] = useState(true);
  function handleVisible() {
    setVisible(!visible);
  }
  function _renderItem(item: any) {
    return (
      <View key={item.id} style={styles.renderItem}>
        <Text type="small" style={styles.name}>
          {item.truck.name}
        </Text>
        <Text type="small" style={styles.money}>
          {`${formatMoney(item.truck.price * item.quantity * 1000)}  ${t(
            'booking_tracking_driver.vnd',
          )}`}
        </Text>
      </View>
    );
  }
  return (
    <View style={styles.wrapper}>
      {visible ? (
        <View>{pickedTrucks.map((item: any) => _renderItem(item))}</View>
      ) : (
        <></>
      )}
      <TouchableOpacity onPress={handleVisible} style={styles.totalContainer}>
        <View style={styles.total}>
          <View style={styles.text}>
            <Text type="small" isBold>
              booking_tracking_driver.total
            </Text>
          </View>
          <Image style={styles.img} source={Images.CARET_UP} />
        </View>

        <RNText>
          <Text type="regular">{`${formatMoney(total)}`}</Text>
          <Text type="regular">{t('booking_tracking_driver.vnd')}</Text>
        </RNText>
      </TouchableOpacity>
      <View style={styles.container}>
        <View style={styles.voucherWrapper}>
          <View style={styles.total}>
            <View style={styles.text}>
              <Text type="small" color={colors.red}>
                booking_tracking_driver.sales
              </Text>
            </View>
          </View>

          <Text type="regular" color={colors.red}>
            {`- ${formatMoney(voucher)} ${t('booking_tracking_driver.vnd')}`}
          </Text>
        </View>
        <View style={styles.totalWrapper}>
          <View style={styles.total}>
            <View style={styles.text}>
              <Text type="regular">voucher.money</Text>
            </View>
          </View>

          <Text type="regular">
            {`${formatMoney(total - voucher)} ${t(
              'booking_tracking_driver.vnd',
            )}`}
          </Text>
        </View>
      </View>
    </View>
  );
};

export default Body;
