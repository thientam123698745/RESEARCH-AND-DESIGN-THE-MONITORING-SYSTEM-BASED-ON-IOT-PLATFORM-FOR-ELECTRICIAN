import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  wrapper: {
    width: '100%',
    paddingVertical: MetricSizes.P_10,
  },
  name: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_16,
  },
  money: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_24,
    fontWeight: 'bold',
  },
  renderItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: MetricSizes.P_10,
  },
  container: {
    width: '100%',
  },
  totalContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: MetricSizes.P_10,
    alignItems: 'center',
  },
  total: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  text: {
    paddingRight: MetricSizes.P_10,
    color: colors.blackText,
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 2 / 1,
    resizeMode: 'stretch',
  },
  totalWrapper: {
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  voucherWrapper: {
    borderTopWidth: 1,
    borderTopColor: colors.grey,
    // borderWidth: 1,
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
