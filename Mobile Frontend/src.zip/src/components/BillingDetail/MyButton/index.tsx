import {View, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './style';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectPickedTrucks} from '@store/bookingTruckOrder/shared/selector';
import {colors} from '@assets/colors';
import Body from '@components/BillingDetail/MyButton/Body';
import Header from '@components/BillingDetail/MyButton/Header';
import Text from '@components/common/Texts/Text';

const MyButton = ({
  handleVisible,
  handleContinue,
}: {
  handleVisible: Function;
  handleContinue: any;
}) => {
  useBookingInjector();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const isFillAllInformation = pickedTrucks.length !== 0;
  return (
    <View style={styles.container}>
      {isFillAllInformation ? (
        <>
          <Header handleVisible={handleVisible} />
          <Body />
        </>
      ) : (
        <></>
      )}
      <TouchableOpacity
        onPress={handleContinue}
        style={[
          styles.button,
          {
            backgroundColor: isFillAllInformation
              ? colors.primary
              : colors.grey,
          },
        ]}
        disabled={!isFillAllInformation}>
        <Text
          type="small"
          isCenter
          isBold
          color={isFillAllInformation ? colors.white : colors.blackText}>
          button.continue
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default MyButton;
