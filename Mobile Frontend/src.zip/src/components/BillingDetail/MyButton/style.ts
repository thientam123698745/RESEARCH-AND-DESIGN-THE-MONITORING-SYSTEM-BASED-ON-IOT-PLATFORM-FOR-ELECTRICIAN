import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
import {fonts} from '@assets/fonts';
import {WINDOW_WIDTH} from '@assets/constants';

const styles = StyleSheet.create({
  container: {
    // position: 'absolute',
    bottom: 0,
    zIndex: 2,
    width: WINDOW_WIDTH,
    padding: MetricSizes.P_20,
    backgroundColor: colors.white,
    justifyContent: 'center',
    alignItems: 'center',
    borderTopRightRadius: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
  },
  button: {
    padding: MetricSizes.P_10,
    width: '100%',
    margin: MetricSizes.P_20,
    backgroundColor: colors.grey,
    justifyContent: 'center',
    alignContent: 'center',
    borderRadius: MetricSizes.P_10,
  },
  text: {
    textAlign: 'center',
  },
});
export default styles;
