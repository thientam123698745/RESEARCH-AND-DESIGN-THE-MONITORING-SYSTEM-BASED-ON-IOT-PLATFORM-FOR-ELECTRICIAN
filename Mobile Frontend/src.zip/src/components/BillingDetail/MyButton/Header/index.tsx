import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
const Header = ({handleVisible}: {handleVisible: any}) => {
  const navigation = useNavigate();
  function handlePayment() {
    navigation.navigate(routers.PAYMENT_METHOD);
  }
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handlePayment} style={styles.payment}>
        <Image style={styles.img} source={Images.WALLET_MIN} />
        <View style={styles.text}>
          <Text type="small" isBold>
            cash
          </Text>
        </View>
        <Image style={styles.img} source={Images.CARET_LEFT} />
      </TouchableOpacity>
      <TouchableOpacity onPress={handleVisible} style={styles.voucher}>
        <Image style={styles.img} source={Images.STAR_VOUCHER} />
        <Text type="small" isBold>
          voucher.use_voucher
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default Header;
