import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  payment: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  text: {
    paddingHorizontal: MetricSizes.P_10,
  },
  voucher: {
    borderWidth: 1,
    borderRadius: MetricSizes.P_10,
    padding: MetricSizes.P_10 * 0.5,
    flexDirection: 'row',
    alignItems: 'center',
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  container: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    paddingVertical: MetricSizes.P_10,
  },
});
