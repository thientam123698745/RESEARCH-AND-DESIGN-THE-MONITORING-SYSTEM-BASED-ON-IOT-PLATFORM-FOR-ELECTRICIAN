import {View, ImageBackground, ScrollView, Image} from 'react-native';
import React, {useState} from 'react';
import useNavigate from '@hooks/useNavigate';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import {colors, linear_gradient} from '@assets/colors';
import LinearGradient from 'react-native-linear-gradient';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import WarningMessage from '@components/BillingDetail/WarningMessage';
import Vouchers from '@components/BillingDetail/Vouchers';
import MyButton from '@components/BillingDetail/MyButton';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import AddressList from '@components/BillingDetail/AddressList';
import MyOrderInformation from '@components/OrderMenu/MyOrderInformation';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectAdded,
  selectHeight,
  selectLong,
  selectOption,
  selectPaymentMethod,
  selectRecipients,
  selectSearchingLoading,
  selectSenderAddress,
  selectTime,
  selectTrucks,
  selectType,
  selectVoucher,
  selectWeight,
  selectWidth,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckSLice from '@store/bookingTruckOrder/shared/slice';
import {ActivityIndicator} from 'react-native-paper';
const BillingDetail = () => {
  useBookingInjector();
  const navigation = useNavigate();
  const [visible, setVisible] = useState(false);
  const recAddress = useSelector(selectRecipients);
  const senderAddress = useSelector(selectSenderAddress);
  const time = useSelector(selectTime);
  const typeOfShipment = useSelector(selectType);
  const manual = useSelector(selectOption);
  const length = useSelector(selectLong);
  const width = useSelector(selectWidth);
  const weight = useSelector(selectWeight);
  const height = useSelector(selectHeight);
  const trucks = useSelector(selectTrucks);
  const payment = useSelector(selectPaymentMethod);
  const voucher = useSelector(selectVoucher);
  const isLoading = useSelector(selectSearchingLoading);
  const isAdded = useSelector(selectAdded);
  const dispatch = useDispatch();
  React.useEffect(() => {
    if (isAdded) {
      dispatch(BookingTruckSLice.actions.setAdded());
      navigation.navigate(routers.FINDING_DRIVER);
    }
  }, [isAdded]);

  function handleVisible() {
    setVisible(!visible);
  }
  function handleContinue() {
    dispatch(
      BookingTruckSLice.actions.addOrder({
        recAddress,
        senderAddress,
        time,
        typeOfShipment,
        manual,
        size: {weight, length, width, height},
        trucks,
        payment,
        fee: '30000',
        voucher,
        shipment_id: 3,
      }),
    );
  }
  return isLoading ? (
    <View style={styles.container}>
      <ActivityIndicator />
    </View>
  ) : (
    <View style={styles.container}>
      <View style={styles.headerWrapper}>
        <MediumLogoHeader
          text="booking_tracking_driver.header"
          navigation={navigation}
        />
      </View>
      <ScrollView showsVerticalScrollIndicator={false}>
        <ImageBackground
          resizeMode={'stretch'}
          style={styles.background}
          imageStyle={styles.img}
          source={Images.BILLING_BACKGROUND}>
          <LinearGradient colors={linear_gradient.transShadow}>
            <View style={styles.linearWrapper}>
              <View style={styles.imageWrapper}>
                <Image source={Images.NOW} style={styles.nowImage} />
              </View>
              <View style={styles.wrapper}>
                <Text type="small" isBold color={colors.white}>
                  booking_tracking_driver.title
                </Text>
                <Text type="tiny" color={colors.white}>
                  booking_tracking_driver.time
                </Text>
              </View>
            </View>
          </LinearGradient>
        </ImageBackground>
        <View style={styles.informationWrapper}>
          <AddressList type="receiver" />
          <AddressList type="sender" />
          <MyOrderInformation disabled={true} />
          <WarningMessage />
        </View>
        <MyButton
          handleVisible={handleVisible}
          handleContinue={handleContinue}
        />
      </ScrollView>
      <Vouchers visible={visible} setVisible={setVisible} />
    </View>
  );
};

export default BillingDetail;
