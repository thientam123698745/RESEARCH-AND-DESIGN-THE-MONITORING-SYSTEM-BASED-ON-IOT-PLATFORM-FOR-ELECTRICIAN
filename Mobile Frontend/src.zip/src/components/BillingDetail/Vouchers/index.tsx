import {
  View,
  Modal,
  TouchableOpacity,
  Image,
  TextInput,
  ImageBackground,
} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {ScrollView} from 'react-native-gesture-handler';
import {colors} from '@assets/colors';
import {VOUCHER_DATA} from '@assets/data';
import {useDispatch} from 'react-redux';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
import {useTranslation} from 'react-i18next';
const Vouchers = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: Function;
}) => {
  const {t} = useTranslation();
  const voucher = VOUCHER_DATA;
  const length = voucher.length;
  const dispatch = useDispatch();
  function handleVisible() {
    setVisible(!visible);
  }
  function handleSaveVoucher(value: number) {
    dispatch(BookingTruckOrderSlice.actions.setVoucher(value));
    handleVisible();
  }
  return (
    <Modal statusBarTranslucent visible={visible}>
      <TransStatusBar color="dark-content" />
      <View style={styles.container}>
        <View style={styles.headerWrapper}>
          <View style={styles.header}>
            <TouchableOpacity style={styles.close} onPress={handleVisible}>
              <Image source={Images.CLOSE_BUTTON} style={styles.img} />
            </TouchableOpacity>
            <Text type="small">order_menu.my_prior</Text>
          </View>
          <View style={styles.search}>
            <TextInput placeholder={t('voucher.input_voucher')} />
          </View>
        </View>
        <View style={styles.body}>
          {length === 0 ? (
            <View style={styles.noVoucherWrapper}>
              <Image source={Images.NO_VOUCHER} style={styles.imgNoVOucher} />
              <Text type="regular" color={colors.grey}>
                voucher.no_voucher
              </Text>
            </View>
          ) : (
            <View style={styles.voucherWrapper}>
              <ScrollView>
                {voucher.map((item, index) => (
                  <View style={styles.itemView} key={index}>
                    <ImageBackground
                      source={Images.VOUCHER_ITEM}
                      imageStyle={styles.bgImage}
                      style={styles.imgBgWrapper}
                      resizeMode="stretch">
                      <View style={styles.itemWrapper}>
                        <View style={styles.itemHeaderWrapper}>
                          <View style={styles.voucherImgWrapper}>
                            <View style={styles.voucherImageContainer}>
                              <Image
                                source={item.image}
                                style={styles.voucherImage}
                              />
                            </View>
                          </View>
                          <View style={styles.textImgWrapper}>
                            <View style={styles.statusWrapper}>
                              <Text type="small" color={colors.orange} isBold>
                                voucher.limit
                              </Text>
                            </View>
                            <Text type="small" isBold>
                              voucher.condition
                            </Text>
                            <Text type="tiny" color={colors.grey}>
                              voucher.expire
                            </Text>
                          </View>
                        </View>
                        <View style={styles.itemBodyWrapper}>
                          <View style={styles.textBodyWrapper}>
                            <TouchableOpacity
                              onPress={() => handleSaveVoucher(item.value)}>
                              <Text type="small" color={colors.primary}>
                                button.use
                              </Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    </ImageBackground>
                  </View>
                ))}
              </ScrollView>
            </View>
          )}
        </View>
      </View>
    </Modal>
  );
};

export default Vouchers;
