import {WINDOW_WIDTH, WINDOW_HEIGHT} from '@assets/constants/index';
import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: colors.white,
  },
  close: {
    position: 'absolute',
    left: 0,
  },
  headerWrapper: {
    padding: MetricSizes.P_20,
    backgroundColor: colors.white,
    borderBottomLeftRadius: MetricSizes.P_10,
    borderBottomRightRadius: MetricSizes.P_10,
  },
  container: {
    paddingVertical: MetricSizes.P_40,
    backgroundColor: colors.borderGray,
    height: '100%',
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  body: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  search: {
    // borderWidth: 1,
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.borderGray,
    // marginHorizontal: MetricSizes.P_20,
    marginTop: MetricSizes.P_20,
    paddingHorizontal: MetricSizes.P_20,
  },
  noVoucherWrapper: {},
  imgNoVOucher: {
    resizeMode: 'stretch',
    width: WINDOW_WIDTH * 0.8,
    height: undefined,
    aspectRatio: 3 / 2,
  },
  voucherWrapper: {
    width: '100%',
    height: '100%',
  },

  itemView: {
    padding: MetricSizes.P_20,
  },
  bgImage: {
    // height: '100%',
    width: '100%',
  },
  imgBgWrapper: {
    // height: '100%',
    // borderWidth: 1,
    justifyContent: 'flex-end',
    flexDirection: 'row',
  },
  itemWrapper: {
    // borderWidth: 1,
    minHeight: WINDOW_HEIGHT * 0.15,
    paddingVertical: MetricSizes.P_10,
    paddingRight: MetricSizes.P_10,
    width: '90%',
    // flexDirection: 'row',
  },
  itemHeaderWrapper: {
    flexDirection: 'row',
  },
  itemBodyWrapper: {
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  textBodyWrapper: {
    width: '60%',
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  statusWrapper: {
    // borderWidth: 1,
    backgroundColor: '#ffe8cd',
    borderRadius: MetricSizes.P_10 * 0.5,
    padding: MetricSizes.P_10 * 0.5,
    // width: '100%',
  },
  statusText: {
    color: colors.orange,
  },
  voucherImgWrapper: {
    width: '40%',
    // borderWidth: 1,
  },
  voucherImageContainer: {
    padding: MetricSizes.P_10,
  },
  voucherImage: {
    height: undefined,
    width: '100%',
    aspectRatio: 1.333,
    resizeMode: 'stretch',
  },

  textImgWrapper: {
    width: '60%',
    // borderWidth: 1,
    paddingTop: MetricSizes.P_10,
    justifyContent: 'flex-start',
  },
  buttonImgWrapper: {
    width: '20%',
    // borderWidth: 1,
  },
});
