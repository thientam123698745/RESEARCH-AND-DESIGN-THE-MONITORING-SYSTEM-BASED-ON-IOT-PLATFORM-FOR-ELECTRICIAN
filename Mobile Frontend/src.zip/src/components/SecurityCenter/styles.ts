import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  wrapper: {
    padding: MetricSizes.P_10,
  },
});
