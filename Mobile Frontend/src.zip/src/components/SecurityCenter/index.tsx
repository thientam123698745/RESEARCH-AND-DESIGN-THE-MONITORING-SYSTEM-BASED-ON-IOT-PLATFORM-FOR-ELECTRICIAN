import {View} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import SquareHeader from '@components/Header/SquareHeader';
import {styles} from './styles';
import {ScrollView} from 'react-native-gesture-handler';
import Text from '@components/common/Texts/Text';

const SecurityCenter = () => {
  const navigation = useNavigate();
  return (
    <View>
      <TransStatusBar />
      <SquareHeader navigation={navigation} text="Trung Tâm Bảo Mật" />

      <ScrollView>
        <View style={styles.wrapper}>
          <Text type="small" color={colors.blackText}>
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla odio
            tempus morbi cursus non cursus dui. Quis nunc congue eget adipiscing
            lorem id neque. Aliquam sem egestas ac odio cum nunc, velit cras.
            Nibh etiam massa placerat vitae eu posuere. Magna nulla non volutpat
            egestas. Lacus ut feugiat nam tempus at. Id a nibh fringilla in
            dictum etiam. Sit vel quisque rhoncus eget varius purus est
            bibendum. Sit massa egestas ipsum consequat odio. Mi venenatis nulla
            elementum sed fringilla adipiscing. Accumsan ac rhoncus pellentesque
            adipiscing aliquam suspendisse mauris amet. Id viverra parturient eu
            egestas commodo erat fermentum. Ac sem duis velit lectus leo
            ultricies. Eget eu nec lacus, vestibulum viverra est. Mattis
            volutpat nunc quisque ornare dictum. Porta aenean dictum porttitor
            arcu fames maecenas phasellus lacinia. Feugiat nunc quam mauris
            velit hac imperdiet lobortis in id. Nibh ut risus id feugiat.
            Ullamcorper posuere sed rhoncus aenean."
          </Text>
          <Text type="small" color={colors.blackText}>
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla odio
            tempus morbi cursus non cursus dui. Quis nunc congue eget adipiscing
            lorem id neque. Aliquam sem egestas ac odio cum nunc, velit cras.
            Nibh etiam massa placerat vitae eu posuere. Magna nulla non volutpat
            egestas. Lacus ut feugiat nam tempus at. Id a nibh fringilla in
            dictum etiam. Sit vel quisque rhoncus eget varius purus est
            bibendum. Sit massa egestas ipsum consequat odio. Mi venenatis nulla
            elementum sed fringilla adipiscing. Accumsan ac rhoncus pellentesque
            adipiscing aliquam suspendisse mauris amet. Id viverra parturient eu
            egestas commodo erat fermentum. Ac sem duis velit lectus leo
            ultricies. Eget eu nec lacus, vestibulum viverra est. Mattis
            volutpat nunc quisque ornare dictum. Porta aenean dictum porttitor
            arcu fames maecenas phasellus lacinia. Feugiat nunc quam mauris
            velit hac imperdiet lobortis in id. Nibh ut risus id feugiat.
            Ullamcorper posuere sed rhoncus aenean."
          </Text>
          <Text type="small" color={colors.blackText}>
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla odio
            tempus morbi cursus non cursus dui. Quis nunc congue eget adipiscing
            lorem id neque. Aliquam sem egestas ac odio cum nunc, velit cras.
            Nibh etiam massa placerat vitae eu posuere. Magna nulla non volutpat
            egestas. Lacus ut feugiat nam tempus at. Id a nibh fringilla in
            dictum etiam. Sit vel quisque rhoncus eget varius purus est
            bibendum. Sit massa egestas ipsum consequat odio. Mi venenatis nulla
            elementum sed fringilla adipiscing. Accumsan ac rhoncus pellentesque
            adipiscing aliquam suspendisse mauris amet. Id viverra parturient eu
            egestas commodo erat fermentum. Ac sem duis velit lectus leo
            ultricies. Eget eu nec lacus, vestibulum viverra est. Mattis
            volutpat nunc quisque ornare dictum. Porta aenean dictum porttitor
            arcu fames maecenas phasellus lacinia. Feugiat nunc quam mauris
            velit hac imperdiet lobortis in id. Nibh ut risus id feugiat.
            Ullamcorper posuere sed rhoncus aenean."
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

export default SecurityCenter;
