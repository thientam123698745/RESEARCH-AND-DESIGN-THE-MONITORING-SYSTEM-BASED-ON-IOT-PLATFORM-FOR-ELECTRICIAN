import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {selectRecipients} from '@store/bookingTruckOrder/shared/selector';
import React from 'react';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {useSelector} from 'react-redux';
import MyTitle from './MyTitle';
import MyBody from './MyBody';
import MyButton from './MyButton';
import MyHeader from './MyHeader';
import MyReceiver from './MyReceiver';
import styles from './styles';

const AddressInformationOfReceiver = () => {
  useBookingInjector();
  const recipientAddresses = useSelector(selectRecipients);
  const {t} = useTranslation();
  const arraySize = recipientAddresses.length + 1;
  return (
    <View style={styles.container}>
      <TransStatusBar color="light-content" />
      <MyHeader />
      <View style={styles.subContainer}>
        <MyTitle text={`${t('recipient.address')} ${arraySize}`} />
        <MyBody />
        <MyTitle text={`${t('recipient.information')} ${arraySize}`} />
        <MyReceiver />
      </View>
      <MyButton />
    </View>
  );
};

export default AddressInformationOfReceiver;
