import {View, Image} from 'react-native';
import React from 'react';
import styles from './style';
import {TextInput} from 'react-native';
import {Images} from '@assets/constants/images';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {selectDisplayLocation} from '@store/bookingTruckOrder/shared/selector';
import {useTranslation} from 'react-i18next';
const MyReceiver = () => {
  const {t} = useTranslation();
  useBookingInjector();
  const dispatch = useDispatch();
  const displayAddress = useSelector(selectDisplayLocation);
  const {recName, phone, noteForDriver} = displayAddress;
  function setRecipientName(data: string) {
    dispatch(BookingTruckOrderSlice.actions.setDisplayName(data));
  }
  function setRecipientPhone(data: string) {
    dispatch(BookingTruckOrderSlice.actions.setDisplayPhone(data));
  }
  function setRecipientNote(data: string) {
    dispatch(BookingTruckOrderSlice.actions.setDisplayNote(data));
  }
  return (
    <View style={styles.receiverWrapper}>
      <View style={styles.receiverBodyWrapper}>
        <TextInput
          style={styles.textInput}
          value={recName}
          onChangeText={setRecipientName}
          placeholder={t('recipient.name')}
        />
        <TextInput
          style={styles.textInput}
          value={phone}
          onChangeText={setRecipientPhone}
          placeholder={t('recipient.phone')}
        />
        <View style={styles.noteView}>
          <View style={styles.imageWrapper}>
            <Image source={Images.NOTEBOOK} style={styles.note} />
          </View>
          <TextInput
            value={noteForDriver}
            onChangeText={setRecipientNote}
            style={styles.textInput}
            placeholder={t('recipient.note')}
          />
        </View>
      </View>
    </View>
  );
};

export default MyReceiver;
