import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  receiverWrapper: {
    height: '30%',
    paddingHorizontal: MetricSizes.P_20,
    justifyContent: 'center',
  },
  receiverButtonWrapper: {},
  receiverTitleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  receiverTitleImage: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    marginRight: MetricSizes.P_10,
  },
  receiverTitleText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
  receiverBodyWrapper: {
    justifyContent: 'flex-start',
  },
  note: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  noteView: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    // borderBottomWidth: 1,
    borderColor: colors.grey,
    // paddingVertical: MetricSizes.P_10,
  },
  textInput_note: {
    width: '90%',
    backgroundColor: colors.white,
    fontSize: fontSize.FS_10,
    padding: 0,
  },
  textInput: {
    backgroundColor: colors.white,
    fontSize: fontSize.FS_10,
    paddingVertical: 10,
    borderBottomWidth: 1,
    flexGrow: 1,
    borderColor: colors.grey,
  },
  icon: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    resizeMode: 'stretch',
  },
  receiverBodyNoteWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    justifyContent: 'center',
  },
  imageWrapper: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    // height: '100%',
  },
});
export default styles;
