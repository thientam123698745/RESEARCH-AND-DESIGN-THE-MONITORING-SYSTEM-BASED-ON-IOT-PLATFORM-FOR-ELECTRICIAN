import {View, Text, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

const MyTitle = ({text}: {text: string}) => {
  return (
    <View style={styles.container}>
      <Image source={Images.LOCATION_DOT} style={styles.img} />
      <Text style={styles.text}>{text}</Text>
    </View>
  );
};

export default MyTitle;
