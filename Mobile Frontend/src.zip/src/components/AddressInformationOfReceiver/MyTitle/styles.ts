import {fonts, fontSize} from '@assets/fonts';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  container: {
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
    // justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    paddingLeft: MetricSizes.P_10,
    fontWeight: 'bold',
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
});
