import MyOtpForm from '@components/OTPPage/MyOtpForm';
import MyTitle from '@components/OTPPage/MyTitle';
import React, {useEffect} from 'react';
import {SafeAreaView} from 'react-native';
import {styles} from './styles';
import {useSelector} from 'react-redux';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import {AuthSaga} from '@store/auth/shared/saga';
import * as AuthSelector from '@store/auth/shared/selector';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import LoadingPage from '@components/common/LoadingPage';
import {routers} from '@assets/constants/routers';
const OTPPage = () => {
  const navigation = useNavigate();
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const loading = useSelector(AuthSelector.selectLoading);
  const isSuccess = useSelector(AuthSelector.selectSuccess);
  const error = useSelector(AuthSelector.selectSignUpError);
  useEffect(() => {
    if (isSuccess) {
      navigation.navigate(routers.LOGIN_PAGE);
    }
  }, [isSuccess, navigation]);

  useEffect(() => {
    if (error) {
      navigation.goBack();
    }
  }, [error, navigation]);
  12345;
  return (
    <SafeAreaView style={styles.container}>
      {loading ? (
        <LoadingPage message="Signning Up ..." />
      ) : (
        <>
          <TransStatusBar />
          <MyTitle />
          <MyOtpForm />
        </>
      )}
    </SafeAreaView>
  );
};

export default OTPPage;
