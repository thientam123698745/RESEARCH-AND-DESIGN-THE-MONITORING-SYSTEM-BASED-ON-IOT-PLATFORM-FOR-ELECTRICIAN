import {View, Alert, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import * as AuthSlice from '@store/auth/shared/slice';
import {useDispatch, useSelector} from 'react-redux';
import * as AuthSelector from '@store/auth/shared/selector';
import useNavigate from '@hooks/useNavigate';
import {OTP_CODE} from '@assets/constants';
import {LogBox} from 'react-native';
import Text from '@components/common/Texts/Text';

LogBox.ignoreLogs([
  'ViewPropTypes will be removed',
  'ColorPropType will be removed',
]);
const MyOtpForm = () => {
  const dispatch = useDispatch();
  const navigation = useNavigate();
  const handleResend = () => {
    Alert.alert('resend button coming soon');
  };
  const handleReinputPhone = () => {
    // Alert.alert('reinput phone button');
    navigation.goBack();
  };
  const registerUser = useSelector(AuthSelector.selectRegisterUser);
  const handleSubmitCode = (code: string) => {
    if (code === OTP_CODE && registerUser.full_name) {
      dispatch(AuthSlice.actions.signUp(registerUser));
    }
  };
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text type="small">otp.question</Text>
        <TouchableOpacity onPress={handleResend}>
          <Text type="small" color={colors.orange} isUnderlined isBold>
            otp.re_input_button
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.otp_input}>
        <OTPInputView
          pinCount={6}
          autoFocusOnLoad={false}
          codeInputFieldStyle={styles.underlineStyleBase}
          codeInputHighlightStyle={styles.underlineStyleHighLighted}
          onCodeFilled={handleSubmitCode}
        />
      </View>
      <View style={styles.footer}>
        <View style={styles.imgWrapper}>
          <Image source={Images.SMALL_LONG_BUTTON} style={styles.image} />
        </View>
        <TouchableOpacity onPress={handleReinputPhone}>
          <Text type="small" color={colors.primary}>
            otp.re_input_button
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.timeWrapper}>
        <Text color={colors.grey} type="small">
          otp.time_remaining
        </Text>
        <Text type="small">{'02:00'}</Text>
      </View>
    </View>
  );
};

export default MyOtpForm;
