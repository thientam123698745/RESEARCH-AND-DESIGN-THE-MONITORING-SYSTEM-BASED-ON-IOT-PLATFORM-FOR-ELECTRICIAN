import {View, Text as RNText} from 'react-native';
import React, {useState} from 'react';
import styles from './styles';
import Text from '@components/common/Texts/Text';
const MyTitle = () => {
  const [phone] = useState('(+84) 375 9876 293');
  return (
    <View style={styles.titleWrapper}>
      <Text type="regular" isCenter>
        otp.title
      </Text>
      <RNText style={styles.text}>
        <Text type="small" isCenter>
          otp.text
        </Text>
        <Text type="small" isBold isCenter>
          {phone}
        </Text>
      </RNText>
    </View>
  );
};

export default MyTitle;
