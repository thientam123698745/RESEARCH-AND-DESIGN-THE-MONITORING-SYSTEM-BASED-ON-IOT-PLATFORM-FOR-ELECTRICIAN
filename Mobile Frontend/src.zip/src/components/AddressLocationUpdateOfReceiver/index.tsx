import {Text, View} from 'react-native';
import React from 'react';
import styles from './style';
import MyMap from './MyMap';
import MyMapInfo from './MyMapInfo';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectSearchingLoading} from '@store/bookingTruckOrder/shared/selector';
import {useAuthInjector} from '@hooks/useInjector/useAuthInjector';
const AddressLocationUpdateOfReceiver = () => {
  useBookingInjector();
  useAuthInjector();
  const isSearchingLoading = useSelector(selectSearchingLoading);

  return (
    <View style={styles.container}>
      {isSearchingLoading ? (
        <Text>Loading</Text>
      ) : (
        <>
          <MyMap />
          <MyMapInfo />
        </>
      )}
    </View>
  );
};

export default AddressLocationUpdateOfReceiver;
