import {View, Text} from 'react-native';
import React from 'react';

const SearchOrder = () => {
  return (
    <View>
      <Text>SearchOrder</Text>
    </View>
  );
};

export default SearchOrder;
