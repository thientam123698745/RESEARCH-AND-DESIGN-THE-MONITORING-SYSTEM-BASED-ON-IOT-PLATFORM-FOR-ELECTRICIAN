import {WINDOW_WIDTH} from '@assets/constants';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  illustrationsWrapper: {
    // flex: 6,
    width: '100%',
    // borderWidth: 1,
  },
  illustrationsImage: {
    resizeMode: 'stretch',
    height: undefined,
    width: WINDOW_WIDTH,
    aspectRatio: 3 / 2.1,
    // resizeMode: 'cover',
  },
});
