import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

const BigLogoHeader = () => {
  return (
    <View style={styles.illustrationsWrapper}>
      <Image
        style={styles.illustrationsImage}
        source={Images.ORANGE_BACKGROUND}
      />
    </View>
  );
};

export default BigLogoHeader;
