import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    paddingTop: MetricSizes.P_40,
    paddingBottom: MetricSizes.P_20,
    borderBottomLeftRadius: MetricSizes.P_20,
    borderBottomRightRadius: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  imgWrapper: {
    position: 'absolute',
    left: MetricSizes.P_20,
    top: MetricSizes.P_40,
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
