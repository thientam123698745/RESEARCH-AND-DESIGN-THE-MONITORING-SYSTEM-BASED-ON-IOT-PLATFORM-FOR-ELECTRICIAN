import {TouchableOpacity, Image} from 'react-native';
import React from 'react';
// import {routers} from '@assets/constants/routers';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import LinearGradient from 'react-native-linear-gradient';
import {colors, linear_gradient} from '@assets/colors';
import Text from '@components/common/Texts/Text';

const MediumLogoHeader = ({
  navigation,
  text,
  onPress,
}: {
  navigation?: any;
  text: string;
  onPress?: any;
}) => {
  const handleNavigation = () => {
    navigation.goBack();
  };
  return (
    <LinearGradient
      colors={linear_gradient.labelHeader}
      style={styles.container}>
      {onPress ? (
        <TouchableOpacity style={styles.imgWrapper} onPress={onPress}>
          <Image style={styles.img} source={Images.CLOSE_BUTTON_WHITE} />
        </TouchableOpacity>
      ) : (
        <TouchableOpacity style={styles.imgWrapper} onPress={handleNavigation}>
          <Image style={styles.img} source={Images.TT_RETURN} />
        </TouchableOpacity>
      )}
      <Text type="small" color={colors.white} isBold>
        {text}
      </Text>
    </LinearGradient>
  );
};

export default MediumLogoHeader;
