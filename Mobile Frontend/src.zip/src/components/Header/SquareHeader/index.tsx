import {TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import LinearGradient from 'react-native-linear-gradient';
import {colors, linear_gradient} from '@assets/colors';
import Text from '@components/common/Texts/Text';

const SquareHeader = ({navigation, text}: {navigation: any; text: string}) => {
  const handleNavigation = () => {
    navigation.goBack();
  };
  return (
    <LinearGradient
      colors={linear_gradient.labelHeader}
      style={styles.container}>
      <TouchableOpacity style={styles.imgWrapper} onPress={handleNavigation}>
        <Image style={styles.img} source={Images.TT_RETURN} />
      </TouchableOpacity>
      <Text type="regular" color={colors.white} isBold>
        {text}
      </Text>
    </LinearGradient>
  );
};

export default SquareHeader;
