import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {selectSearchingList} from '@store/bookingTruckOrder/shared/selector';
import React from 'react';
import {useTranslation} from 'react-i18next';
import {View} from 'react-native';
import {useSelector} from 'react-redux';
import MyTitle from './MyTitle';
import MyBody from './MyBody';
import MyButton from './MyButton';
import MyHeader from './MyHeader';
import MyReceiver from './MyReceiver';
import styles from './styles';

const AddressInformationOfSender = () => {
  useBookingInjector();
  const recipientAddresses = useSelector(selectSearchingList);
  const {t} = useTranslation();
  const arraySize = recipientAddresses.length + 1;
  return (
    <View style={styles.container}>
      <TransStatusBar color="light-content" />
      <MyHeader />
      <View style={styles.subContainer}>
        <MyTitle text={`${t('sender.address')} ${arraySize}`} />
        <MyBody />
        <MyTitle text={`${t('sender.information')} ${arraySize}`} />
        <MyReceiver />
      </View>
      <MyButton />
    </View>
  );
};

export default AddressInformationOfSender;
