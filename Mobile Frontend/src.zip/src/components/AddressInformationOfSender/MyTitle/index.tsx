import {View, Image, Text as RNText} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';

const MyTitle = ({text, index}: {text: string; index?: string}) => {
  return (
    <View style={styles.container}>
      <View style={styles.iconWrapper}>
        <Image source={Images.LOCATION_DOT} style={styles.img} />
      </View>
      <RNText>
        <Text type="small" isBold style={styles.text}>
          {text}
        </Text>
        <Text type="small" isBold style={styles.text}>
          {` ${index}`}
        </Text>
      </RNText>
    </View>
  );
};

export default MyTitle;
