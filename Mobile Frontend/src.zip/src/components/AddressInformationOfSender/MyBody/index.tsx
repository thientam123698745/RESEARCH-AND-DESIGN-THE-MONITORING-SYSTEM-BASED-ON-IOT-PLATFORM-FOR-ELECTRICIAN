import {Image, TextInput, TouchableOpacity, View} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import MapView, {Marker} from 'react-native-maps';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import {btRouters} from '@assets/constants/btRouters';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectDisplayLocation,
  selectSearchingList,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
import {useTranslation} from 'react-i18next';
const MyBody = () => {
  useBookingInjector();
  const {t} = useTranslation();
  const navigation = useNavigate();
  const displayAddress = useSelector(selectDisplayLocation);
  const {
    coord,
    shortAddress,
    detailAddress,
    apartmentFloor,
    noteAddress,
    recName,
    noteForDriver,
    phone,
  } = displayAddress;
  const addressList = useSelector(selectSearchingList);
  const {latitude, longitude} = coord;
  const handleLocation = () => {
    navigation.navigate(btRouters.BOOK_CAR);
  };
  const dispatch = useDispatch();
  const isValidate =
    apartmentFloor != null &&
    noteAddress != null &&
    recName != null &&
    noteForDriver != null &&
    phone != null;
  function setFloor(floor: string) {
    const tmpFloor = parseInt(floor, 10);
    dispatch(BookingTruckOrderSlice.actions.setDisplayFloor(tmpFloor));
  }
  function setNoteAddress(note: string) {
    if (note !== null) {
      dispatch(BookingTruckOrderSlice.actions.setDisplayNoteAddress(note));
    }
  }
  return (
    <View style={styles.container}>
      <View style={styles.bodyWrapper}>
        <View style={styles.bodyMapWrapper}>
          <MapView
            style={styles.map}
            region={{
              latitude: latitude,
              longitude: longitude,
              latitudeDelta: 0.001,
              longitudeDelta: 0.001,
            }}>
            <Marker
              coordinate={{
                latitude: latitude,
                longitude: longitude,
              }}>
              <View style={styles.markerView}>
                <Image source={Images.LOCATION2} style={styles.markerImage} />
              </View>
            </Marker>
          </MapView>
        </View>
        <View style={styles.bodyInfoWrapper}>
          <View style={styles.bodyInfoTItle}>
            <View style={styles.titleWrapper}>
              <Image
                style={styles.bodyInfoTitleIcon}
                source={Images.LOCATION}
              />
              <View style={styles.shortAddressWrapper}>
                <Text type="small" isCenter={false} isBold>
                  {shortAddress}
                </Text>
              </View>
            </View>

            <TouchableOpacity
              onPress={handleLocation}
              style={styles.bodyInfoTItleButton}>
              <Text type="tiny" style={styles.bodyInfoTitleButtonText}>
                button.change
              </Text>
            </TouchableOpacity>
          </View>
          <Text type="tiny" isCenter={false} style={styles.bodyInfoAddress}>
            {detailAddress}
          </Text>
          <View style={styles.bodyInfoApartment}>
            <Image style={styles.icon} source={Images.HOME} />
            <TextInput
              keyboardType="decimal-pad"
              placeholder={t('address_form.apartment')}
              value={apartmentFloor ? apartmentFloor + '' : ''}
              onChangeText={setFloor}
              style={styles.textInput}
            />
          </View>
          <View style={styles.bodyInfoNote}>
            <Image style={styles.icon} source={Images.NOTE} />
            <TextInput
              placeholder={t('address_form.note_address')}
              value={noteAddress}
              onChangeText={setNoteAddress}
              style={styles.textInput}
            />
          </View>
          <TouchableOpacity
            disabled={!isValidate}
            onPress={() => {
              const data = {
                list: addressList,
                address: displayAddress,
              };
              dispatch(BookingTruckOrderSlice.actions.addNewAddress(data));
              navigation.navigate(routers.ORDER_MENU);
            }}
            style={styles.bodyInfoButtonWrapper}>
            <Image style={styles.icon} source={Images.ADD} />
            <Text type="small" color={colors.primary} isBold isCenter>
              sender.button
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default MyBody;
