import {colors} from '@assets/colors';
import {WINDOW_HEIGHT, WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  receiverTitleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
  },
  receiverTitleImage: {
    width: MetricSizes.P_10,
    height: MetricSizes.P_10,
    marginRight: MetricSizes.P_10,
  },
  receiverTitleText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
  },
  container: {
    height: '60%',
    justifyContent: 'center',
  },
  map: {width: '100%', height: '100%'},
  textInput: {
    width: '100%',
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    padding: -10,
  },
  icon: {
    width: MetricSizes.P_10 * 1.5,
    height: MetricSizes.P_10 * 1.5,
    marginRight: MetricSizes.P_10,
  },
  bodyWrapper: {
    // height: '80%',
    marginHorizontal: MetricSizes.P_20,
    marginVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_10 * 0.5,
    paddingTop: MetricSizes.P_10 * 0.5,
    borderRadius: MetricSizes.P_10,
    borderColor: colors.grey,
    borderWidth: 1,
  },
  bodyMapWrapper: {
    borderRadius: MetricSizes.P_10,
    height: '40%',
  },
  bodyInfoWrapper: {
    height: '60%',
    justifyContent: 'space-around',
    paddingHorizontal: MetricSizes.P_10,
    paddingTop: MetricSizes.P_10,
  },
  bodyButtonWrapper: {
    height: WINDOW_HEIGHT * 0.1,
  },
  titleWrapper: {
    flexDirection: 'row',
    maxWidth: WINDOW_WIDTH * 0.6,
  },
  shortAddressWrapper: {
    maxWidth: '90%',
  },
  bodyInfoTItle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  bodyInfoTItleButton: {
    borderWidth: 1,
    borderColor: colors.primary,
    // paddingVertical: MetricSizes.P_10 * 0.5,
    paddingHorizontal: MetricSizes.P_10 * 0.8,
    borderRadius: MetricSizes.P_10 * 0.5,
    backgroundColor: colors.lightBlue,
  },
  bodyInfoTitleButtonText: {
    color: colors.primary,
    fontSize: MetricSizes.P_10,
    padding: MetricSizes.P_10 * 0.5,
  },
  bodyInfoTitleText: {
    width: '70%',
    fontSize: fontSize.FS_16,
    fontWeight: 'bold',
    fontFamily: fonts.SF_PRO_REGULAR,
  },
  bodyInfoTitleIcon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    marginRight: MetricSizes.P_10,
  },
  bodyInfoAddress: {
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
    borderBottomWidth: 0.5,
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    borderColor: colors.grey,
  },
  bodyInfoApartment: {
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderColor: colors.grey,
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
  },
  bodyInfoNote: {
    alignItems: 'center',
    borderBottomWidth: 0.5,
    borderColor: colors.grey,
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
  },
  bodyInfoButton: {
    color: colors.primary,
    fontSize: fontSize.FS_16,
    paddingVertical: MetricSizes.P_10,
    fontWeight: 'bold',
    fontFamily: fonts.SF_PRO_BOLD,
    textAlign: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bodyInfoButtonWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_10,
  },
  markerView: {},
  markerImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
export default styles;
