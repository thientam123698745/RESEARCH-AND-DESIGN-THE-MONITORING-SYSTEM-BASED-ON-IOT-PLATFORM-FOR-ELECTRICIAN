import {View, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './style';
import {routers} from '@assets/constants/routers';
import useNavigate from '@hooks/useNavigate';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectDisplayLocation,
  selectSenderAddress,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const MyButton = () => {
  useBookingInjector();
  const displayAddress = useSelector(selectDisplayLocation);
  const addressList = useSelector(selectSenderAddress);
  const navigation = useNavigate();
  const dispatch = useDispatch();
  const {apartmentFloor, noteAddress, recName, noteForDriver, phone} =
    displayAddress;
  const isValidate =
    apartmentFloor != null &&
    noteAddress != null &&
    recName != null &&
    noteForDriver != null &&
    phone != null;
  function handleAddNewAddress() {
    const data = {
      list: addressList,
      address: displayAddress,
    };
    dispatch(BookingTruckOrderSlice.actions.addNewSenderAddress(data));
    navigation.navigate(routers.ORDER_MENU);
  }
  return (
    <View style={styles.buttonWrapper}>
      <TouchableOpacity
        onPress={handleAddNewAddress}
        style={[
          styles.button,
          {backgroundColor: isValidate ? colors.primary : colors.grey},
        ]}>
        <Text
          type="small"
          isCenter
          color={colors.white}
          isBold
          style={styles.buttonText}>
          button.continue
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default MyButton;
