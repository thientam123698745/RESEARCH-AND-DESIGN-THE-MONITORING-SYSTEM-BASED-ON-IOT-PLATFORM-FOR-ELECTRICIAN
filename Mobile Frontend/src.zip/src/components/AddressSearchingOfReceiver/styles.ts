import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    justifyContent: 'space-around',
    // borderWidth: 1,
  },
});
export default styles;
