import {View, ScrollView} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {CURRENT_SEARCHING_LOCATION_DATA} from '@assets/data';
import MySearchResultItem from './MySearchResultItem/MySearchResultItem';
import {useSelector} from 'react-redux';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {
  selectSearchingList,
  selectSearchingLoading,
} from '@store/bookingTruckOrder/shared/selector';
import MySearchResultPlaceholder from './MySearchResultPlaceholder/MySearchResultPlaceholder';
const MySearchResult = () => {
  useBookingInjector();
  let data = CURRENT_SEARCHING_LOCATION_DATA;
  const isLoading = useSelector(selectSearchingLoading);
  const searchingList = useSelector(selectSearchingList);
  if (searchingList.length !== 0) {
    data = searchingList;
  }
  return (
    <View style={styles.container}>
      {isLoading ? (
        <MySearchResultPlaceholder />
      ) : (
        <ScrollView showsVerticalScrollIndicator={false}>
          {data.map((item: any) => (
            <View key={item.id}>
              <MySearchResultItem item={item} />
            </View>
          ))}
        </ScrollView>
      )}
    </View>
  );
};
export default MySearchResult;
