import {View} from 'react-native';
import React from 'react';
import Input from '@components/common/Input';
import {REGEX_LIST} from '@assets/constants';
import {useForm} from 'react-hook-form';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import * as ProfileSelector from '@store/profile/shared/selector';
import {useDispatch, useSelector} from 'react-redux';
import LoadingPage from '@components/common/LoadingPage';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as ProfileSlice from '@store/profile/shared/slice';
import * as AuthSlice from '@store/auth/shared/slice';
import {ProfileSaga} from '@store/profile/shared/saga';
import {AuthSaga} from '@store/auth/shared/saga';
import {input_texts} from '@assets/constants/texts';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const NUMBER_OF_TEXT_INPUT = 1;
const ChangeFullName = () => {
  useInjectReducer({
    key: ProfileSlice.sliceKey,
    reducer: ProfileSlice.reducer,
  });
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: ProfileSlice.sliceKey,
    saga: ProfileSaga,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const full_name = useSelector(ProfileSelector.selectFullName);
  const phone = useSelector(ProfileSelector.selectPhone);
  const loading = useSelector(ProfileSelector.selectLoading);
  const {control, handleSubmit, formState} = useForm();

  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_TEXT_INPUT;
  const dispatch = useDispatch();
  const handleSave = (data: any) => {
    const requestData = {
      phone_number: phone,
      full_name_new: data.full_name,
    };

    dispatch(ProfileSlice.actions.changeFullName(requestData));
  };
  const navigation = useNavigate();
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="address_form.full_name" />
      <View style={styles.body}>
        <Text type="small" isBold>
          address_form.full_name
        </Text>
        <Text type="small">error.full_name</Text>
        <View style={styles.pad}>
          <Input
            control={control}
            label="address_form.full_name"
            input_value={full_name}
            rules={{
              required: true,
              minLength: 6,
              pattern: REGEX_LIST.FULL_NAME,
            }}
            name={input_texts.FULL_NAME}
            errMsg="error.full_name"
          />
        </View>
        <Button
          type="solid"
          disabled={countAtt}
          onPress={handleSubmit(handleSave)}>
          button.save
        </Button>
      </View>
    </View>
  );
};

export default ChangeFullName;
