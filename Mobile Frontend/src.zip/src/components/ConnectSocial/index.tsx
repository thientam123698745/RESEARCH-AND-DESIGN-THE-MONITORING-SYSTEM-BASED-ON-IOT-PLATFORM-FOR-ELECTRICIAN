import {View} from 'react-native';
import React from 'react';
import SwitchAccount from '@components/common/SwitchAccount';
import {styles} from './styles';
import SquareHeader from '@components/Header/SquareHeader';
import useNavigate from '@hooks/useNavigate';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';

const ConnectSocial = () => {
  const data = [
    {text: 'Liên kết Zalo', image: require('assets/images/zalo.png')},
    {text: 'Liên kết Facebook', image: require('assets/images/fb.png')},
    {text: 'Liên kết Instagram', image: require('assets/images/ins.png')},
  ];
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <SquareHeader navigation={navigation} text="Kết nối mạng xã hội" />
      {data.map((item, index) => (
        <SwitchAccount
          key={index}
          index={index}
          image={item.image}
          text={item.text}
        />
      ))}
    </View>
  );
};

export default ConnectSocial;
