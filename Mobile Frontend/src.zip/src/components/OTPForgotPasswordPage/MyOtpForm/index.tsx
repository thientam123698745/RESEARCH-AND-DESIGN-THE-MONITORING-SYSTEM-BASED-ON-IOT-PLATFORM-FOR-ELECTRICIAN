import {
  View,
  Alert,
  Image,
  TouchableOpacity,
  Text as RNText,
} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import OTPInputView from '@twotalltotems/react-native-otp-input';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
const MyOtpForm = () => {
  // const dispatch = useDispatch();
  const navigation = useNavigate();
  const handleResend = () => {
    Alert.alert('resend button coming soon');
  };
  const handleReinputPhone = () => {
    // Alert.alert('reinput phone button');
    navigation.goBack();
  };
  // const registerUser = useSelector(AuthSelector.selectRegisterUser);
  const handleSubmitCode = (code: string) => {
    if (code === '123456') {
      navigation.navigate(routers.FORGOT_PASSWORD_PAGE);
      // dispatch(AuthSlice.actions.signUp(registerUser));
    }
  };
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text type="small">otp.question</Text>
        <TouchableOpacity onPress={handleResend}>
          <Text type="small" color={colors.orange} isUnderlined isBold>
            otp.resend
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.otp_input}>
        <OTPInputView
          pinCount={6}
          autoFocusOnLoad
          codeInputFieldStyle={styles.underlineStyleBase}
          codeInputHighlightStyle={styles.underlineStyleHighLighted}
          onCodeFilled={handleSubmitCode}
        />
      </View>
      <View style={styles.footer}>
        <View style={styles.imgWrapper}>
          <Image source={Images.SMALL_LONG_BUTTON} style={styles.image} />
        </View>
        <Text type="small" onPress={handleReinputPhone} color={colors.primary}>
          otp.re_input_button
        </Text>
      </View>
      <View style={styles.timeWrapper}>
        <RNText>
          <Text type="small" color={colors.grey}>
            otp.time_remaining
          </Text>
          <Text type="small">02:00</Text>
        </RNText>
      </View>
    </View>
  );
};

export default MyOtpForm;
