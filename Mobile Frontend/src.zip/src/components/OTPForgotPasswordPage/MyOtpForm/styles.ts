import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    flex: 7,
  },
  header: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    width: '100%',
  },
  footer: {
    flex: 1,
    // justifyContent: 'flex-start',
    alignItems: 'center',
    flexDirection: 'row',
    width: '100%',
  },
  imgWrapper: {
    paddingRight: MetricSizes.P_10,
  },
  image: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 3 / 2,
  },
  timeWrapper: {
    flex: 4,
    width: '100%',
    justifyContent: 'flex-end',
    bottom: MetricSizes.P_20,
  },
  otp_input: {
    flex: 1,
    // borderWidth: 1,
    padding: MetricSizes.P_20,
  },
  underlineStyleBase: {
    backgroundColor: colors.greyLine,
    color: colors.blackText,
  },
  underlineStyleHighLighted: {
    backgroundColor: colors.grey,
  },
});
