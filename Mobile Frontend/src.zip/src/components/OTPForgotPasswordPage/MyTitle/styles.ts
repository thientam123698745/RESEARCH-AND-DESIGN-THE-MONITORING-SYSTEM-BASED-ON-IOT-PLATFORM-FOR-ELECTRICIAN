import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  titleWrapper: {
    flex: 1,
    paddingVertical: MetricSizes.P_10,
  },
  text: {
    textAlign: 'center',
  },
});
export default styles;
