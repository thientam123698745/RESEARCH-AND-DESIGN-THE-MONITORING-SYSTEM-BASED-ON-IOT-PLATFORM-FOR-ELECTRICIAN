import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    flex: 1,
    paddingHorizontal: MetricSizes.P_20,
  },
});
