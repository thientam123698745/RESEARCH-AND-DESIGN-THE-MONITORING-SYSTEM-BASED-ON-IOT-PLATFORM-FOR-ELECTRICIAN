import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    // borderWidth: 1,
  },
  imageHeaderImage: {
    width: '100%',
    height: undefined,
    aspectRatio: 3 / 2,
    resizeMode: 'stretch',
  },
});
