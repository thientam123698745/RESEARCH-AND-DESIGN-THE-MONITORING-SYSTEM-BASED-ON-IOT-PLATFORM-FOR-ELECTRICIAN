import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
const BookingSuccessHeaderImage = () => {
  return (
    <View style={styles.container}>
      <Image source={Images.TITLE_HEADER} style={styles.imageHeaderImage} />
    </View>
  );
};
export default BookingSuccessHeaderImage;
