import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#3578DA',
    zIndex: 2,
  },
  titleImage: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  titleImageView: {
    // borderWidth: 1,
    padding: MetricSizes.P_20,
  },
  titleTextView: {},
});
