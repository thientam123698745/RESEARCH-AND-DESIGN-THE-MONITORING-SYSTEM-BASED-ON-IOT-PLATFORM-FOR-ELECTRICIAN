import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const BookingSuccessHeaderTitle = ({handleShare}: {handleShare: Function}) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.titleImageView}>
        <Image source={Images.CLOSE_BUTTON_WHITE} style={styles.titleImage} />
      </TouchableOpacity>
      <View style={styles.titleTextView}>
        <Text type="small" color={colors.white} isCenter>
          redirect_bill
        </Text>
      </View>
      <TouchableOpacity
        onPress={() => handleShare()}
        style={styles.titleImageView}>
        <Image source={Images.SHARE} style={styles.titleImage} />
      </TouchableOpacity>
    </View>
  );
};
export default BookingSuccessHeaderTitle;
