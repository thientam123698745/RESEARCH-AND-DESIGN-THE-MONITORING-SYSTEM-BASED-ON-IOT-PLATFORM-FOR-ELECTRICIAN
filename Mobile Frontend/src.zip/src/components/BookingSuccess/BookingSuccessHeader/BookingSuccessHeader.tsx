import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import BookingSuccessHeaderTitle from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeaderTitle/BookingSuccessHeaderTitle';
import BookingSuccessHeaderImage from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeaderImage/BookingSuccessHeaderImage';
import BookingSuccessHeaderInformation from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeaderInformation/BookingSuccessHeaderInformation';
const BookingSuccessHeader = ({handleShare}: {handleShare: Function}) => {
  return (
    <View style={styles.container}>
      <BookingSuccessHeaderTitle handleShare={handleShare} />
      <BookingSuccessHeaderImage />
      <BookingSuccessHeaderInformation />
    </View>
  );
};
export default BookingSuccessHeader;
