import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import BookingSuccessHeaderInformationBody from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeaderInformation/BookingSuccessHeaderInformationBody/BookingSuccessHeaderInformationBody';
import BookingSuccessHeaderInformationDetailButton from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeaderInformation/BookingSuccessHeaderInformationDetailButton/BookingSuccessHeaderInformationDetailButton';
const BookingSuccessHeaderInformation = () => {
  return (
    <View style={styles.container}>
      <BookingSuccessHeaderInformationBody />
      <BookingSuccessHeaderInformationDetailButton />
    </View>
  );
};
export default BookingSuccessHeaderInformation;
