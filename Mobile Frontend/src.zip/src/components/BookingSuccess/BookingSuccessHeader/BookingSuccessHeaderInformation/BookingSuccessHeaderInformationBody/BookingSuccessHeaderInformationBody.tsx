import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const BookingSuccessHeaderInformationBody = () => {
  return (
    <View style={styles.container}>
      <View style={styles.bodyOrderView}>
        <Image source={Images.ORDER_HEADER} style={styles.bodyOrderImage} />
      </View>
      <View style={styles.bodyOrderTextView}>
        <Text type="small" color={colors.blackText} isBold>
          shipment_code
        </Text>
        <Text type="small" color={colors.grey}>
          shipment_date
        </Text>
        <Text type="small" color={colors.blackText} isBold>
          is_shipment
        </Text>
      </View>
      <TouchableOpacity style={styles.bodyOrderView}>
        <Image source={Images.COPY_CODE} style={styles.bodyOrderImage} />
      </TouchableOpacity>
    </View>
  );
};
export default BookingSuccessHeaderInformationBody;
