import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    paddingBottom: MetricSizes.P_20,
    borderBottomWidth: 1,
    borderColor: colors.grey,
  },
  bodyOrderImage: {
    width: MetricSizes.P_20,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 1,
  },
  bodyOrderView: {
    // padding: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bodyOrderTextView: {
    paddingTop: MetricSizes.P_20,
    paddingHorizontal: MetricSizes.P_10,
    flexGrow: 1,
  },
});
