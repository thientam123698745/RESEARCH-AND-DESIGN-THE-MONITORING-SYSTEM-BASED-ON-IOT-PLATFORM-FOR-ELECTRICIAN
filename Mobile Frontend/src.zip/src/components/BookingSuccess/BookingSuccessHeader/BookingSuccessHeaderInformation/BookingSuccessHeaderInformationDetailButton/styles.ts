import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
  },
  detailCaretImage: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
});
