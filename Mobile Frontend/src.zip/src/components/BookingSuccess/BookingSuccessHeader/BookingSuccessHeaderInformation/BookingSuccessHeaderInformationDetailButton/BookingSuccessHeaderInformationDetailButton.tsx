import {Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
const BookingSuccessHeaderInformationDetailButton = () => {
  const navigation = useNavigate();
  function handleViewDetail() {
    navigation.navigate(routers.BOOKING_SHIPMENT_DETAIL);
  }
  return (
    <TouchableOpacity style={styles.container}>
      <TouchableOpacity onPress={handleViewDetail}>
        <Text type="small">order_enu.view_order_detail</Text>
      </TouchableOpacity>
      <Image
        source={Images.DOUBLE_CARET_LEFT}
        style={styles.detailCaretImage}
      />
    </TouchableOpacity>
  );
};
export default BookingSuccessHeaderInformationDetailButton;
