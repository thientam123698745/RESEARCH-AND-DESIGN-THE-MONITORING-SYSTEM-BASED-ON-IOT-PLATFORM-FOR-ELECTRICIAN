import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    marginTop: MetricSizes.P_10,
    padding: MetricSizes.P_20,
  },
  trackerTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingBottom: MetricSizes.P_10,
  },
  trackerTitleImageView: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackerTitleImage: {
    width: MetricSizes.P_20 * 1.5,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 2 / 1,
  },
  trackerTitleTextView: {
    flexGrow: 1,
  },
  trackerTitleLinkView: {},
  trackerProgress: {
    flexDirection: 'row',
  },
  progressTextView: {},
  progressImageView: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressImage: {
    width: MetricSizes.P_20,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 1,
  },
});
