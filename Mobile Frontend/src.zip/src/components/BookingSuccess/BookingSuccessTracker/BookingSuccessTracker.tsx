import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
const BookingSuccessTracker = () => {
  const navigation = useNavigate();
  function handleViewDetail() {
    navigation.navigate(routers.BOOKING_SHIPMENT_DETAIL);
  }
  return (
    <View style={styles.container}>
      <View style={styles.trackerTitle}>
        <View style={styles.trackerTitleImageView}>
          <Image source={Images.FAST_TRUCK} style={styles.trackerTitleImage} />
        </View>
        <View style={styles.trackerTitleTextView}>
          <Text type="small" isBold color={colors.blackText}>
            track_order
          </Text>
        </View>
        <TouchableOpacity
          onPress={handleViewDetail}
          style={styles.trackerTitleLinkView}>
          <Text type="small" color={colors.primary}>
            view_detail
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.trackerProgress}>
        <View style={styles.progressImageView}>
          <Image source={Images.GET_SHIPMENT} style={styles.progressImage} />
        </View>
        <View style={styles.progressTextView}>
          <Text type="small" color={colors.blackText} isBold>
            is_coming
          </Text>
          <Text type="small" color={colors.blackText}>
            time_remaining
          </Text>
        </View>
      </View>
    </View>
  );
};
export default BookingSuccessTracker;
