import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: MetricSizes.P_10,
    padding: MetricSizes.P_20,
    backgroundColor: colors.white,
  },
  textView: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: MetricSizes.P_10,
  },
  textView1: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: MetricSizes.P_10,
    borderTopWidth: 1,
  },
});
