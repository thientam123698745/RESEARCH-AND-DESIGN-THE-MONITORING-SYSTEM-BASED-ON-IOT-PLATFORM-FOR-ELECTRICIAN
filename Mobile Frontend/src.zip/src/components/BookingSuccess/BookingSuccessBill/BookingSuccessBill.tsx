import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const BookingSuccessBill = () => {
  return (
    <View style={styles.container}>
      <View style={styles.textView}>
        <Text type="small" color={colors.blackText}>
          truck
        </Text>
        <Text type="small" color={colors.blackText}>
          truck_value
        </Text>
      </View>
      <View style={styles.textView}>
        <Text type="small" color={colors.blackText}>
          truck
        </Text>
        <Text type="small" color={colors.blackText}>
          truck_value
        </Text>
      </View>
      <View style={styles.textView}>
        <Text type="small" color={colors.blackText}>
          total
        </Text>
        <Text type="small" color={colors.blackText}>
          truck_value
        </Text>
      </View>
      <View style={styles.textView1}>
        <Text type="small" color={colors.red}>
          sales
        </Text>
        <Text type="small" color={colors.red}>
          truck_value_minus
        </Text>
      </View>
      <View style={styles.textView}>
        <Text type="small" color={colors.blackText}>
          need_to_pay
        </Text>
        <Text type="small" color={colors.blackText}>
          truck_value
        </Text>
      </View>
    </View>
  );
};
export default BookingSuccessBill;
