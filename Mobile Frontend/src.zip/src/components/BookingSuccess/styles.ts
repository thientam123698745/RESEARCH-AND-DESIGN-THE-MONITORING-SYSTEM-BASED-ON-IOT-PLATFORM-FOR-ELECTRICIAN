import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,\
    borderWidth: 1,
    paddingTop: MetricSizes.P_40,
    backgroundColor: '#3578DA',
  },
  view: {
    backgroundColor: colors.borderGray,
    // minHeight: WINDOW_HEIGHT * 1.1,
  },
  shareSheetContainer: {
    height: '100%',
    // borderWidth: 1,
    // backgroundColor: colors.grey,
  },
  socialContainer: {
    // borderWidth: 1,
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'space-around',
    flexDirection: 'row',
    // borderWidth: 1,
  },
  socialItem: {
    alignItems: 'center',
    justifyContent: 'center',
    width: WINDOW_WIDTH * 0.25,
  },
  socialItemImageView: {},
  socialItemImage: {},
  socialItemTitleView: {},
  socialTitleContainer: {
    // flex: 1,
    // borderWidth: 1,
  },
});
