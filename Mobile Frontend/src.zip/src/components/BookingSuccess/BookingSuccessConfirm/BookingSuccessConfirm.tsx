import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const BookingSuccessConfirm = () => {
  const navigation = useNavigate();
  function handleReturn() {
    navigation.navigate(routers.BOOKING_FINISH);
  }
  return (
    <View style={styles.container}>
      <Text type="small" color={colors.blackText} isBold isCenter>
        sign_confirm
      </Text>
      <Button type="solid" onPress={handleReturn}>
        approve
      </Button>
    </View>
  );
};
export default BookingSuccessConfirm;
