import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: MetricSizes.P_10,
    padding: MetricSizes.P_20,
    backgroundColor: colors.white,
  },
  signView: {
    justifyContent: 'center',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    margin: MetricSizes.P_20,
  },
  canvasBody: {
    backgroundColor: colors.white,
    height: undefined,
    width: '50%',
    aspectRatio: 1 / 1,
    // borderWidth: 1,
  },
});
