import {Image, ScrollView, TouchableOpacity, View} from 'react-native';
import React, {useCallback, useMemo, useRef} from 'react';
import {styles} from './styles';
import BookingSuccessHeader from '@components/BookingSuccess/BookingSuccessHeader/BookingSuccessHeader';
import BookingSuccessTracker from '@components/BookingSuccess/BookingSuccessTracker/BookingSuccessTracker';
import BookingSuccessBill from '@components/BookingSuccess/BookingSuccessBill/BookingSuccessBill';
import BookingSuccessConfirm from '@components/BookingSuccess/BookingSuccessConfirm/BookingSuccessConfirm';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import BottomSheet from '@gorhom/bottom-sheet';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const BookingSuccess = () => {
  const bottomSheetRef = useRef<BottomSheet>(null);

  const snapPoints = useMemo(() => ['20%'], []);

  const handleSheetChanges = useCallback(() => {}, []);
  const data = [
    {
      id: 0,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 1,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 2,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 3,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 4,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 5,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 6,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
    {
      id: 7,
      image: Images.FACEBOOK,
      text: 'Facebook',
    },
  ];
  function handleOpenShareSheet() {
    bottomSheetRef.current.expand();
  }
  function handleCloseShareSheet() {
    bottomSheetRef.current.close();
  }
  return (
    <View style={styles.container}>
      <TransStatusBar color="light-content" />
      {/* <StatusBar backgroundColor={colors.primary}  /> */}
      <ScrollView>
        <View style={styles.view}>
          <BookingSuccessHeader handleShare={handleOpenShareSheet} />
          <BookingSuccessTracker />
          <BookingSuccessBill />
          <BookingSuccessConfirm />
        </View>
      </ScrollView>

      <BottomSheet
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}>
        <View style={styles.shareSheetContainer}>
          <View style={styles.socialTitleContainer}>
            <Text type="small" color={colors.blackText} isCenter isBold>
              share_order
            </Text>
          </View>
          <View style={styles.socialContainer}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {data.map((item, index) => (
                <TouchableOpacity
                  key={index}
                  onPress={handleCloseShareSheet}
                  style={styles.socialItem}>
                  <View style={styles.socialItemImageView}>
                    <Image
                      source={Images.FACEBOOK}
                      style={styles.socialItemImage}
                    />
                  </View>
                  <View style={styles.socialItemTitleView}>
                    <Text type="small" color={colors.blackText}>
                      facebook
                    </Text>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </BottomSheet>
    </View>
  );
};
export default BookingSuccess;
