import {fontSize} from '@assets/fonts';
import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.white,
    paddingBottom: MetricSizes.P_10,
  },
  view1: {
    height: '70%',
    padding: MetricSizes.P_20,
  },
  view1_1: {
    width: '100%',
    height: '100%',
    flexDirection: 'row',
    backgroundColor: colors.greyLine,
    padding: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10 * 0.5,
  },
  view2: {
    height: '30%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  button: {
    height: '80%',
    borderRadius: MetricSizes.P_10,
    width: '90%',
    backgroundColor: colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: colors.white,
  },
  view3: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_20,
    width: '10%',
  },
  view4: {
    width: '80%',
    justifyContent: 'center',
  },
  view5: {},
  view6: {},
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  text1: {
    fontSize: fontSize.FS_16,
  },
  text2: {fontSize: fontSize.FS_10, color: colors.grey},
});
export default styles;
