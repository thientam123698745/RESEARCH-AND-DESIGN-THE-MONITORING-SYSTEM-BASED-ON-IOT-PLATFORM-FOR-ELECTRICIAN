import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 2.8,
  },
  mapWrapper: {
    height: '100%',
  },
  imgView: {
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    bottom: 30,
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  pin: {
    width: MetricSizes.P_40 * 0.75,
    height: MetricSizes.P_40 * 0.75,
    resizeMode: 'stretch',
  },
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  returnButton: {
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
    padding: MetricSizes.P_10,
    position: 'absolute',
    top: MetricSizes.P_40,
    left: MetricSizes.P_10,
  },
  currentButton: {
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
    padding: MetricSizes.P_10,
    position: 'absolute',
    bottom: MetricSizes.P_40,
    right: MetricSizes.P_10,
  },
  markerView: {},
  markerImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
export default styles;
