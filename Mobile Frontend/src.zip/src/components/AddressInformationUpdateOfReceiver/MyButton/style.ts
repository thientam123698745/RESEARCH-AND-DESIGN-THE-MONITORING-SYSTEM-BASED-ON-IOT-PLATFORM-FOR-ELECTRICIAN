import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts} from '@assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  buttonWrapper: {
    flex: 1.2,
    // alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: MetricSizes.P_10,
  },
  button: {
    backgroundColor: colors.primary,
    borderRadius: MetricSizes.P_10 * 0.5,
    padding: MetricSizes.P_10,
    margin: MetricSizes.P_10,
  },
  buttonText: {
    fontFamily: fonts.SF_PRO_BOLD,
    color: colors.white,
    textAlign: 'center',
  },
});
export default styles;
