import React from 'react';

import {
  Image,
  ImageBackground,
  TouchableOpacity,
  View,
  Text as RNText,
} from 'react-native';

import {Images} from '@assets/constants/images';

import styles from './styles';

import useNavigate from '@hooks/useNavigate';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useDispatch, useSelector} from 'react-redux';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {
  selectSeachValue,
  selectUpdateIndex,
} from '@store/bookingTruckOrder/shared/selector';
import _ from 'lodash';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
import TextInput from '@components/common/TextInput/TextInput';
const MySearchAddress = () => {
  const navigation = useNavigate();

  useBookingInjector();
  const dispatch = useDispatch();
  const searchValue = useSelector(selectSeachValue);
  const index = useSelector(selectUpdateIndex);
  function handleGoBack() {
    navigation.goBack();
  }
  function handleClear() {
    dispatch(BookingTruckOrderSlice.actions.clearSearchValue());
  }
  function handleSearchValue(text: string) {
    _.debounce(function () {
      dispatch(BookingTruckOrderSlice.actions.searchingValue(text));
    }, 2000);
  }
  return (
    <ImageBackground
      style={styles.container}
      resizeMode="stretch"
      imageStyle={styles.img}
      source={Images.BG_BOOK_CAR}>
      <SafeAreaView style={styles.searchWrapper}>
        <View style={styles.titleWrapper}>
          <TouchableOpacity onPress={handleGoBack} style={styles.returnWrapper}>
            <Image style={styles.returnImage} source={Images.TT_RETURN} />
          </TouchableOpacity>
          <View style={styles.returnText}>
            <RNText>
              <Text type="small">
                update_recipient.update_recipient_choose_location
              </Text>
              <Text type="small">{` ${index + 1}`}</Text>
            </RNText>
          </View>
        </View>
        <View style={styles.searchTextInputWrapper}>
          <View style={styles.searchTextInput}>
            <View style={styles.searchTextInputPositionDot}>
              <Image
                source={Images.LOCATION_DOT}
                style={styles.searchTextInputPositionDotImage}
              />
            </View>
            <TextInput
              style={styles.searchTextInputInput}
              placeholder="placeholder.location"
              value={searchValue}
              onChangeText={handleSearchValue}
            />
            <TouchableOpacity
              onPress={handleClear}
              style={styles.searchTextInputCloseDot}>
              <Image
                source={Images.CLOSE_MODAL_BUTTON}
                style={styles.searchTextInputCloseDotImage}
              />
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default MySearchAddress;
