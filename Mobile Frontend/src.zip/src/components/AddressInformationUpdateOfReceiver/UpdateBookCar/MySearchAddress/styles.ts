import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: '25%',
    backgroundColor: colors.orange,
    justifyContent: 'flex-end',
  },
  img: {
    height: '100%',
  },
  searchWrapper: {
    // marginTop: MetricSizes.P_20 * 1.5,
    paddingVertical: MetricSizes.P_20,
    paddingHorizontal: MetricSizes.P_20,
  },
  titleWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
  },
  returnWrapper: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  returnText: {},
  searchTextInputWrapper: {
    alignItems: 'flex-end',
  },
  searchTextInput: {
    borderRadius: MetricSizes.P_10,
    width: '90%',
    flexDirection: 'row',
    borderColor: colors.white,
    backgroundColor: colors.semiTransparent,
    borderWidth: 1,
    justifyContent: 'space-between',
    paddingHorizontal: MetricSizes.P_10,
    alignItems: 'center',
  },
  searchTextInputPositionDot: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchTextInputPositionDotImage: {
    width: MetricSizes.P_20,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 1,
  },
  searchTextInputInput: {
    height: '100%',
    flexGrow: 1,
    color: colors.white,
    fontSize: fontSize.FS_16,
    fontFamily: fonts.SF_PRO_REGULAR,
    fontWeight: '500',
  },
  searchTextInputCloseDot: {
    width: '10%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  searchTextInputCloseDotImage: {
    width: MetricSizes.P_20,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 1,
  },
  returnImage: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  icon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  locationWrapper: {
    justifyContent: 'center',
  },
  inputWrapper: {
    // borderWidth: 1,
    width: '80%',
    height: '100%',
    borderWidth: 1,
  },
  closeWrapper: {
    justifyContent: 'center',
  },
  clockWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    width: WINDOW_WIDTH * 0.2,
    // borderWidth: 1,
  },
  clockIcon: {
    width: MetricSizes.P_40,
    height: MetricSizes.P_40,
    resizeMode: 'stretch',
  },
  textWrapper: {
    // width: WINDOW_WIDTH * 0.8,
    // borderWidth: 1,
    width: '80%',
  },
  title: {
    width: '100%',
  },
  content: {
    paddingTop: MetricSizes.P_10 * 0.5,
    width: '100%',
  },
  MetricSizes: {},
  address: {},
  rowContainer: {
    flexDirection: 'row',
    padding: MetricSizes.P_10,
    width: WINDOW_WIDTH,
    // borderWidth: 1,
  },
});

export default styles;
