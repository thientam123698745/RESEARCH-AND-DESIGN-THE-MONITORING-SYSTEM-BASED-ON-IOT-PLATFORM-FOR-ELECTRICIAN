import React from 'react';
import SkeletonPlaceholder from 'react-native-skeleton-placeholder';
import MetricSizes from '@assets/constants/MetricSizes';
import {WINDOW_HEIGHT} from '@gorhom/bottom-sheet';

const MySearchResultPlaceholder = () => {
  return (
    <>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
      <SkeletonPlaceholder>
        <SkeletonPlaceholder.Item
          flexDirection="row"
          alignItems="center"
          paddingVertical={MetricSizes.P_20}
          height={WINDOW_HEIGHT * 0.125}>
          <SkeletonPlaceholder.Item width={'10%'}>
            <SkeletonPlaceholder.Item
              width={MetricSizes.P_20 * 1.5}
              height={MetricSizes.P_20 * 1.5}
              borderRadius={MetricSizes.P_20 * 1}
            />
          </SkeletonPlaceholder.Item>
          <SkeletonPlaceholder.Item marginLeft={MetricSizes.P_10} width="90%">
            <SkeletonPlaceholder.Item height={20} borderRadius={4} />
            <SkeletonPlaceholder.Item
              marginTop={MetricSizes.P_10 * 0.5}
              height={20}
              borderRadius={4}
            />
          </SkeletonPlaceholder.Item>
        </SkeletonPlaceholder.Item>
      </SkeletonPlaceholder>
    </>
  );
};
export default MySearchResultPlaceholder;
