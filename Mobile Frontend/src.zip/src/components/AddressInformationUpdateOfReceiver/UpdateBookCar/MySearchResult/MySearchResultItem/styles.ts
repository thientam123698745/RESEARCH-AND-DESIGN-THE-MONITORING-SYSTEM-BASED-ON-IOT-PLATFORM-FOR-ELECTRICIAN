import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_20,
    borderBottomWidth: 1,
    borderColor: colors.grey,
    height: WINDOW_HEIGHT * 0.125,
    width: '100%',
    // borderWidth: 1,
  },
  itemImage: {
    width: MetricSizes.P_20 * 1.5,
    paddingHorizontal: MetricSizes.P_10,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  itemImageView: {
    width: '10%',
  },
  itemTextView: {
    width: '90%',
    // borderWidth: 1,
    paddingHorizontal: MetricSizes.P_10,
    justifyContent: 'space-around',
  },
});
