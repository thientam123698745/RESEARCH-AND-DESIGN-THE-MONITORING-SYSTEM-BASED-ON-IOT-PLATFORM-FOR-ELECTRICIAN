import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts} from '@assets/fonts';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    // height: WINDOW_HEIGHT * 0.1,
    padding: MetricSizes.P_10,
    borderTopColor: colors.grey,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderTopWidth: 1,
    width: '100%',
    backgroundColor: colors.white,
    position: 'absolute',
    bottom: 0,
    //shadow
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.39,
    shadowRadius: 8.3,

    elevation: 13,
  },
  locationText: {
    color: colors.primary,
    fontFamily: fonts.SF_PRO_REGULAR,
  },
  locationDot: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    marginHorizontal: MetricSizes.P_10,
  },
});

export default styles;
