import {Image, TouchableOpacity, View} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import MapView, {Marker} from 'react-native-maps';
import useNavigate from '@hooks/useNavigate';
import {btRouters} from '@assets/constants/btRouters';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {selectDisplayLocation} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import TextInput from '@components/common/TextInput/TextInput';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyBody = () => {
  useBookingInjector();
  const navigation = useNavigate();
  const displayAddress = useSelector(selectDisplayLocation);

  const {coord, shortAddress, detailAddress, apartmentFloor, noteAddress} =
    displayAddress;
  const {latitude, longitude} = coord;
  const handleLocation = () => {
    navigation.navigate(btRouters.BOOK_CAR);
  };
  const dispatch = useDispatch();
  function setFloor(floor: string) {
    const tmpFloor = parseInt(floor, 10);
    dispatch(BookingTruckOrderSlice.actions.setDisplayFloor(tmpFloor));
  }
  function setNoteAddress(note: string) {
    if (note !== null) {
      dispatch(BookingTruckOrderSlice.actions.setDisplayNoteAddress(note));
    }
  }
  return (
    <View style={styles.container}>
      <View style={styles.bodyWrapper}>
        <View style={styles.bodyMapWrapper}>
          <MapView
            style={styles.map}
            region={{
              latitude: latitude,
              longitude: longitude,
              latitudeDelta: 0.001,
              longitudeDelta: 0.001,
            }}>
            <Marker
              coordinate={{
                latitude: latitude,
                longitude: longitude,
              }}>
              <View style={styles.markerView}>
                <Image source={Images.LOCATION2} style={styles.markerImage} />
              </View>
            </Marker>
          </MapView>
        </View>
        <View style={styles.bodyInfoWrapper}>
          <View style={styles.bodyInfoTItle}>
            <View style={styles.titleWrapper}>
              <Image
                style={styles.bodyInfoTitleIcon}
                source={Images.LOCATION}
              />
              <View style={styles.infoTitleWrapper}>
                <Text
                  type="small"
                  color={colors.primary}
                  isCenter={false}
                  isBold
                  style={styles.bodyInfoTitleText}>
                  {shortAddress}
                </Text>
              </View>
            </View>
            <TouchableOpacity
              onPress={handleLocation}
              style={styles.bodyInfoTItleButton}>
              <Text
                type="small"
                color={colors.primary}
                style={styles.bodyInfoTitleButtonText}>
                button.change
              </Text>
            </TouchableOpacity>
          </View>
          <Text type="tiny" isCenter={false} style={styles.bodyInfoAddress}>
            {detailAddress}
          </Text>
          <View style={styles.bodyInfoApartment}>
            <Image style={styles.icon} source={Images.HOME} />
            <TextInput
              keyboardType="decimal-pad"
              placeholder="address_form.apartment"
              value={apartmentFloor ? apartmentFloor + '' : ''}
              onChangeText={setFloor}
              style={styles.textInput}
            />
          </View>
          <View style={styles.bodyInfoNote}>
            <Image style={styles.icon} source={Images.NOTE} />
            <TextInput
              placeholder="address_form.note_address"
              value={noteAddress}
              onChangeText={setNoteAddress}
              style={styles.textInput}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

export default MyBody;
