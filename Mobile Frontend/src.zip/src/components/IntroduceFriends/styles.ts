import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  img: {
    width: '100%',
    height: WINDOW_HEIGHT * 0.3,
  },
  imgWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  compWrapper: {
    // justifyContent: 'center',
    // alignItems: 'center',
  },
  shareWrapper: {
    backgroundColor: colors.white,
    height: WINDOW_HEIGHT * 0.1,
    width: '90%',
    marginTop: WINDOW_HEIGHT * 0.25,
    borderRadius: MetricSizes.P_10,
    alignSelf: 'center',
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_20,
  },
  wrapper1: {
    padding: MetricSizes.P_20,
  },
  wrapper2: {
    backgroundColor: colors.white,
    padding: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10,
    margin: MetricSizes.P_20,
  },
  textInput: {
    borderWidth: 1,
    borderRadius: MetricSizes.P_10,
    borderColor: colors.grey,
    padding: MetricSizes.P_10 * 0.3,
    margin: MetricSizes.P_10,
  },
  wrapper3: {
    padding: MetricSizes.P_20,
  },
  iconWrapper: {
    width: '20%',
    height: '100%',
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    width: MetricSizes.P_40 * 1.5,
    height: MetricSizes.P_40 * 1.5,
    resizeMode: 'stretch',
  },
  textWrapper: {
    width: '60%',
    height: '100%',
    // borderWidth: 1,
    justifyContent: 'center',
    padding: MetricSizes.P_10,
  },
  nextWrapper: {
    width: '20%',
    height: '100%',
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  nextIcon: {
    width: MetricSizes.P_20 * 1.5,
    height: MetricSizes.P_20 * 1.5,
    resizeMode: 'stretch',
  },
});
