import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {ScrollView} from 'react-native-gesture-handler';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
import TextInput from '@components/common/TextInput/TextInput';

const IntroduceFriends = () => {
  return (
    <View>
      <View style={styles.imgWrapper}>
        <Image
          style={styles.img}
          source={require('@assets/images/introBackground.png')}
        />
      </View>
      <ScrollView style={styles.compWrapper}>
        <TouchableOpacity style={styles.shareWrapper}>
          <View style={styles.iconWrapper}>
            <Image style={styles.icon} source={Images.USER_ICON} />
          </View>
          <View style={styles.textWrapper}>
            <Text type="small" color={colors.blackText} isBold>
              use_voucher
            </Text>
            <Text type="tiny" color={colors.primary} isUnderlined>
              link
            </Text>
          </View>
          <View style={styles.nextWrapper}>
            <Image style={styles.nextIcon} source={Images.CARET_LEFT} />
          </View>
        </TouchableOpacity>
        <View style={styles.wrapper1}>
          <Text type="regular" color={colors.orange} isCenter>
            taken_discount
          </Text>
          <Text type="regular" isCenter color={colors.blackText}>
            taken_discount_message
          </Text>
        </View>
        <View style={styles.wrapper2}>
          <Text type="regular" isCenter color={colors.blackText}>
            invite_friend
          </Text>
          <View style={styles.textInput}>
            <TextInput placeholder="invite_input" />
          </View>
        </View>
        <View style={styles.wrapper3}>
          <Text type="regular" color={colors.blackText}>
            how
          </Text>
          <Text type="small" color={colors.blackText}>
            "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Tincidunt
            adipiscing nulla magnis diam. Vestibulum leo felis morbi praesent
            nibh mauris, et malesuada. In suspendisse quis orci, vel netus et
            massa. Id sapien aenean at velit lobortis egestas tincidunt."
          </Text>
        </View>
      </ScrollView>
    </View>
  );
};

export default IntroduceFriends;
