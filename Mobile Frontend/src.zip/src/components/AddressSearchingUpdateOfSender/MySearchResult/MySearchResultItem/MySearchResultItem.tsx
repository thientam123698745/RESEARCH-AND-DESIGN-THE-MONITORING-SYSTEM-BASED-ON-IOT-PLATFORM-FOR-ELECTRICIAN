import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {useDispatch} from 'react-redux';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import Text from '@components/common/Texts/Text';
const MySearchResultItem = ({item}: {item: any}) => {
  const dispatch = useDispatch();
  const navigation = useNavigate();
  function handleDisplayLocation() {
    dispatch(BookingTruckOrderSlice.actions.setDisplayLocation(item));
    navigation.navigate(routers.ADDRESS_LOCATION_UPDATE_OF_SENDER);
  }
  return (
    <TouchableOpacity onPress={handleDisplayLocation} style={styles.container}>
      <View style={styles.itemImageView}>
        <Image source={Images.CLOCK} style={styles.itemImage} />
      </View>
      <View style={styles.itemTextView}>
        <Text type="small" isBold>
          {item.shortAddress}
        </Text>
        <Text type="tiny" isTruncated>
          {item.detailAddress}
        </Text>
      </View>
    </TouchableOpacity>
  );
};
export default MySearchResultItem;
