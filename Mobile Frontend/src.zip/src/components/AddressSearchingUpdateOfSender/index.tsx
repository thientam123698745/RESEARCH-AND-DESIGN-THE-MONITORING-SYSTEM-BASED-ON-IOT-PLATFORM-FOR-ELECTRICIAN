import {View} from 'react-native';
import React, {useEffect} from 'react';
import styles from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MySearchAddress from './MySearchAddress';
import MyCurrentLocationButton from './MyCurrentLocationButton';
import MySearchResult from './MySearchResult/MySearchResult';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {selectSearchError} from '@store/bookingTruckOrder/shared/selector';
import * as AuthSlice from '@store/auth/shared/slice';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
const AddressSearchingUpdateOfSender = () => {
  useBookingInjector();
  const error = useSelector(selectSearchError);
  const dispatch = useDispatch();

  useEffect(() => {
    const data = {
      index: 2,
      error: error,
    };
    if (error) {
      dispatch(AuthSlice.actions.openNotification(data));
      dispatch(BookingTruckOrderSlice.actions.removerError());
    }
  }, [dispatch, error]);
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MySearchAddress />
      <MySearchResult />
      <MyCurrentLocationButton />
    </View>
  );
};
export default AddressSearchingUpdateOfSender;
