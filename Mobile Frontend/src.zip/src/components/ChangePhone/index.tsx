import {View} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import * as ProfileSelector from '@store/profile/shared/selector';
import {useSelector} from 'react-redux';
import Text from '@components/common/Texts/Text';
const ChangeFullName = () => {
  const navigation = useNavigate();
  const phone = useSelector(ProfileSelector.selectPhone);
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="phone_title" />
      <View style={styles.body}>
        <Text type="small" color={colors.blackText} isBold>
          phone_title
        </Text>
        <Text type="small" color={colors.blackText}>
          phone_otp_notice
        </Text>
        <View style={styles.pad}>
          <View style={styles.inputWrapper}>
            <Text type="small">{phone}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

export default ChangeFullName;
