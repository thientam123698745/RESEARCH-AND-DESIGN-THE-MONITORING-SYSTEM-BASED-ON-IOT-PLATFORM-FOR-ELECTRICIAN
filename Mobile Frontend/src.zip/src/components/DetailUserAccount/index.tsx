import React, {useCallback, useEffect, useMemo, useRef} from 'react';
import {styles} from './styles';
import MyHeaderAndAvatar from './MyHeaderAndAvatar';
import MyInformation from './MyInformation';
import {Text} from 'react-native-paper';
import BottomSheet from '@gorhom/bottom-sheet';
import {View} from 'react-native';
import ImageCropPicker from 'react-native-image-crop-picker';
import {useDispatch, useSelector} from 'react-redux';
import * as ProfileSelector from '@store/profile/shared/selector';
import * as ProfileSlice from '@store/profile/shared/slice';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import Button from '@components/common/Button/Button';

const DetailUserAccount = () => {
  useProfileInjector();
  const phone = useSelector(ProfileSelector.selectPhone);
  const showImgOption = useSelector(ProfileSelector.selectisShowOption);
  const dispatch = useDispatch();
  // ref
  const bottomSheetRef = useRef<BottomSheet>(null);

  // variables
  const snapPoints = useMemo(() => ['25%'], []);

  // callbacks
  const handleSheetChanges = useCallback((index: number) => {}, []);

  useEffect(() => {
    if (showImgOption) {
      bottomSheetRef.current.expand();
    } else {
      bottomSheetRef.current.close();
    }
  }, [showImgOption]);

  const handlePickImage = async () => {
    bottomSheetRef.current.close();
    try {
      const response = await ImageCropPicker.openPicker({
        width: 128,
        height: 128,
        cropping: true,
        includeBase64: true,
        cropperCircleOverlay: true,
      });
      if (response) {
        const data = response.data;
        const tmp_response = {
          phone_number: phone,
          avatar_new: `data:image/png;base64,${data}`,
        };
        dispatch(ProfileSlice.actions.changeAvatar(tmp_response));
      }
    } catch (error) {}
  };
  const handleTakePicture = async () => {
    bottomSheetRef.current.close();

    try {
      const response = await ImageCropPicker.openCamera({
        width: 128,
        height: 128,
        cropping: true,
        includeBase64: true,
        cropperCircleOverlay: true,
      });
      if (response) {
        const data = response.data;
        const tmp_response = {
          phone_number: phone,
          avatar_new: `data:image/png;base64,${data}`,
        };
        dispatch(ProfileSlice.actions.changeAvatar(tmp_response));
      }
    } catch (error) {}
  };
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MyHeaderAndAvatar />
      <MyInformation />
      <BottomSheet
        style={styles.bottomSheet}
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}>
        <View style={styles.contentContainer}>
          <Text>Choose Avatar</Text>
          <Button type="solid" onPress={handleTakePicture}>
            choose_from_camera
          </Button>
          <Button type="solid" onPress={handlePickImage}>
            choose_from_gallery
          </Button>
        </View>
      </BottomSheet>
    </View>
  );
};

export default DetailUserAccount;
