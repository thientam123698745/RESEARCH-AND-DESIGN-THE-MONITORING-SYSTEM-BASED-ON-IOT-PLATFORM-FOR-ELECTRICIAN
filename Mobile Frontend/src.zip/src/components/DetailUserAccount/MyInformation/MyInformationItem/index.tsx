import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';

const MyInformationItem = ({
  label,
  content,
  image,
  navigateAddress,
}: {
  label: string;
  content: string;
  image: any;
  navigateAddress: any;
}) => {
  const navigation = useNavigate();
  const handleNavigate = () => {
    navigation.navigate(navigateAddress);
  };
  return (
    <TouchableOpacity onPress={handleNavigate} style={styles.container}>
      <View style={styles.imgWrapper}>
        <Image source={image} style={styles.image} />
      </View>
      <View style={styles.textWrapper}>
        <View style={styles.labelWrapper}>
          <Text style={styles.label}>{label}</Text>
        </View>
        <View style={styles.contentWrapper}>
          <Text style={styles.content}>{content}</Text>
        </View>
      </View>
      <View style={styles.nextButtonWrapper}>
        <Image style={styles.caret} source={Images.CARET_LEFT} />
      </View>
    </TouchableOpacity>
  );
};

export default MyInformationItem;
