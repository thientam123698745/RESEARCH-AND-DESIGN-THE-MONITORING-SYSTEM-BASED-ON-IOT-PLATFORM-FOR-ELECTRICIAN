import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
    // borderBottomWidth: 1,
    // borderTopWidth: 1,
    // borderColor: colors.grey,
    backgroundColor: colors.white,
    marginVertical: MetricSizes.P_10 * 0.2,
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_20,
  },
  imgWrapper: {
    width: '10%',
  },
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  textWrapper: {
    width: '80%',
  },
  labelWrapper: {},
  label: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_10,
    color: colors.blackText,
  },
  contentWrapper: {},
  content: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    color: colors.blackText,
  },
  nextButtonWrapper: {
    width: '10%',
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  caret: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
});
