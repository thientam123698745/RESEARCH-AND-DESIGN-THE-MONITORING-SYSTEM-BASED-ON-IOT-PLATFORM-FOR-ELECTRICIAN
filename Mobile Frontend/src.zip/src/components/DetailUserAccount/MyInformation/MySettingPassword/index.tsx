import {View, Text, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';

const MySettingPassword = () => {
  const navigation = useNavigate();
  const handleNavigate = () => {
    navigation.navigate(routers.CHANGE_PASSWORD);
  };
  return (
    <TouchableOpacity onPress={handleNavigate} style={styles.container}>
      <View style={styles.imgWrapper}>
        <Image source={Images.AVT_PASSWORD} style={styles.image} />
      </View>
      <View style={styles.textWrapper}>
        <View style={styles.labelWrapper}>
          <Text style={styles.label}>Thiet lap mat khau</Text>
        </View>
      </View>
      <View style={styles.nextButtonWrapper}>
        <Image style={styles.caret} source={Images.CARET_LEFT} />
      </View>
    </TouchableOpacity>
  );
};

export default MySettingPassword;
