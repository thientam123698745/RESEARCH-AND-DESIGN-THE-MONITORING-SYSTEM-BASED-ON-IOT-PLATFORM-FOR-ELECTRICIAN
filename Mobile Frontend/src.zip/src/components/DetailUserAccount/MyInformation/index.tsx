import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MySettingPassword from './MySettingPassword';
import * as ProfileSelector from '@store/profile/shared/selector';
import {useSelector} from 'react-redux';
import {User} from '@store/models/Auth.model';
import {routers} from '@assets/constants/routers';
import MyInformationItem from '@components/DetailUserAccount/MyInformation/MyInformationItem';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import moment from 'moment';
import {GENDER, NOT_VALID_DATE} from '@assets/constants';
const MyInformation = () => {
  useProfileInjector();
  const user: User = useSelector(ProfileSelector.selectUser);
  const configGender = (gender: string) => {
    if (gender === GENDER.FEMALE) {
      return 'Nữ';
    }
    if (gender === GENDER.MALE) {
      return 'Nam';
    }
    if (gender === GENDER.OTHER) {
      return 'Khác';
    } else {
      return '';
    }
  };
  const data = [
    {
      image: require('assets/images/accInfoName-min.png'),
      label: 'Họ và tên',
      content: user.full_name ? user.full_name : 'Full Name',
      navigate: routers.CHANGE_FULL_NAME,
    },
    {
      image: require('assets/images/accInfoNickname-min.png'),
      label: 'Nickname',
      content: user.nick_name ? user.nick_name : 'Thêm nickname',
      navigate: routers.CHANGE_NICK_NAME,
    },
    {
      image: require('assets/images/accInfoBirth-min.png'),
      label: 'Ngày Sinh',
      content:
        user.birth.getTime() !== NOT_VALID_DATE.getTime()
          ? moment(user.birth).format('DD/MM/YYYY')
          : 'Thêm ngày, tháng năm sinh',
      navigate: routers.CHANGE_BIRTH,
    },
    {
      image: require('assets/images/accInfoGender-min.png'),
      label: 'Giới Tính',
      content: user.gender
        ? configGender(user.gender)
        : 'Thêm thông tin giới tính',
      navigate: routers.CHANGE_GENDER,
    },
    {
      image: require('assets/images/accInfoPhone-min.png'),
      label: 'Số điện thoại',
      content: user.phone_number ? user.phone_number : 'Thêm số điện thoại',
      navigate: routers.CHANGE_PHONE,
    },
    {
      image: require('assets/images/accInfoEmail-min.png'),
      label: 'Địa chỉ email',
      content: user.user_name ? user.user_name : 'abc@yahoo.com',
      navigate: routers.CHANGE_EMAIL,
    },
  ];
  return (
    <View style={styles.container}>
      {data.map((item, index) => {
        return (
          <MyInformationItem
            image={item.image}
            key={index}
            label={item.label}
            content={item.content}
            navigateAddress={item.navigate}
          />
        );
      })}
      <MySettingPassword />
    </View>
  );
};

export default MyInformation;
