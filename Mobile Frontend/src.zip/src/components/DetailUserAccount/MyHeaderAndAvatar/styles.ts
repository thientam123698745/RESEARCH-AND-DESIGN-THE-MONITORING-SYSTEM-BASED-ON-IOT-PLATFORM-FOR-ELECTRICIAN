import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
  },
  background: {
    height: '66%',
    // borderWidth: 1,
    width: '100%',
    backgroundColor: colors.primary,
    borderBottomRightRadius: MetricSizes.P_20,
    borderBottomLeftRadius: MetricSizes.P_20,
    position: 'absolute',
    top: 0,
  },
  labelWrapper: {
    width: '100%',
    height: '33%',
    // borderWidth: 1,
    padding: MetricSizes.P_20,
    // flexDirection: 'row',
  },
  label: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_16,
    color: colors.white,
    textAlign: 'center',
  },
  returnButton: {
    position: 'absolute',
    left: MetricSizes.P_20,
    top: MetricSizes.P_20,
  },
  return: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  headerAvatarWrapper: {
    height: '66%',
    // borderWidth: 1,
    // width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarWrapper: {},
  avatar: {
    width: 120,
    height: undefined,
    aspectRatio: 1 / 1,
    borderRadius: 60,
  },
  editButton: {
    position: 'absolute',
    right: 0,
    bottom: MetricSizes.P_20,
  },
  edit: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  modalContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    backgroundColor: colors.white,
    width: '80%',
    height: '50%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
