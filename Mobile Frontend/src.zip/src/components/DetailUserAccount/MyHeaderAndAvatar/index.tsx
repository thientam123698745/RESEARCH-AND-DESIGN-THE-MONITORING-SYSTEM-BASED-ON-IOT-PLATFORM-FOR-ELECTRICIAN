import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';
import * as ProfileSelector from '@store/profile/shared/selector';
import {useDispatch, useSelector} from 'react-redux';
import {User} from '@store/models/Auth.model';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import * as ProfileSlice from '@store/profile/shared/slice';
import LoadingPage from '@components/common/LoadingPage';
import Text from '@components/common/Texts/Text';
const MyHeaderAndAvatar = () => {
  useProfileInjector();
  const navigation = useNavigate();
  const avatar = useSelector(ProfileSelector.selectUser).avatar;
  const loading = useSelector(ProfileSelector.selectLoading);
  const dispatch = useDispatch();
  const handleReturn = () => {
    navigation.goBack();
  };
  const handleShowBottomSheet = () => {
    dispatch(ProfileSlice.actions.showImgOption());
  };
  useProfileInjector();
  const user: User = useSelector(ProfileSelector.selectUser);
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <View style={styles.background} />
      <View style={styles.labelWrapper}>
        <Text type="small">profile.account_information</Text>
        <TouchableOpacity onPress={handleReturn} style={styles.returnButton}>
          <Image source={Images.CARET_RIGHT} style={styles.return} />
        </TouchableOpacity>
      </View>
      <View style={styles.headerAvatarWrapper}>
        <View style={styles.avatarWrapper}>
          <Image
            source={{uri: avatar ? avatar : user.avatar}}
            style={styles.avatar}
          />
        </View>
        <TouchableOpacity
          onPress={handleShowBottomSheet}
          style={styles.editButton}>
          <Image source={Images.EDIT_AVT} style={styles.edit} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default MyHeaderAndAvatar;
