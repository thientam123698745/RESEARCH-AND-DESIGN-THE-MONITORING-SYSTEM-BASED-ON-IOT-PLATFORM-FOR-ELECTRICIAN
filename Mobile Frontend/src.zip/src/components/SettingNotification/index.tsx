import {View} from 'react-native';
import React from 'react';
import useNavigate from '@hooks/useNavigate';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import SquareHeader from '@components/Header/SquareHeader';
import SwitchOption from '@components/common/SwitchOption';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
const SettingNotification = () => {
  const data = [
    {
      text: 'Cập nhật đơn hàng',
      note: 'Thông báo các thông tin quan trọng về đơn hàng',
    },
    {
      text: 'Cập nhật từ 365 Truck',
      note: 'Các thông tin khuyến mãi, chính sách từ 365 Truck',
    },
    {text: 'Chat', note: 'Trò chuyện trực tiếp với nhà phân phối hoặc bác tài'},
    {text: 'Khác', note: 'Các thông báo khác'},
  ];
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <TransStatusBar />

      <SquareHeader navigation={navigation} text="Thiết lập thông báo" />
      <SwitchOption text={'Cho phép nhận thông báo'} />
      <View style={styles.view}>
        <Text type="small" isBold color={colors.blackText}>
          config_notification
        </Text>
        <Text type="small" color={colors.grey}>
          choose_content_notification
        </Text>
      </View>
      {data.map((item, index) => (
        <SwitchOption
          key={index}
          index={index}
          text={item.text}
          note={item.note}
        />
      ))}
    </View>
  );
};

export default SettingNotification;
