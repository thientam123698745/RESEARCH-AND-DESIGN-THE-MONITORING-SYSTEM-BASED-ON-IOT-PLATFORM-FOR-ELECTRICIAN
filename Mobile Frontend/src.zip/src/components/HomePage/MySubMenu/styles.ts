import {colors} from 'assets/colors';
import {WINDOW_HEIGHT} from 'assets/constants';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  truckListSeeALLWrapper: {
    flexDirection: 'row',
  },
  truckListSeeAllText: {
    color: colors.orange,
  },
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
    fontSize: 16,
  },
  backgroundImage: {borderRadius: 10},
  BottomBarButtonWrapper: {
    flexDirection: 'row',
    position: 'absolute',
    width: '100%',
    justifyContent: 'space-around',
    alignItems: 'center',
    top: WINDOW_HEIGHT * 0.02,
  },
  SubMenuWrapper: {
    backgroundColor: colors.white,
    borderRadius: 20,
    // minHeight: height * 3,
    marginTop: WINDOW_HEIGHT * 0.03,
    flexDirection: 'column',
  },
});
export default styles;
