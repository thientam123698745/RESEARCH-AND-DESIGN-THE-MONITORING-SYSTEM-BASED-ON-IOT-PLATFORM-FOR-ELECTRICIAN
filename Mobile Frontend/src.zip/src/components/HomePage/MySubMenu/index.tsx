import {View} from 'react-native';
import React from 'react';

import MyCategoriesBar from '../MyCategoriesBar';
import MyServiceBar from '../MyServiceBar';
import MyTruckList from '../MyTruckList';
import styles from './styles';
import MyVoucherBar from '../MyVoucherBar';
import MyBrandMenu from '../MyBrandMenu';

const MySubMenu = () => {
  return (
    <View style={styles.SubMenuWrapper}>
      <MyCategoriesBar />
      <MyVoucherBar />
      <MyServiceBar />
      <MyBrandMenu />
      <MyTruckList />
    </View>
  );
};
export default MySubMenu;
