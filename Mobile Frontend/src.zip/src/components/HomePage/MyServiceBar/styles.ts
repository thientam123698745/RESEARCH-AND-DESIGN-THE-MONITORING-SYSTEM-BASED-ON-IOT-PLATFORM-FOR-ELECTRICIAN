import MetricSizes from '@assets/constants/MetricSizes';
import {WINDOW_HEIGHT} from '@assets/constants';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  serviceWrapper: {
    padding: MetricSizes.P_20,
  },
  serviceTitle: {
    fontSize: WINDOW_HEIGHT * 0.022,
    textAlign: 'center',
  },
  serviceImage: {
    width: '80%',
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'contain',
  },
  serviceItemsWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    justifyContentAlign: 'center',
    marginTop: WINDOW_HEIGHT * 0.02,
  },
  serviceItemWrapper: {
    borderRadius: MetricSizes.small,
    backgroundColor: '#FFCC6A1A',
    width: '48%',
    height: undefined,
    aspectRatio: 1,
    marginBottom: MetricSizes.P_20,
  },
  touchableWrapper: {
    width: '100%',
    height: '100%',
    padding: MetricSizes.P_20,
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: MetricSizes.small,
  },
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
  },
});
export default styles;
