import {Image, View} from 'react-native';
import React from 'react';

import styles from './styles';

import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
import {SERVICE_DATA} from '@assets/data';
import {TouchableRipple} from 'react-native-paper';

const MyServiceBar = () => {
  const handleVoucher = () => {};
  return (
    <View style={styles.serviceWrapper}>
      <View>
        <Text
          type="small"
          isBold
          isCenter={false}
          color={colors.orange}
          style={styles.primaryTitle}>
          home_page.service_title
        </Text>
      </View>
      <View style={styles.serviceItemsWrapper}>
        {SERVICE_DATA.map(item => {
          return (
            <View key={item.id} style={styles.serviceItemWrapper}>
              <TouchableRipple
                borderless
                rippleColor={colors.blackText}
                onPress={handleVoucher}
                style={styles.touchableWrapper}>
                <>
                  <Image style={styles.serviceImage} source={item.image} />
                  <Text type="small" isBold style={styles.serviceTitle}>
                    {item.title}
                  </Text>
                </>
              </TouchableRipple>
            </View>
          );
        })}
      </View>
    </View>
  );
};

export default MyServiceBar;
