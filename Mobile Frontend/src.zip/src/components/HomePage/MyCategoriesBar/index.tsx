import {Image, TouchableOpacity, View} from 'react-native';
import React from 'react';

import {Images} from '@assets/constants/images';

import styles from './styles';

import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
import {CATEGORIES_SELL_DATA} from '@assets/data';
const MyCategoriesBar = () => {
  const handleVoucher = () => {};
  return (
    <View style={styles.CategoriesWrapper}>
      <View style={styles.subMenuCategoriesHeaderWrapper}>
        <Text
          type="small"
          color={colors.primary}
          isBold
          style={styles.primaryTitle}>
          home_page.tranfer_car
        </Text>
        <TouchableOpacity onPress={handleVoucher} style={styles.seeAllWrapper}>
          <Text type="small" color={colors.orange}>
            button.view_all
          </Text>
          <Image source={Images.YELLOW_ARROW} style={styles.viewAllImage} />
        </TouchableOpacity>
      </View>
      <View style={styles.subMenuCategoriesWrapper}>
        {CATEGORIES_SELL_DATA.map(item => (
          <TouchableOpacity
            key={item.id}
            onPress={handleVoucher}
            style={styles.categoryWrapper}>
            <Image style={styles.categoriesIcon} source={item.image} />
            <Text type="tiny" isBold>
              {item.title}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
};

export default MyCategoriesBar;
