import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  categoryWrapper: {
    justifyContent: 'space-around',
    textAlign: 'center',
    alignItems: 'center',
  },
  viewAllImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  subMenuCategoriesHeaderWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  subMenuCategoriesWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: WINDOW_HEIGHT * 0.02,
    // borderWidth: 1,
  },
  CategoriesWrapper: {
    padding: MetricSizes.P_20,
    borderBottomWidth: MetricSizes.P_10 * 0.5,
    borderColor: colors.greyLine,
  },
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
  },
  categoriesIcon: {
    width: MetricSizes.P_20 * 3,
    height: MetricSizes.P_20 * 3,
  },
  seeAllWrapper: {flexDirection: 'row', alignItems: 'center'},
});
export default styles;
