import {Image, ImageBackground, View} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';

import styles from './styles';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
import {TouchableRipple} from 'react-native-paper';

const MyBookCarBar = () => {
  const handleVoucher = () => {};
  return (
    <ImageBackground
      imageStyle={styles.image}
      source={Images.BACKGROUND}
      style={styles.bookCarWrapper}>
      <View style={styles.backgroundWrapper}>
        <View style={styles.titleWrapper}>
          <Text
            type="regular"
            isBold
            isCenter={false}
            color={colors.white}
            style={styles.bookCarText}>
            home_page.question
          </Text>
        </View>
        <View style={styles.buttonWrapper}>
          <TouchableRipple
            rippleColor={colors.white}
            onPress={handleVoucher}
            style={styles.bookCarButton}>
            <>
              <Text
                type="small"
                isBold
                color={colors.white}
                style={styles.bookCarPanelText}>
                button.book_now
              </Text>
              <Image source={Images.ARROW_UP} />
            </>
          </TouchableRipple>
        </View>
      </View>
      <View style={styles.imageWrapper}>
        <Image style={styles.linearGradientBackground} source={Images.LINEAR} />
      </View>
    </ImageBackground>
  );
};

export default MyBookCarBar;
