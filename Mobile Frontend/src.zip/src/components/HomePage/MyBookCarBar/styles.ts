import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import {StyleSheet} from 'react-native';
import {fonts, fontSize} from '@assets/fonts';
const styles = StyleSheet.create({
  bookCarText: {
    fontFamily: 'Work Sans ExtraBold',
    color: colors.white,
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: {width: -1, height: 1},
    textShadowRadius: 10,
    fontSize: fontSize.FS_24,
    textAlign: 'left',
  },
  imageWrapper: {
    borderRadius: MetricSizes.P_10,
    position: 'absolute',
    top: 0,
    right: 0,
    left: 0,
    bottom: 0,
  },
  titleWrapper: {
    zIndex: 2,
  },
  linearGradientBackground: {
    height: '100%',
    width: '100%',
    resizeMode: 'stretch',
    borderRadius: MetricSizes.P_10,
    opacity: 0.8,
    zIndex: 1,
  },
  backgroundWrapper: {
    padding: MetricSizes.P_20,
  },
  bookCarPanelText: {
    color: colors.white,
    fontFamily: fonts.SF_PRO_BOLD,
  },
  bookCarButton: {
    zIndex: 2,
    backgroundColor: colors.red,
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10 * 0.8,
    marginTop: MetricSizes.P_20,
    borderRadius: 8,
    justifyContent: 'space-evenly',
    alignItems: 'center',
  },

  bookCarWrapper: {
    zIndex: 0,
    borderRadius: MetricSizes.P_10,
    width: WINDOW_WIDTH - MetricSizes.P_10 * 2,
    alignSelf: 'center',
  },
  image: {
    borderRadius: MetricSizes.P_10,
  },
  buttonWrapper: {
    justifyContent: 'flex-end',
    alignItems: 'flex-start',
  },
});
export default styles;
