import {Image, ScrollView, StatusBar, View} from 'react-native';
import React from 'react';

import {Images} from '@assets/constants/images';

import styles from './styles';

import MyHeader from './MyHeader';
import MyBookCarBar from './MyBookCarBar';
import MySaleSlider from './MySaleSlider';
import MySubMenu from './MySubMenu';
import {colors} from '@assets/colors';
import {SafeAreaView} from 'react-native-safe-area-context';

const HomePage = () => {
  return (
    <SafeAreaView>
      <StatusBar backgroundColor={colors.white} barStyle="dark-content" />

      <Image
        resizeMode="repeat"
        source={Images.REPEAT}
        style={styles.waveBackground}
      />
      <View style={styles.container}>
        <ScrollView showsVerticalScrollIndicator={false}>
          <MyHeader />
          <MySaleSlider />
          <MyBookCarBar />
          <MySubMenu />
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

export default HomePage;
