import {View} from 'react-native';
import React from 'react';

import styles from './styles';
import MySlider from '@components/common/MySlider';
import {VOUCHER_SLIDER_DATA} from '@assets/data';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyVoucherBar = () => (
  <View style={styles.container}>
    <View style={styles.voucherWrapper}>
      <Text
        type="small"
        isCenter={false}
        isBold
        color={colors.red}
        style={styles.primaryTitle}>
        home_page.voucher_title
      </Text>
    </View>
    <View>
      <MySlider data={VOUCHER_SLIDER_DATA} />
    </View>
  </View>
);

export default MyVoucherBar;
