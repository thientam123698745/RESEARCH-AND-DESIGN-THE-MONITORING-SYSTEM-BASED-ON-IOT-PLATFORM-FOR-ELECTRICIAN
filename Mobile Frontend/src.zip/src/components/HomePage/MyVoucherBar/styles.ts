import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  voucherWrapper: {
    paddingHorizontal: MetricSizes.P_20,
    paddingTop: MetricSizes.P_10,
  },
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
    fontSize: 16,
  },
  container: {borderBottomWidth: 5, borderColor: colors.greyLine},
});
export default styles;
