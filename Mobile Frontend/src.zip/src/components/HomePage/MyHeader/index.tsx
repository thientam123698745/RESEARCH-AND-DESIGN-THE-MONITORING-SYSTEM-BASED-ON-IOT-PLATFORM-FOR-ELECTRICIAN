import {Image, TouchableOpacity, View, Text as RNText} from 'react-native';
import React, {useEffect} from 'react';
import styles from './styles';
import {Images} from '@assets/constants/images';

import {useDispatch, useSelector} from 'react-redux';
import * as ProfileSlice from '@store/profile/shared/slice';
import * as ProfileSelector from '@store/profile/shared/selector';
import useNavigate from '@hooks/useNavigate';
import {colors} from '@assets/colors';
import {routers} from '@assets/constants/routers';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import Text from '@components/common/Texts/Text';
import {TouchableRipple} from 'react-native-paper';
const MyHeader = () => {
  const navigation = useNavigate();
  useProfileInjector();
  const dispatch = useDispatch();
  const full_name = useSelector(ProfileSelector.selectFullName);
  const avatar = useSelector(ProfileSelector.selectAvatar);
  useEffect(() => {
    dispatch(ProfileSlice.actions.getUser());
  }, [dispatch]);
  let userFullName = 'user';
  if (full_name) {
    const userArr = full_name.split(' ');
    userFullName = userArr[userArr.length - 1];
  }
  function handleNavigationUser() {
    navigation.navigate(routers.PROFILE_PAGE);
  }
  function handleNavigationNotificationPage() {
    navigation.navigate(routers.SETTING_NOTIFICATION);
  }
  function handleSearch() {}
  return (
    <View style={styles.headerWrapper}>
      <View style={styles.backgroundWrapper} />
      <View style={styles.logoWrapper}>
        <Image style={styles.headerLogo} source={Images.LOGO} />
      </View>
      <View style={styles.textWrapper}>
        <View style={styles.titleWrapper}>
          <RNText>
            <Text color={colors.primary} isBold type="small">
              home_page.hello_text
            </Text>
            <Text color={colors.primary} isBold type="small">
              {` ${userFullName} !`}
            </Text>
          </RNText>
        </View>
        <View style={styles.buttonWrapper}>
          <TouchableOpacity
            style={styles.iconButtonWrapper}
            onPress={handleNavigationNotificationPage}>
            <Image style={styles.imageIcon} source={Images.BELL} />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.iconButtonWrapper}
            onPress={handleNavigationUser}>
            {avatar ? (
              <Image style={styles.imageIcon} source={{uri: avatar}} />
            ) : (
              <Image style={styles.imageIcon} source={Images.USER_ICON} />
            )}
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.inputContainer}>
        <TouchableRipple
          rippleColor={colors.blackText}
          onPress={handleSearch}
          style={styles.inputWrapper}>
          <>
            <View style={styles.searchImageWrapper}>
              <Image source={Images.SEARCH_ICON} style={styles.searchImage} />
            </View>
            <View style={styles.texWrapper}>
              <Text type="small" isCenter={false} style={styles.texText}>
                home_page.add_order
              </Text>
            </View>
          </>
        </TouchableRipple>
      </View>
    </View>
  );
};

export default MyHeader;
