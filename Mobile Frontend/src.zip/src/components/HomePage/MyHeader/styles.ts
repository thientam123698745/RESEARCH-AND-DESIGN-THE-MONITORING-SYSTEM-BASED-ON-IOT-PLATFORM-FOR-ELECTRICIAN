import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
import Common from '@assets/common/Common';
const styles = StyleSheet.create({
  headerWrapper: {},
  backgroundWrapper: {
    height: '70%',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.white,
    borderBottomEndRadius: MetricSizes.P_10,
    borderBottomStartRadius: MetricSizes.P_10,
  },
  textWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: MetricSizes.P_20,
    zIndex: 3,
  },
  iconButtonWrapper: {
    padding: MetricSizes.small,
  },
  headerLogo: {
    alignSelf: 'center',
    resizeMode: 'contain',
    width: '40%',
    height: undefined,
    aspectRatio: 100 / 35,
  },
  logoWrapper: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
    width: WINDOW_WIDTH,
    height: '60%',
  },
  imageIcon: {
    width: MetricSizes.P_20 * 1.5,
    height: undefined,
    aspectRatio: 1,
    resizeMode: 'contain',
  },
  bellButtonWrapper: {},
  buttonWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  headerTitle: {
    maxWidth: '35%',
    color: colors.primary,
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
    flexWrap: 'wrap',
  },
  titleWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputContainer: {
    paddingHorizontal: MetricSizes.regular,
  },
  inputWrapper: {
    flexDirection: 'row',
    backgroundColor: colors.white,
    borderRadius: MetricSizes.regular,
    padding: MetricSizes.big,
    alignItems: 'center',
    ...Common.shadow,
  },
  searchImageWrapper: {},
  searchImage: {},
  texWrapper: {
    flexGrow: 1,
  },
  texText: {},
});
export default styles;
