import {colors} from '@assets/colors';
import {WINDOW_HEIGHT, WINDOW_WIDTH} from '@assets/constants';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  waveBackground: {
    height: WINDOW_HEIGHT,
    width: WINDOW_WIDTH,
    backgroundColor: colors.primary,
    position: 'absolute',
    top: 0,
    zIndex: -1,
    opacity: 0.8,
  },
  container: {},
});
export default styles;
