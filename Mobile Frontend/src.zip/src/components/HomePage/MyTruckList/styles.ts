import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {WINDOW_HEIGHT, WINDOW_WIDTH} from '@assets/constants';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
    fontSize: 16,
  },
  truckListCategorieItem: {
    borderRadius: MetricSizes.small,
    borderColor: colors.primary,
    height: WINDOW_HEIGHT * 0.11,
    width: WINDOW_WIDTH * 0.2,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
    padding: MetricSizes.P_10 * 0.1,
  },
  truckListCategorieItemImage: {
    width: MetricSizes.P_40,
    height: MetricSizes.P_40,
    resizeMode: 'contain',
  },
  truckListSeeALLWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  touchableWrapper: {
    width: '100%',
    height: '100%',
    borderRadius: MetricSizes.small,
    justifyContent: 'center',
    alignItems: 'center',
  },
  imgWrapper: {
    height: '50%',
    // borderWidth: 1,
  },
  truckListSeeAllText: {
    color: colors.orange,
  },
  truckListHeaderText: {},
  truckListWrapper: {
    backgroundColor: '#F1F1F1',
    padding: MetricSizes.P_20,
  },
  truckListHeaderWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  truckListCategoriesWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  truckListMenuWrapper: {
    paddingTop: WINDOW_HEIGHT * 0.02,
    paddingBottom: WINDOW_HEIGHT * 0.11,
    //   paddingHorizontal:width * 0.1,
    zIndex: 5,
  },
  viewAllImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
export default styles;
