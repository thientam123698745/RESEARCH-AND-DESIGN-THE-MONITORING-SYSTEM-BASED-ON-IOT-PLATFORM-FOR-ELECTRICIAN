import {Image, TouchableOpacity, View} from 'react-native';
import React, {useEffect, useState} from 'react';

import {Images} from '@assets/constants/images';

import styles from './styles';
import {useDispatch, useSelector} from 'react-redux';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as TruckPostSlice from '@store/truckPost/shared/slice';
import {TruckPostSaga} from '@store/truckPost/shared/saga';
import useNavigate from '@hooks/useNavigate';
import {colors} from '@assets/colors';
import {selectListTruckPost} from '@store/truckPost/shared/selector';
import {TRUCK_LIST_CATEGORIES_DATA} from '@assets/data';
import Text from '@components/common/Texts/Text';
import {TouchableRipple} from 'react-native-paper';
const MyTruckList = () => {
  const [choice, setChoice] = useState(0);
  const navigation = useNavigate();
  const [pagination, setPagination] = useState(1);
  const handleVoucher = (id: any) => {
    setChoice(id);
  };
  const truckList = useSelector(selectListTruckPost);

  useInjectReducer({
    key: TruckPostSlice.sliceKey,
    reducer: TruckPostSlice.reducer,
  });
  useInjectSaga({
    key: TruckPostSlice.sliceKey,
    saga: TruckPostSaga,
  });
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(
      TruckPostSlice.actions.getTruckPost({id: choice, pagination: pagination}),
    );
  }, [choice, dispatch, pagination]);

  return (
    <View style={styles.truckListWrapper}>
      <View style={styles.truckListHeaderWrapper}>
        <Text
          isBold
          type="small"
          style={[styles.truckListHeaderText, styles.primaryTitle]}>
          home_page.news_feed
        </Text>
        <TouchableOpacity
          onPress={handleVoucher}
          style={styles.truckListSeeALLWrapper}>
          <Text
            type="small"
            color={colors.orange}
            style={styles.truckListSeeAllText}>
            button.view_all
          </Text>
          <Image style={styles.viewAllImage} source={Images.YELLOW_ARROW} />
        </TouchableOpacity>
      </View>
      <View style={styles.truckListCategoriesWrapper}>
        {TRUCK_LIST_CATEGORIES_DATA.map((item, index) => {
          return (
            <View
              key={index}
              style={[
                styles.truckListCategorieItem,
                {borderWidth: choice === item.id ? 1 : 0},
              ]}>
              <TouchableRipple
                style={styles.touchableWrapper}
                borderless
                rippleColor={colors.blackText}
                onPress={() => handleVoucher(item.id)}>
                <>
                  <View style={styles.imgWrapper}>
                    <Image
                      style={styles.truckListCategorieItemImage}
                      source={item.image}
                    />
                  </View>
                  <Text type="small" color={colors.blackText} isCenter>
                    {item.title}
                  </Text>
                </>
              </TouchableRipple>
            </View>
          );
        })}
      </View>
      <View style={styles.truckListMenuWrapper}>
        {/* <MyPaginationTruckList truckList={truckList} />
        <Text type="small">Nothing to show</Text> */}
      </View>
    </View>
  );
};

export default MyTruckList;
