import React from 'react';
import MySlider from '@components/common/MySlider';
import {ADS_SLIDER_DATA} from '@assets/data';
const MySaleSlider = () => {
  return <MySlider data={ADS_SLIDER_DATA} />;
};

export default MySaleSlider;
