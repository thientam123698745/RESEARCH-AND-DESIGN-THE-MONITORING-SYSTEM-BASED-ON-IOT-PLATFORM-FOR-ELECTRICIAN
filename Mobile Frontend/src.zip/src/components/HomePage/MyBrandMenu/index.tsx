import {Image, ImageBackground, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';

import styles from './styles';
import {colors} from '@assets/colors';
import {BRAND_DATA} from '@assets/data';
import Text from '@components/common/Texts/Text';
import {TouchableRipple} from 'react-native-paper';

const MyBrandMenu = () => {
  const handleVoucher = () => {};
  return (
    <ImageBackground source={Images.BG_BRAND} style={styles.brandCarWrapper}>
      <View style={styles.brandCarTextWrapper}>
        <Text
          type="small"
          color={colors.white}
          isBold
          style={[styles.primaryTitle]}>
          home_page.brand_car
        </Text>
        <TouchableOpacity
          onPress={handleVoucher}
          style={styles.truckListSeeALLWrapper}>
          <Text
            type="small"
            color={colors.orange}
            style={styles.truckListSeeAllText}>
            button.view_all
          </Text>
          <Image style={styles.viewAllImage} source={Images.YELLOW_ARROW} />
        </TouchableOpacity>
      </View>
      <View style={styles.brandListWrapper}>
        {BRAND_DATA.map(item => (
          <ImageBackground
            key={item.id}
            style={styles.brandItemWrapper}
            imageStyle={styles.brandItemImage}
            source={item.image}>
            <TouchableRipple
              rippleColor={colors.white}
              borderless
              onPress={handleVoucher}
              style={styles.touchableWrapper}>
              <></>
            </TouchableRipple>
          </ImageBackground>
        ))}
      </View>
    </ImageBackground>
  );
};

export default MyBrandMenu;
