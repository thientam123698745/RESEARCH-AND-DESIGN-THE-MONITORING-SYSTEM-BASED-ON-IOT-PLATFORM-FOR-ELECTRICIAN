import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {WINDOW_WIDTH} from '@assets/constants';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  brandCarWrapper: {
    // height: WINDOW_WIDTH,
    paddingVertical: MetricSizes.P_20,
    width: WINDOW_WIDTH,
  },
  brandCarTextWrapper: {
    padding: MetricSizes.P_20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  brandListWrapper: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  brandItemWrapper: {
    width: '48%',
    height: undefined,
    marginTop: MetricSizes.P_10,
    aspectRatio: 1,
    resizeMode: 'contain',
  },
  touchableWrapper: {
    width: '100%',
    height: undefined,
    aspectRatio: 1,
    borderRadius: MetricSizes.P_20,
  },
  brandItemImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'stretch',
  },
  truckListSeeALLWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  truckListSeeAllText: {
    color: colors.orange,
  },
  primaryTitle: {
    color: colors.primary,
    fontFamily: 'WorkSans-SemiBold',
    fontSize: 16,
  },
  viewAllImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
export default styles;
