import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 10,
    paddingVertical: MetricSizes.P_10,
  },
  view: {
    // flex: 1,
    backgroundColor: colors.white,
    paddingHorizontal: MetricSizes.P_10,
    paddingVertical: MetricSizes.P_20,
    borderRadius: MetricSizes.P_10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  status: {
    // flex: 1,
    justifyContent: 'space-around',
    paddingBottom: MetricSizes.P_10,
  },
  statusHeader: {
    flexDirection: 'row',
    // justifyContent: 'space-around',
  },
  statusBody: {
    flexDirection: 'row',
  },
  time: {
    paddingTop: MetricSizes.P_10,
    borderTopColor: colors.grey,
    borderTopWidth: 1,
    justifyContent: 'space-around',
  },
  image: {
    width: MetricSizes.P_10,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  caret: {
    width: MetricSizes.P_10,
    height: undefined,
    aspectRatio: 2 / 1,
    resizeMode: 'stretch',
  },
  imgWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '10%',
  },
  textWrapper: {
    width: '80%',
  },
  recWrapper: {
    position: 'absolute',
    left: 16,
    top: 10,
  },
  rec: {
    width: MetricSizes.P_10 * 0.3,
    height: MetricSizes.P_40 * 1.2,
  },
});
