import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import OrderTime from '@components/BookingTrackingDriver/OrderStatus/OrderTime';
import Text from '@components/common/Texts/Text';
const OrderStatus = ({code, text}: {code: number; text: string}) => {
  const initData = [
    {
      id: 0,
      title: 'Xác nhận đơn hàng',
      intendTime: {
        startTime: '17:00',
        endTime: '18:00',
      },
      realTime: '17:40',
      realDate: 'hôm nay',
    },
    {
      id: 1,
      title: 'Lấy hàng',
      intendTime: {
        startTime: '18:00',
        endTime: '19:00',
      },
      realTime: '19:30',
      realDate: 'hôm nay',
    },
    {
      id: 2,
      title: 'Giao hàng',
      intendTime: {
        startTime: '20:00',
        endTime: '21:00',
      },
      realTime: '21:45',
      realDate: 'hôm nay',
    },
  ];
  const status = initData[code];
  return (
    <View style={styles.container}>
      <View style={styles.view}>
        <OrderTime code={code} data={initData} text={text} />
        <View style={styles.time}>
          <View>
            <Text type="tiny" color={colors.grey}>
              plan_time
            </Text>
          </View>
          <View>
            <Text
              type="small"
              isBold
              color={
                colors.blackText
              }>{`${status.intendTime.startTime} - ${status.intendTime.endTime}`}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};
export default OrderStatus;
