import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const OrderTimeInactive = ({text, status}: {text: string; status: any}) => {
  const title = status.title;
  return (
    <View style={styles.container}>
      <View>
        <Image source={Images.GET_SHIPMENT} style={styles.imgShipment} />
      </View>
      <View style={styles.textWrapper}>
        <Text type="small" color={colors.blackText} isBold>
          {title}
        </Text>
        <Text type="small" color={colors.grey}>
          {text}
        </Text>
      </View>
    </View>
  );
};
export default OrderTimeInactive;
