import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    paddingVertical: MetricSizes.P_10,
  },
  textWrapper: {
    flexGrow: 1,
    paddingHorizontal: MetricSizes.P_10,
  },
  rec: {
    width: MetricSizes.P_10 * 0.3,
    height: undefined,
    resizeMode: 'stretch',
    aspectRatio: 1 / 10,
    position: 'absolute',
    left: MetricSizes.P_10 * 0.42,
    top: MetricSizes.P_10 * 1.5,
  },
  imgShipment: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  imgCaret: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 3 / 2,
    resizeMode: 'stretch',
  },
});
