import {View, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const OrderTimeActive = ({
  title,
  text,
  data,
  code,
}: {
  title: string;
  text: string;
  data: Array<any>;
  code: number;
}) => {
  const displayData = data.filter((item, index) => {
    return index < code;
  });
  return (
    <>
      {displayData.map((item, index) => (
        <View key={index} style={styles.container}>
          <View>
            <Image
              source={Images.GET_SHIPMENT_INACTIVE}
              style={styles.imgShipment}
            />
          </View>
          <View style={styles.textWrapper}>
            <Text type="small" color={colors.grey}>
              {`${item.title} (${item.realTime} - ${item.realDate})`}
            </Text>
          </View>
          <View style={styles.rec}>
            <Image source={Images.REC_GET_SHIPMENT} style={styles.rec} />
          </View>
        </View>
      ))}
      <View style={styles.container}>
        <View>
          <Image source={Images.GET_SHIPMENT} style={styles.imgShipment} />
        </View>
        <View style={styles.textWrapper}>
          <Text type="small" color={colors.blackText} isBold>
            {title}
          </Text>
          <Text type="small" color={colors.grey}>
            {text}{' '}
          </Text>
        </View>
      </View>
    </>
  );
};
export default OrderTimeActive;
