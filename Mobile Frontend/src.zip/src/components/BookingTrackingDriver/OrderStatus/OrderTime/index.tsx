import {View, TouchableOpacity, Image} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import OrderTimeActive from '@components/BookingTrackingDriver/OrderStatus/OrderTime/OrderTimeActive';
import OrderTimeInactive from '@components/BookingTrackingDriver/OrderStatus/OrderTime/OrderTimeInactive';
const OrderTime = ({
  code,
  data,
  text,
}: {
  code: number;
  data: Array<any>;
  text: string;
}) => {
  const status = data[code];
  const {title} = status;
  const [active, setActive] = useState(false);
  function handleActive() {
    setActive(!active);
  }
  return (
    <TouchableOpacity onPress={handleActive} style={styles.container}>
      {active ? (
        <OrderTimeActive text={text} title={title} data={data} code={code} />
      ) : (
        <OrderTimeInactive text={text} status={status} />
      )}
      <View style={styles.imgWrapper}>
        <Image
          source={active ? Images.CARET_UP : Images.CARET_DOWN}
          style={styles.img}
        />
      </View>
    </TouchableOpacity>
  );
};
export default OrderTime;
