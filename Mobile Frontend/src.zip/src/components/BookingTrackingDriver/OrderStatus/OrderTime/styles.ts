import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // flexDirection: 'row',
    justifyContent: 'space-around',
    paddingBottom: MetricSizes.P_10,
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 5 / 3,
    resizeMode: 'stretch',
  },
  imgWrapper: {
    position: 'absolute',
    top: MetricSizes.P_10,
    right: MetricSizes.P_10,
  },
});
