import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  mapContainer: {
    flex: 1,
    // backgroundColor: colors.red,
  },
  mapWrapper: {
    width: '100%',
    height: '100%',
  },
  informationContainer: {
    flex: 1,
    zIndex: 1,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    position: 'absolute',
  },
  mapViewContainer: {
    height: WINDOW_HEIGHT * 0.65,
    justifyContent: 'space-between',
    alignItems: 'center',
    // borderWidth: 1,
  },
  body: {
    flex: 81,
    // borderWidth: 1,
    paddingVertical: MetricSizes.P_10,
    // justifyContent: 'flex-end',
    // alignItems: 'center',
    marginHorizontal: MetricSizes.P_10,
  },
  top: {
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_10,
    margin: MetricSizes.P_10,
    padding: MetricSizes.P_10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  bottom: {
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_10,
    flexDirection: 'row',
    margin: MetricSizes.P_10,
    padding: MetricSizes.P_10,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: '60%',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  number: {
    paddingHorizontal: MetricSizes.P_10,
  },
  truckImageView: {
    // borderWidth: 1,
  },
  truckImage: {
    width: 35,
    height: undefined,
    aspectRatio: 2 / 1,
    resizeMode: 'stretch',
  },
  locationImage: {
    width: 35,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
});
