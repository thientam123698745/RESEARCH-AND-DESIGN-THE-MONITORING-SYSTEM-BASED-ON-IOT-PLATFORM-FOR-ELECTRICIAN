import {View, Text, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
const OrderDriver = () => {
  return (
    <View style={styles.container}>
      <View style={styles.view}>
        <View style={styles.driver}>
          <View style={styles.avtWrapper}>
            <Image source={Images.USER_ICON} style={styles.image} />
          </View>
          <View style={styles.textWrapper}>
            <View style={styles.textHeader}>
              <Text
                type="small"
                bold
                color={colors.blackText}
                text="NGUYỄN VĂN THANH"
              />
              <View style={styles.feedback}>
                <Image style={styles.star} source={Images.STAR_FEEDBACK} />
                <Text>5.00</Text>
              </View>
            </View>
            <Text
              type="small"
              color={colors.blackText}
              text="30G-00478 . Xe Van 500"
            />
          </View>
        </View>
        <View style={styles.option}>
          <View style={styles.optionItem}>
            <View style={styles.optionImgWrapper}>
              <Image source={Images.PHONE} style={styles.optionImage} />
            </View>
            <Text
              type="small"
              color={colors.primary}
              isBold
              text="Gọi Cho Tài Xế"
            />
          </View>
          <View style={styles.optionItem2}>
            <View style={styles.optionImgWrapper}>
              <Image source={Images.CHAT} style={styles.optionImage} />
            </View>
            <Text type="small" color={colors.primary} isBold text="Chat Ngay" />
          </View>
        </View>
      </View>
    </View>
  );
};
export default OrderDriver;
