import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 13,
    width: '100%',
  },
  view: {
    // flex: 1,
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.white,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  feedback: {
    paddingRight: MetricSizes.P_10,
    flexDirection: 'row',
    // alignItems: 'center',
  },
  driver: {
    borderBottomWidth: 1,
    borderColor: colors.grey,
    // flex: 3,
    flexDirection: 'row',
    alignItems: 'center',
  },
  option: {
    // borderWidth: 1,
    width: '100%',
    flexDirection: 'row',
    // justifyContent: 'space-around',
    marginVertical: MetricSizes.P_10,
  },
  avtWrapper: {
    // justifyContent: 'center',
    // alignItems: 'center',
    // borderWidth: 1,
    padding: MetricSizes.P_10,
    width: '20%',
  },
  image: {
    width: '100%',
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  textHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  textWrapper: {
    // height: '100%',
    flexGrow: 1,
    // borderWidth: 1,
    // justifyContent: 'space-around',
  },
  star: {
    width: MetricSizes.P_10 * 1.5,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  optionItem: {
    width: '50%',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    // flexGrow: 1,
  },
  optionItem2: {
    width: '50%',
    // flexGrow: 1,
    borderLeftWidth: 1,
    borderColor: colors.grey,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  optionImage: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
  },
  optionImgWrapper: {
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
