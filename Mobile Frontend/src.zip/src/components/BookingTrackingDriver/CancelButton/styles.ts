import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 12,
  },
  view: {
    flex: 1,
    // marginTop: MetricSizes.P_10,
    backgroundColor: colors.white,
    justifyContent: 'center',
    // alignItems: 'center',
    paddingHorizontal: MetricSizes.P_10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
});
