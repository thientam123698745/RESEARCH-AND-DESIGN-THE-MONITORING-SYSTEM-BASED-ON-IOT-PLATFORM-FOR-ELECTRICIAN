import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import Button from '@components/common/Button/Button';
const CancelButton = ({handleVisible}: {handleVisible: Function}) => {
  return (
    <View style={styles.container}>
      <View style={styles.view}>
        <Button type="solid" onPress={handleVisible}>
          cancel_order
        </Button>
      </View>
    </View>
  );
};
export default CancelButton;
