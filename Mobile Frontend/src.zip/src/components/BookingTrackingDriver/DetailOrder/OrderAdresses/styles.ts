import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 14,
    paddingHorizontal: MetricSizes.P_10,
    backgroundColor: colors.white,
    marginTop: MetricSizes.P_10,
    justifyContent: 'space-around',
    borderRadius: MetricSizes.P_10,
    paddingVertical: MetricSizes.P_10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
  },
  title: {
    paddingHorizontal: MetricSizes.P_10,
  },
  address: {
    width: '100%',
    flexDirection: 'row',
  },
  image: {
    width: '10%',
  },
  text: {
    width: '90%',
    paddingVertical: MetricSizes.P_10,
  },
});
