import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    // flex: 18,
    backgroundColor: colors.white,
    marginTop: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10,
    paddingVertical: MetricSizes.P_10,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
    marginBottom: MetricSizes.P_10,
  },
  text: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
  },
  textUnderlined: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderColor: colors.grey,
    alignItems: 'center',
  },
  bill: {
    // borderWidth: 1,
    // flex: 1,
    marginHorizontal: MetricSizes.P_20,
    justifyContent: 'space-around',
  },
});
