import {
  View,
  Modal,
  Image,
  TouchableOpacity,
  GestureResponderEvent,
} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const GetShipmentModal = ({
  visible,
  handleVisible,
  handleShare,
}: {
  visible: boolean;
  handleVisible: Function;
  handleShare: (event: GestureResponderEvent) => void;
}) => {
  return (
    <Modal visible={visible} transparent statusBarTranslucent>
      <View style={styles.container}>
        <View style={styles.view}>
          <View style={styles.titleWrapper}>
            <Text type="regular" color={colors.primary}>
              driver_already_taken_shipment
            </Text>
          </View>
          <View style={styles.contentWrapper}>
            <Text type="small" color={colors.blackText}>
              notification
            </Text>
          </View>
          <View style={styles.imageWrapper}>
            <Image
              source={Images.GET_SHIPMENT_SUCCESS}
              style={styles.imgShipment}
            />
          </View>
          <View style={styles.buttonWrapper}>
            <Button type="solid" onPress={handleVisible}>
              track_order
            </Button>
          </View>
          <View style={styles.linkWrapper}>
            <TouchableOpacity activeOpacity={0.8} onPress={handleShare}>
              <Text type="small" color={colors.primary} isCenter>
                share_location
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
};
export default GetShipmentModal;
