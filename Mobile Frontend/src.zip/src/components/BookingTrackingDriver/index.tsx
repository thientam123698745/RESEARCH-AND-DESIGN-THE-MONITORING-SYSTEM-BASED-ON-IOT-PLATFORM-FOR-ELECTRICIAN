import {
  View,
  ScrollView,
  NativeSyntheticEvent,
  Text as RNText,
  NativeScrollEvent,
  Image,
  ActivityIndicator,
} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {styles} from './styles';
import Header from '@components/BookingTrackingDriver/Header';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MapView, {Marker} from 'react-native-maps';
import {Images} from '@assets/constants/images';
import OrderStatus from '@components/BookingTrackingDriver/OrderStatus';
import OrderDriver from '@components/BookingTrackingDriver/OrderDriver';
import DetailOrder from '@components/BookingTrackingDriver/DetailOrder';
import CancelButton from '@components/BookingTrackingDriver/CancelButton';
import {colors} from '@assets/colors';
import CancelModal from '@components/BookingTrackingDriver/CancelModal';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import DriverGetShipmentModal from '@components/BookingTrackingDriver/DriverGetShipmentModal';
import MapViewDirections from 'react-native-maps-directions';
import {GOOGLE_API} from '@assets/constants';
import Text from '@components/common/Texts/Text';
import FoundModal from '@components/FindingDriver/FoundModal';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectSearchingLoading} from '@store/bookingTruckOrder/shared/selector';
const BookingTrackingDriver = () => {
  useBookingInjector();
  const isLoading = useSelector(selectSearchingLoading);
  const INIT_LOCATION = {
    latitude: 10.784774774774775,
    longitude: 106.72850750844884,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  };
  const navigation = useNavigate();
  const mapRef = useRef(null);
  const [closeModalVisible, setCloseModalVisible] = useState(false);
  const [driverGetShipmentVisible, setDriverGetShipmentVisible] =
    useState(false);
  const [isScroll, setIsScroll] = useState(false);
  const [visible, setVisible] = useState(true);
  function handleVisible() {
    setVisible(!visible);
  }
  function handleDetail() {
    navigation.navigate(routers.BOOKING_SHIPMENT_DETAIL);
  }
  function handleCloseModalVisible() {
    setCloseModalVisible(!closeModalVisible);
  }
  function handleContinue() {
    navigation.navigate(routers.BOTTOM_TABS);
  }
  function handleOnScroll(event: NativeSyntheticEvent<NativeScrollEvent>) {
    const positionScrollView = event.nativeEvent.contentOffset.y;
    if (positionScrollView === 0) {
      setIsScroll(true);
    } else {
      setIsScroll(false);
    }
  }
  function handleDriverGetShipmentVisible() {
    setDriverGetShipmentVisible(!driverGetShipmentVisible);
  }
  function handleDriverGetShipmentContinue() {
    //share location
  }
  useEffect(() => {
    // setTimeout(driverTracking, 1000);
    // setTimeout(driverIsShipping, 10000);
  }, []);

  return (
    <View style={styles.container}>
      <TransStatusBar color="dark-content" />
      <FoundModal
        visible={visible}
        handleVisible={handleVisible}
        handleContinue={handleDetail}
      />
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          onPoiClick={() => {}}
          showsUserLocation={true}
          style={styles.mapWrapper}
          region={INIT_LOCATION}>
          <Marker
            coordinate={{
              latitude: 10.784774774774775,
              longitude: 106.72850750844884,
            }}>
            <View style={styles.truckImageView}>
              <Image source={Images.TRUCK_ON_MAP} style={styles.truckImage} />
            </View>
          </Marker>
          <Marker
            coordinate={{
              latitude: 10.784774774774775,
              longitude: 106.83850750844884,
            }}>
            <Image source={Images.LOCATION2} style={styles.locationImage} />
          </Marker>
          <MapViewDirections
            origin={{
              latitude: 10.784774774774775,
              longitude: 106.72850750844884,
            }}
            destination={{
              latitude: 10.784774774774775,
              longitude: 106.83850750844884,
            }}
            apikey={GOOGLE_API}
            strokeWidth={3}
            strokeColor={colors.blackText}
          />
        </MapView>
      </View>
      <View style={styles.informationContainer}>
        <Header />
        <View style={styles.body}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            onScrollEndDrag={handleOnScroll}>
            <View style={styles.mapViewContainer}>
              {!isScroll ? (
                <>
                  <View style={styles.top}>
                    <RNText>
                      <Text type="small" color={colors.grey}>
                        driver_coming
                      </Text>
                      <Text type="small" color={colors.primary}>
                        short_address
                      </Text>
                      <Text type="small" color={colors.grey}>
                        please_wait
                      </Text>
                    </RNText>
                  </View>
                  <View style={styles.bottom}>
                    <View style={styles.number}>
                      <Text type="regular" color={colors.primary}>
                        3
                      </Text>
                    </View>
                    <View>
                      <Text type="small" color={colors.grey}>
                        predict_driver_coming_in
                      </Text>
                      <Text type="small" color={colors.grey}>
                        minute
                      </Text>
                    </View>
                  </View>
                </>
              ) : (
                <></>
              )}
            </View>
            <OrderStatus code={1} text="Tài xế đang trên đường đến lấy hàng" />
            <OrderDriver />
            <DetailOrder />
          </ScrollView>
        </View>
        <CancelButton handleVisible={handleCloseModalVisible} />
        <CancelModal
          visible={closeModalVisible}
          handleVisible={handleCloseModalVisible}
          handleContinue={handleContinue}
        />
        <DriverGetShipmentModal
          visible={driverGetShipmentVisible}
          handleVisible={handleDriverGetShipmentVisible}
          handleContinue={handleDriverGetShipmentContinue}
        />
      </View>
    </View>
  );
};
export default BookingTrackingDriver;
