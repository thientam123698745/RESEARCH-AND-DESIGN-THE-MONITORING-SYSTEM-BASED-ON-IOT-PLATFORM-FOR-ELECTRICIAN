import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.modal,
  },
  view: {
    backgroundColor: colors.white,
    width: '90%',
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'space-around',
    alignItems: 'center',
    borderRadius: MetricSizes.P_20,
    padding: MetricSizes.P_20,
  },
  titleView: {},
  titleText: {},
  driverViewImage: {
    width: '50%',
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  shareView: {},
});
