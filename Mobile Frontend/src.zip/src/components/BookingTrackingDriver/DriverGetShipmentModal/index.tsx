import {View, Modal, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const DriverGetShipmentModal = ({
  visible,
  handleVisible,
}: {
  visible: boolean;
  handleVisible: Function;
  handleContinue: Function;
}) => {
  return (
    <Modal visible={visible} transparent statusBarTranslucent>
      <View style={styles.container}>
        <View style={styles.view}>
          <Text type="regular" color={colors.primary}>
            driver_already_taken_shipment
          </Text>
          <Text type="small" isCenter color={colors.blackText}>
            notification
          </Text>
          <Image
            source={Images.GET_SHIPMENT_SUCCESS}
            style={styles.driverViewImage}
          />
          <Button type="solid" onPress={handleVisible}>
            track_order
          </Button>
          <TouchableOpacity activeOpacity={0.5} style={styles.shareView}>
            <Text type="small" color={colors.primary} isBold>
              share_location
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};
export default DriverGetShipmentModal;
