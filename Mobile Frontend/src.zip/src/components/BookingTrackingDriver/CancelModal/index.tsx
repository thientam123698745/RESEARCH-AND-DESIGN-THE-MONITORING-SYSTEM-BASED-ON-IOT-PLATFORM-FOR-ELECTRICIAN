import {View, Modal} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';
import TextInput from '@components/common/TextInput/TextInput';
import Button from '@components/common/Button/Button';
const CancelModal = ({
  visible,
  handleVisible,
  handleContinue,
}: {
  visible: boolean;
  handleVisible: Function;
  handleContinue: Function;
}) => {
  return (
    <Modal transparent statusBarTranslucent visible={visible}>
      <View style={styles.container}>
        <View style={styles.view}>
          <View style={styles.title}>
            <Text type="regular" color={colors.red}>
              cancel_order
            </Text>
          </View>
          <View style={styles.title}>
            <Text type="small" isBold color={colors.blackText}>
              cancel_order_question
            </Text>
          </View>
          <View style={styles.reasonInput}>
            <TextInput multiline placeholder="input_cancel_reason" />
          </View>
          <View style={styles.btnGroup}>
            <View style={styles.button}>
              <Button type="outline" onPress={handleVisible}>
                cancel
              </Button>
            </View>
            <View style={styles.button}>
              <Button type="outline" onPress={handleContinue}>
                delete_order
              </Button>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};
export default CancelModal;
