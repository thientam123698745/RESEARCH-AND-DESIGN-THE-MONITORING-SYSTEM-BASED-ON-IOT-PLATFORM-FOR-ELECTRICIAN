import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.modal,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view: {
    width: '86%',
    // height: undefined,
    // aspectRatio: 3 / 2,
    // justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10,
  },
  title: {
    paddingVertical: MetricSizes.P_10 * 0.5,
  },
  reasonInput: {
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.borderGray,
    marginVertical: MetricSizes.P_10,
    width: '96%',
    height: WINDOW_HEIGHT * 0.15,
    padding: MetricSizes.P_10,
  },
  btnGroup: {
    paddingVertical: MetricSizes.P_10,
    // borderWidth: 1,
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
  },
  button: {
    height: '100%',
    width: '46%',
  },
});
