import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import Text from '@components/common/Texts/Text';
const Header = () => {
  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <View style={styles.statusBar} />
        <View style={[styles.headerBar, styles.statusBar]}>
          <TouchableOpacity style={styles.imgWrapper}>
            <Image source={Images.CARET_DOWN} style={styles.caret} />
          </TouchableOpacity>
          <Text type="small" color={colors.blackText}>
            wait_driver
          </Text>
        </View>
      </View>
    </View>
  );
};
export default Header;
