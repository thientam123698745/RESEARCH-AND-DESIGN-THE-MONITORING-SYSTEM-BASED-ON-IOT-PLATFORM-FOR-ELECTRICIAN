import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  headerContainer: {
    borderRadius: MetricSizes.P_10,
    backgroundColor: colors.white,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,

    elevation: 5,
    flex: 1,
  },
  container: {
    backgroundColor: colors.white,
    flex: 12,
  },
  statusBar: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerBar: {
    width: '100%',
    borderTopWidth: 1,
    borderColor: colors.grey,
  },
  caret: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 3 / 2,
    resizeMode: 'stretch',
  },
  imgWrapper: {
    position: 'absolute',
    left: MetricSizes.P_10,
  },
});
