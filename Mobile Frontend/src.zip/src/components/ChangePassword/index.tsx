import {View} from 'react-native';
import React from 'react';
import Input from '@components/common/Input';
import {REGEX_LIST} from '@assets/constants';
import {useForm} from 'react-hook-form';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import {useDispatch, useSelector} from 'react-redux';
import * as ProfileSlice from '@store/profile/shared/slice';
import * as ProfileSelector from '@store/profile/shared/selector';
import LoadingPage from '@components/common/LoadingPage';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const NUMBER_OF_TEXT_INPUT = 3;
const ChangeBirth = () => {
  useProfileInjector();
  const {control, handleSubmit, formState} = useForm();
  const phone = useSelector(ProfileSelector.selectPhone);
  const loading = useSelector(ProfileSelector.selectLoading);

  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_TEXT_INPUT;
  const dispatch = useDispatch();
  const handleSave = ({
    password_new,
    password_old,
  }: {
    password_new: string;
    password_old: string;
  }) => {
    const requestData = {
      phone_number: phone,
      password_new,
      password_old,
    };

    dispatch(ProfileSlice.actions.changePassword(requestData));
  };
  const navigation = useNavigate();
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="MẬT KHẨU" />
      <View style={styles.body}>
        <Text type="small">error.password</Text>
        <View style={styles.pad}>
          <Text isBold type="small">
            placeholder.password
          </Text>

          <Input
            control={control}
            isPassword
            label="placeholder.old_password"
            rules={{
              required: true,
              minLength: 6,
              pattern: REGEX_LIST.PASSWORD,
            }}
            name="password_old"
            errMsg="error.password"
          />
          <Text isBold type="small">
            placeholder.new_password
          </Text>
          <Input
            control={control}
            isPassword
            label="placeholder.new_password"
            rules={{
              required: true,
              minLength: 6,
              pattern: REGEX_LIST.PASSWORD,
            }}
            name="password_new"
            errMsg="error.password"
          />
          <Text isBold type="small">
            placeholder.confirm_pasword
          </Text>
          <Input
            control={control}
            isPassword
            label="placeholder.confirm"
            rules={{
              required: true,
              minLength: 6,
              pattern: REGEX_LIST.PASSWORD,
            }}
            name="password_confirm"
            errMsg="error.password"
          />
        </View>
        <Button
          type="solid"
          disabled={countAtt}
          onPress={handleSubmit(handleSave)}>
          placeholder.choose_birth
        </Button>
      </View>
    </View>
  );
};

export default ChangeBirth;
