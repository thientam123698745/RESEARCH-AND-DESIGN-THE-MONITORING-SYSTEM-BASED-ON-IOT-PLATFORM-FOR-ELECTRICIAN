import {View} from 'react-native';
import React from 'react';
import styles from './styles';
import MyFormWrapper from './MyFormWrapper';
import MyOtherAccount from './MyOtherAccount';
import {useSelector} from 'react-redux';
import * as AuthSelector from '@store/auth/shared/selector';
import LoadingPage from '@components/common/LoadingPage';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import BigLogoHeader from '@components/Header/BigLogoHeader';
import {useAuthInjector} from '@hooks/useInjector/useAuthInjector';
const LoginPage = () => {
  useAuthInjector();
  const loading = useSelector(AuthSelector.selectLoading);

  return !loading ? (
    <View style={styles.container}>
      <TransStatusBar />
      <BigLogoHeader />
      <MyFormWrapper />
      <MyOtherAccount />
    </View>
  ) : (
    <LoadingPage message="Loginning In... " />
  );
};

export default LoginPage;
