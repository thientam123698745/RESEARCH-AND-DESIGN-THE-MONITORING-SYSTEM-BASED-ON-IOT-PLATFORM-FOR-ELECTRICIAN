import {WINDOW_WIDTH} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  formWrapper: {
    flex: 6,
    width: '100%',
    paddingHorizontal: WINDOW_WIDTH * 0.07,
    justifyContent: 'space-around',
  },
  label: {
    marginBottom: MetricSizes.P_20,
  },
});
export default styles;
