import {View} from 'react-native';
import React from 'react';
import styles from './styles';

import {useForm} from 'react-hook-form';

import {useDispatch} from 'react-redux';

import * as AuthSlice from '@store/auth/shared/slice';

import {REGEX_LIST} from '@assets/constants';

import {useAuthInjector} from '@hooks/useInjector/useAuthInjector';

import Text from '@components/common/Texts/Text';
import Input from '@components/common/Input';
import Button from '@components/common/Button/Button';

const NUMBER_OF_VALUE = 2;
const MyFormWrapper = () => {
  useAuthInjector();
  const {control, handleSubmit, formState} = useForm();
  const dispatch = useDispatch();
  const handleLoginCLick = (data: any) => {
    dispatch(AuthSlice.actions.signIn(data));
  };
  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_VALUE;

  return (
    <View style={styles.formWrapper}>
      <View style={styles.label}>
        <Text type="regular" isBold isCenter>
          welcome.title
        </Text>
      </View>
      <Input
        name="user_name"
        label={'placeholder.email'}
        control={control}
        isPassword={false}
        errMsg={'error.email_error'}
        rules={{
          required: true,
          minLength: 6,
          pattern: REGEX_LIST.EMAIL,
        }}
      />
      <Input
        name="password"
        control={control}
        label={'placeholder.password'}
        isPassword={true}
        errMsg={'error.password_error'}
        rules={{
          required: true,
          pattern: REGEX_LIST.PASSWORD,
        }}
      />
      <Button
        disabled={countAtt}
        type="solid"
        onPress={handleSubmit(handleLoginCLick)}>
        button.login
      </Button>
    </View>
  );
};

export default MyFormWrapper;
