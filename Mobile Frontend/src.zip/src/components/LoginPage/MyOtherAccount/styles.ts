import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  otherAccountWrapper: {
    flex: 3,
    width: '100%',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  otherAccountItemsWrapper: {
    flexDirection: 'row',
    justifyContent: 'center',
  },
  iconTwitter: {},
  icon: {},
  iconFacebook: {},
  iconGoogle: {
    paddingLeft: MetricSizes.P_20,
  },
});
export default styles;
