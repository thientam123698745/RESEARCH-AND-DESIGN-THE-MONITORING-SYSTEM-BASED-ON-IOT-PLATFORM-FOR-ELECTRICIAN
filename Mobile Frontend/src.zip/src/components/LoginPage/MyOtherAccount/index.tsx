import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import styles from './styles';
import {Images} from '@assets/constants/images';
import useNavigate from '@hooks/useNavigate';
import {colors} from '@assets/colors';
import {routers} from '@assets/constants/routers';
import {useInjectReducer, useInjectSaga} from 'redux-injectors';
import * as AuthSlice from '@store/auth/shared/slice';
import {AuthSaga} from '@store/auth/shared/saga';
import {useDispatch} from 'react-redux';
import Text from '@components/common/Texts/Text';
const MyOtherAccount = () => {
  const navigation = useNavigate();
  useInjectReducer({
    key: AuthSlice.sliceKey,
    reducer: AuthSlice.reducer,
  });
  useInjectSaga({
    key: AuthSlice.sliceKey,
    saga: AuthSaga,
  });
  const dispatch = useDispatch();
  const handleFacebookLogin = () => {
    dispatch(AuthSlice.actions.signInFacebook());
  };

  function handleForgotPassword() {
    navigation.navigate(routers.FORGOT_PASSWORD_PAGE_ENTER_PHONE);
  }
  function handleRegister() {
    navigation.navigate(routers.REGISTER);
  }

  return (
    <View style={styles.otherAccountWrapper}>
      <Text color={colors.grey} type="tiny">
        login.other_login_title
      </Text>

      <View style={styles.otherAccountItemsWrapper}>
        <TouchableOpacity
          onPress={handleFacebookLogin}
          style={styles.iconFacebook}>
          <Image style={styles.icon} source={Images.FACEBOOK} />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconGoogle}>
          <Image style={styles.icon} source={Images.GOOGLE} />
        </TouchableOpacity>
      </View>

      <Text
        type="small"
        onPress={handleForgotPassword}
        color={colors.blackText}>
        login.forgot_password_link
      </Text>

      <Text type="small" onPress={handleRegister} color={colors.primary}>
        login.sign_up_link
      </Text>
    </View>
  );
};

export default MyOtherAccount;
