import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  container: {
    height: '100%',
    minHeight: WINDOW_HEIGHT,
    // justifyContent: 'center',
    // alignItems: 'center',
    backgroundColor: colors.white,
    // flex: 1,
  },
});
export default styles;
