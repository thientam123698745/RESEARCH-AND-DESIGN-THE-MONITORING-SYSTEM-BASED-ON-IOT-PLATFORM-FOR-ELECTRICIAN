import React from 'react';

const MyIllustration = () => {
  return <></>;
};

export default MyIllustration;
