import {View} from 'react-native';
import React from 'react';
import {colors} from '@assets/colors';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import {styles} from './styles';
import useNavigate from '@hooks/useNavigate';
import * as ProfileSelector from '@store/profile/shared/selector';
import {useSelector} from 'react-redux';
import Text from '@components/common/Texts/Text';
const ChangeEmail = () => {
  const navigation = useNavigate();
  const email = useSelector(ProfileSelector.selectUser).user_name;
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="ĐỊA CHỈ EMAIL" />
      <View style={styles.body}>
        <Text type="small" color={colors.blackText} isBold>
          email
        </Text>
        <Text type="small" color={colors.blackText}>
          otp_notice
        </Text>
        <View style={styles.pad}>
          <View style={styles.inputWrapper}>
            <Text type="small">{email}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

export default ChangeEmail;
