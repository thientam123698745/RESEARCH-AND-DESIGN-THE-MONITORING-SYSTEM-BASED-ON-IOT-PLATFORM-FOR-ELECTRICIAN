import {View} from 'react-native';
import React from 'react';
import styles from './styles';
import Input from '@components/common/Input';
import {useForm} from 'react-hook-form';
import {REGEX_LIST} from '@assets/constants';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import {useTranslation} from 'react-i18next';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const NUMBER_OF_VALUE = 2;

const ForgotPasswordPage = () => {
  const {t} = useTranslation();
  const navigation = useNavigate();
  const {control, setError, handleSubmit, formState} = useForm();
  const countAtt =
    Object.keys(formState.dirtyFields).length !== NUMBER_OF_VALUE;
  const handleForgotPassword = (data: any) => {
    if (data.password != null || data.confirm != null) {
      if (data.password !== data.confirm) {
        setError('confirm', {
          type: 'confirm',
          message: t('placeholder.confirm'),
        });
      } else {
        navigation.navigate(routers.LOGIN_PAGE);
      }
    }
  };
  return (
    <View style={styles.container}>
      <Text type="regular" isCenter>
        forgot_password.title
      </Text>

      <View style={styles.pad}>
        <Text type="small" isCenter>
          forgot_password.text
        </Text>
      </View>
      <Input
        control={control}
        isPassword
        label={t('FG_PASSWORD_TEXT')}
        name="password"
        errMsg={t('placeholder.password')}
        rules={{
          required: true,
          pattern: REGEX_LIST.PASSWORD,
        }}
      />
      <Input
        errMsg={t('placeholder.confirm')}
        rules={{
          required: true,
          pattern: REGEX_LIST.PASSWORD,
        }}
        control={control}
        isPassword
        label={t('placeholder.confirm')}
        name="confirm"
      />
      <Button
        onPress={handleSubmit(handleForgotPassword)}
        type="solid"
        disabled={countAtt}>
        button.get_password_back
      </Button>
    </View>
  );
};

export default ForgotPasswordPage;
