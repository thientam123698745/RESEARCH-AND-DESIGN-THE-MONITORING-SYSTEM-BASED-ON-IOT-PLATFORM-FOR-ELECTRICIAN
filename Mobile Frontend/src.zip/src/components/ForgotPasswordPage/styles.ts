import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  btnWrapper: {},
  container: {
    flex: 1,
    backgroundColor: colors.white,
    paddingHorizontal: MetricSizes.P_20,
  },
  buttonWrapper: {
    flexGrow: 1,
  },
  pad: {
    paddingVertical: MetricSizes.P_20,
  },
  titleWrapper: {
    flex: 1,
    justifyContent: 'space-around',
  },
  wrapper: {
    borderWidth: 1,
    borderRadius: MetricSizes.P_10,
    borderColor: colors.blackGrey,
    backgroundColor: colors.greyLine,
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: MetricSizes.P_10,
    padding: MetricSizes.P_10 * 0.5,
  },
  text: {
    color: colors.blackText,
  },
  input: {
    width: '85%',
    color: colors.blackText,
  },
  codeWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '15%',
  },
  notice: {
    paddingTop: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
  },
});

export default styles;
