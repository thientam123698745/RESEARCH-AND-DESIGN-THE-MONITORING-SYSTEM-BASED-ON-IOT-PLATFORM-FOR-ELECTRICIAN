import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    // padding: MetricSizes.P_20,
    // borderWidth: 1,
  },
  body: {
    padding: MetricSizes.P_20,
  },
  pad: {
    paddingTop: MetricSizes.P_20,
  },
  radio: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
});
