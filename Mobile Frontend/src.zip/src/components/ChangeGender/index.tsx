import {View} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import {RadioButton} from 'react-native-paper';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
import {useDispatch, useSelector} from 'react-redux';
import * as ProfileSelector from '@store/profile/shared/selector';
import * as ProfileSlice from '@store/profile/shared/slice';
import {GENDER} from '@assets/constants';
import LoadingPage from '@components/common/LoadingPage';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const ChangeGender = () => {
  useProfileInjector();
  const gender = useSelector(ProfileSelector.selectUser).gender;
  const loading = useSelector(ProfileSelector.selectLoading);
  const phone = useSelector(ProfileSelector.selectPhone);
  const [value, setValue] = useState(gender);
  const dispatch = useDispatch();
  const handleSave = () => {
    const requestData = {
      phone_number: phone,
      gender_new: value,
    };
    dispatch(ProfileSlice.actions.changeGender(requestData));
  };
  const navigation = useNavigate();
  const handleOnChange = (data: any) => {
    setValue(data);
  };
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="GIỚI TÍNH" />
      <View style={styles.body}>
        <Text type="small" isBold>
          profile.gender
        </Text>
        <RadioButton.Group onValueChange={handleOnChange} value={value}>
          <View style={styles.radio}>
            <RadioButton value={GENDER.MALE} />
            <Text type="regular">profile.gender_male</Text>
          </View>
          <View style={styles.radio}>
            <RadioButton value={GENDER.FEMALE} />
            <Text type="regular">profile.gender_female</Text>
          </View>
          <View style={styles.radio}>
            <RadioButton value={GENDER.OTHER} />
            <Text type="regular">profile.gender_other</Text>
          </View>
        </RadioButton.Group>
        <Button type="solid" disabled={value === ''} onPress={handleSave}>
          button.save_changes
        </Button>
      </View>
    </View>
  );
};

export default ChangeGender;
