import {colors} from './../../../../assets/colors/index'; // TODO @nhan update absolute import
import distance from '@assets/constants/distance';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  text: {
    paddingHorizontal: distance.P_20,
  },
  container: {
    borderBottomLeftRadius: distance.P_20,
    borderBottomRightRadius: distance.P_20,
    marginBottom: distance.P_20,
    paddingBottom: distance.P_20,
    backgroundColor: colors.white,
  },
  wrapper: {
    paddingTop: distance.P_10,
    // borderBottomWidth: 1,
  },
});
