import {View} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import useNavigate from '@hooks/useNavigate';
import {useDispatch, useSelector} from 'react-redux';
import * as ProfileSelector from '@store/profile/shared/selector';
import {colors} from '@assets/colors';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import DatePicker from 'react-native-date-picker';
import BottomSheet, {BottomSheetView} from '@gorhom/bottom-sheet';
import {useRef, useMemo, useCallback} from 'react';
import moment from 'moment';
import * as ProfileSlice from '@store/profile/shared/slice';
import LoadingPage from '@components/common/LoadingPage';
import {NOT_VALID_DATE} from '@assets/constants';
import Text from '@components/common/Texts/Text';
import Button from '@components/common/Button/Button';
const ChangeBirth = () => {
  const handleSave = () => {
    bottomSheetRef.current.expand();
  };
  const navigation = useNavigate();
  const loading = useSelector(ProfileSelector.selectLoading);
  const dispatch = useDispatch();
  let userDate = useSelector(ProfileSelector.selectUserBirth);

  const phone = useSelector(ProfileSelector.selectPhone);
  const [tmpDate, setTmpDate] = useState(userDate);
  // ref
  const bottomSheetRef = useRef<BottomSheet>(null);

  // variables
  const snapPoints = useMemo(() => ['25%', '50%'], []);

  // callbacks
  const handleSheetChanges = useCallback(() => {}, []);

  const handleSubmitDate = () => {
    bottomSheetRef.current.close();
    const requestData = {
      phone_number: phone,
      birth_new: tmpDate,
    };
    dispatch(ProfileSlice.actions.changeBirth(requestData));
  };
  const handleDateChange = (date: Date) => {
    setTmpDate(date);
  };
  return loading ? (
    <LoadingPage message="loading.updating" />
  ) : (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader navigation={navigation} text="Ngày Sinh" />
      <View style={styles.body}>
        <Text type="small" color={colors.blackText} isBold>
          birth
        </Text>
        <View style={styles.text}>
          <Text type="small" isCenter color={colors.blackText}>
            {userDate.getTime() !== NOT_VALID_DATE.getTime()
              ? moment(tmpDate).format('DD/MM/YYYY')
              : 'Thêm ngày sinh'}
          </Text>
        </View>
        <Button type="solid" onPress={handleSave}>
          choose_birth
        </Button>
      </View>
      <BottomSheet
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        onChange={handleSheetChanges}>
        <BottomSheetView>
          <BottomSheetView style={styles.title}>
            <Text type="small" isCenter>
              placeholder.choose_birth
            </Text>
          </BottomSheetView>
          <DatePicker
            style={styles.datePicker}
            mode="date"
            onDateChange={handleDateChange}
            date={tmpDate}
          />
          <BottomSheetView style={styles.buttonWrapper}>
            <Button type="solid" onPress={handleSubmitDate}>
              button.save
            </Button>
          </BottomSheetView>
        </BottomSheetView>
      </BottomSheet>
    </View>
  );
};

export default ChangeBirth;
