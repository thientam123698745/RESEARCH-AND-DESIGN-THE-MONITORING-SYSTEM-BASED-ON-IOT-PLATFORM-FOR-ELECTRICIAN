import {WINDOW_WIDTH, WINDOW_HEIGHT} from '@assets/constants/index';
import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    // padding: MetricSizes.P_20,
    // borderWidth: 1,
  },
  body: {
    padding: MetricSizes.P_20,
  },
  pad: {
    paddingTop: MetricSizes.P_20,
  },
  text: {
    borderRadius: MetricSizes.P_10,
    borderWidth: 1,
    borderColor: colors.borderGray,
    backgroundColor: colors.greyLine,
    paddingHorizontal: MetricSizes.P_10 * 1.5,
    paddingVertical: MetricSizes.P_20,
    marginVertical: MetricSizes.P_10,
  },
  datePicker: {
    width: WINDOW_WIDTH,
    height: WINDOW_HEIGHT * 0.5 * 0.7,
    borderRadius: MetricSizes.P_40,
  },
  title: {
    paddingVertical: MetricSizes.P_10,
    borderBottomWidth: 1,
    borderColor: colors.grey,
    height: WINDOW_HEIGHT * 0.5 * 0.1,
  },
  buttonWrapper: {
    height: WINDOW_HEIGHT * 0.5 * 0.2,
    padding: MetricSizes.P_10,
  },
});
