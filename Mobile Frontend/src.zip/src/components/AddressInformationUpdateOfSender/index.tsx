import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {selectUpdateIndex} from '@store/bookingTruckOrder/shared/selector';
import React from 'react';
import {View} from 'react-native';
import {useSelector} from 'react-redux';
import MyTitle from './MyTitle';
import MyBody from './MyBody';
import MyButton from './MyButton';
import MyHeader from './MyHeader';
import MyReceiver from './MyReceiver';
import styles from './styles';

const AddressInformationUpdateOfSender = () => {
  useBookingInjector();
  const index = useSelector(selectUpdateIndex);
  return (
    <View style={styles.container}>
      <TransStatusBar color="light-content" />
      <MyHeader />
      <View style={styles.subContainer}>
        <MyTitle text="update_sender.address" index={`${index + 1}`} />
        <MyBody />
        <MyTitle text="update_sender.information" index={`${index + 1}`} />
        <MyReceiver />
      </View>
      <MyButton />
    </View>
  );
};

export default AddressInformationUpdateOfSender;
