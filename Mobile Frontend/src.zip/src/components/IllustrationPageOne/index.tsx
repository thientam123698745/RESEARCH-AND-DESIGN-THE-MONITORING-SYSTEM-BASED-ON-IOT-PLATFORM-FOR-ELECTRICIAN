import {Image, View} from 'react-native';
import React, {useEffect, useState} from 'react';
import {TouchableOpacity} from 'react-native';
import styles from './styles';
import Carousel, {Pagination} from 'react-native-snap-carousel';

import {Images} from '@assets/constants/images';

import * as AuthSelector from '../../store/auth/shared/selector'; // TODO @nhan update absolute import
import {useSelector} from 'react-redux';
import BlueBtn from '@components/common/Button/BlueBtn';
import BlueBorderBtn from '@components/common/Button/BlueBorderBtn';
import useNavigate from '@hooks/useNavigate';
import {WINDOW_WIDTH} from '@assets/constants';
import {texts} from '@assets/constants/texts';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import SmallDumpText from '@components/common/Texts/SmallDumpText';
import {colors} from '@assets/colors';
import BigDumpText from '@components/common/Texts/BigDumpText';
import {useAuthInjector} from '@hooks/useInjector/useAuthInjector';
import {SPLASH_SCREEN_DATA} from '@assets/data';
const IllustrationPageOne = () => {
  const navigation = useNavigate();
  let inputRef = React.useRef<any>('');
  const [isShowButtonLeft, setButtonLeft] = useState(false);
  const [activeSlide, setActiveSlide] = useState(0);
  useAuthInjector();
  const initScreen = useSelector(AuthSelector.selectInitScreen);
  useEffect(() => {
    if (initScreen === 'LoginPage') {
      navigation.navigate('LoginPage');
    }
  }, [initScreen, navigation]);
  React.useLayoutEffect(() => {
    navigation.setOptions({
      headerLeft: () =>
        isShowButtonLeft ? (
          <TouchableOpacity onPress={() => inputRef.current.snapToPrev()}>
            <Image
              style={styles.returnImage}
              source={Images.ARROW_SPLASH_SCREEN}
            />
          </TouchableOpacity>
        ) : (
          <></>
        ),
      headerRight: () => (
        <TouchableOpacity onPress={() => navigation.navigate('LoginPage')}>
          <SmallDumpText color={colors.white} text={texts.IL_SKIP} />
        </TouchableOpacity>
      ),
    });
  }, [navigation, isShowButtonLeft]);

  const _renderItem = ({item}: {item: any}) => {
    return (
      <View style={styles.ItemWrapper}>
        <View style={styles.ImageWrapper}>
          <Image style={styles.image} source={item.image} />
        </View>
        <View style={styles.ContentWrapper}>
          <View style={styles.textContentWrapper}>
            <BigDumpText center color={colors.blackText} text={item.title} />
            <SmallDumpText center color={colors.grey} text={item.content} />
          </View>

          {item.isNext ? (
            <View style={styles.buttonWrapper}>
              <BlueBtn
                label={texts.IL_CONTINUE}
                onPress={() => {
                  inputRef.current.snapToNext();
                }}
              />
            </View>
          ) : (
            <View style={styles.buttonWrapper}>
              <BlueBtn
                onPress={() => navigation.navigate('WelcomePage')}
                label={texts.IL_BEGIN_NOW}
              />
              <BlueBorderBtn
                onPress={() => navigation.navigate('LoginPage')}
                label={texts.IL_CREATE_ORDER}
              />
            </View>
          )}
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <TransStatusBar />
      <Carousel
        onSnapToItem={index => {
          setActiveSlide(index);
          if (index !== 0) {
            setButtonLeft(true);
          } else {
            setButtonLeft(false);
          }
        }}
        layout="default"
        activeAnimationType="decay"
        ref={inputRef}
        scrollEnabled={false}
        sliderWidth={WINDOW_WIDTH}
        itemWidth={WINDOW_WIDTH}
        data={SPLASH_SCREEN_DATA}
        renderItem={_renderItem}
      />
      <Pagination
        dotsLength={SPLASH_SCREEN_DATA.length}
        activeDotIndex={activeSlide}
        containerStyle={styles.containerPagination}
        dotStyle={styles.dotStylesContainer}
        inactiveDotStyle={styles.inactiveDotPagination}
        inactiveDotOpacity={0.4}
        inactiveDotScale={0.6}
      />
    </View>
  );
};

export default IllustrationPageOne;
