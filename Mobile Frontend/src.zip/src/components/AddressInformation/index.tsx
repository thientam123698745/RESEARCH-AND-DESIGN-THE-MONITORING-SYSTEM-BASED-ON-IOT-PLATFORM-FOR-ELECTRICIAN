import {View} from 'react-native';
import React from 'react';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import SquareHeader from '@components/Header/SquareHeader';
import useNavigate from '@hooks/useNavigate';
import Address from '@components/common/Address';
import {ADDRESS_INFORMATION} from '@assets/data';

const AddressInformation = () => {
  const navigation = useNavigate();
  const data = ADDRESS_INFORMATION;
  return (
    <View>
      <TransStatusBar />
      <SquareHeader text="address_information.title" navigation={navigation} />
      {data.map((item, index) => {
        return (
          <Address
            address={item.address}
            name={item.name}
            isDefaultAddress={item.isDefaultAddress}
            phone={item.phone}
            key={index}
          />
        );
      })}
    </View>
  );
};

export default AddressInformation;
