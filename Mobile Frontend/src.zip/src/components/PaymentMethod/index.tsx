import {Image, ScrollView, TouchableOpacity, View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import useNavigate from '@hooks/useNavigate';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import {RadioButton} from 'react-native-paper';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {PAYMENT_METHOD} from '@assets/data';
import {useDispatch, useSelector} from 'react-redux';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {selectPaymentMethod} from '@store/bookingTruckOrder/shared/selector';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import Text from '@components/common/Texts/Text';
const PaymentMethod = () => {
  const navigation = useNavigate();
  useBookingInjector();
  const checked = useSelector(selectPaymentMethod);
  const paymentMethods = PAYMENT_METHOD;
  const dispatch = useDispatch();
  function isChecked(name: string) {
    return checked === name + '' ? 'checked' : 'unchecked';
  }
  function handleChecked(name: string) {
    dispatch(BookingTruckOrderSlice.actions.setPaymentMethod(name));
  }
  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MediumLogoHeader text="Phương thức thanh toán" navigation={navigation} />
      <ScrollView>
        <View style={styles.wrapper}>
          <View style={styles.paymentWrapper}>
            {paymentMethods.map((item, index) => (
              <View
                key={index}
                style={[
                  styles.itemPaymentMethodWrapper,
                  {borderTopWidth: item.id === 0 ? 0 : 1},
                ]}>
                <View style={styles.radioWrapper}>
                  <RadioButton
                    onPress={() => handleChecked(item.name)}
                    value={item.name}
                    color={colors.orange}
                    status={isChecked(item.name)}
                  />
                </View>
                <View style={styles.imgWrapper}>
                  <Image source={item.image} style={styles.paymentImage} />
                </View>
                <View style={styles.textWrapper}>
                  <Text type="small" isBold color={colors.blackText}>
                    {item.name}
                  </Text>
                </View>
              </View>
            ))}
          </View>
          <View style={styles.otherPaymentWrapper}>
            <View style={styles.label}>
              <Text type="small" isBold color={colors.grey}>
                other_method_title
              </Text>
            </View>
            <View style={styles.otherPaymentBodyWrapper}>
              <TouchableOpacity
                onPress={() => handleChecked('Thẻ ATM')}
                style={styles.otherPaymentItemWrapper}>
                <View style={styles.otherPaymentItemHeader}>
                  <Image source={Images.CARD} style={styles.paymentImage} />
                  <View style={styles.text}>
                    <Text type="small">atm</Text>
                  </View>
                  <Image source={Images.CARET_LEFT} style={styles.arrowImg} />
                </View>
                <View style={styles.otherPaymentItemBody}>
                  <Text type="small" color={colors.grey}>
                    atm_title
                  </Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => handleChecked('Ví điện tử Momo')}
                style={styles.otherPaymentItemWrapper}>
                <View style={styles.otherPaymentItemHeader}>
                  <Image source={Images.MOMO} style={styles.paymentImage} />
                  <View style={styles.text}>
                    <Text type="small" color={colors.blackText}>
                      momo
                    </Text>
                  </View>
                  <Image source={Images.CARET_LEFT} style={styles.arrowImg} />
                </View>
                <View style={styles.otherPaymentItemBody}>
                  <Text type="small" color={colors.grey}>
                    atm_title
                  </Text>
                </View>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
};

export default PaymentMethod;
