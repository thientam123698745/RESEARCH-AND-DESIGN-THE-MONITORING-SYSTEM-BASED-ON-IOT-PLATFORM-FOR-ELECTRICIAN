import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
import {WINDOW_HEIGHT} from '@assets/constants';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.borderGray,
  },
  paymentWrapper: {
    marginBottom: MetricSizes.P_20,
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
  },
  otherPaymentWrapper: {},
  itemPaymentMethodWrapper: {
    backgroundColor: colors.white,
    paddingVertical: MetricSizes.P_20,
    flexDirection: 'row',
    alignItems: 'center',
    borderColor: colors.grey,
  },
  radioWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '10%',
  },
  imgWrapper: {
    justifyContent: 'center',
    alignItems: 'center',
    width: '20%',
  },
  textWrapper: {},
  paymentImage: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  label: {
    // borderWidth: 1,
    paddingVertical: MetricSizes.P_10,
  },
  otherPaymentBodyWrapper: {},
  otherPaymentItemWrapper: {
    // borderWidth: 1,
    minHeight: WINDOW_HEIGHT * 0.2,
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
    padding: MetricSizes.P_20,
    marginTop: MetricSizes.P_20,
    // flex: 1,
  },
  wrapper: {
    padding: MetricSizes.P_20,
  },
  otherPaymentItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.grey,
    flex: 1,
  },
  otherPaymentItemBody: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  paymentImg: {},
  arrowImg: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  text: {
    flexGrow: 1,
    paddingHorizontal: MetricSizes.P_20,
  },
});
