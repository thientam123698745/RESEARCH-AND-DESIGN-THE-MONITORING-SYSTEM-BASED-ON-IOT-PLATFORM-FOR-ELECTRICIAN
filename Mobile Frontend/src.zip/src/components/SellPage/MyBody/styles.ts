import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts} from 'assets/fonts';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  bodyFormWrapper: {
    padding: MetricSizes.P_20,
    flex: 5,
  },
  sellFormItemWrapper: {flex: 2},
  formTitle: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontWeight: 'bold',
  },
  formTextInput: {
    backgroundColor: colors.white,
    borderRadius: 8,
    marginVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
  },
  formItemWrapper: {
    flex: 1,
    // paddingVertical: MetricSizes.P_10,
  },
  imageWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_10,
  },
});
export default styles;
