import React from 'react';

const MyBody = () => {
  return <></>;
};

export default MyBody;
