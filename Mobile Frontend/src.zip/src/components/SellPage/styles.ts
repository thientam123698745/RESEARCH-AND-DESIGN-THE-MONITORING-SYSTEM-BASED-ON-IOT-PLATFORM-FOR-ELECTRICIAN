import {StyleSheet} from 'react-native';
import {colors} from 'assets/colors';

const styles = StyleSheet.create({
  MenuWrapper: {
    // height: height * 2.74,
    // backgroundColor: 'rgba(52, 52, 52, 0)',
    flex: 1,
  },
  container: {
    backgroundColor: colors.greyLine,
    flex: 1,
  },
});
export default styles;
