import {StatusBar, View} from 'react-native';
import React from 'react';

import {SafeAreaView} from 'react-native-safe-area-context';
import {colors} from '@assets/colors';

import styles from './styles';
import MyBody from './MyBody';
import MyFooter from './MyFooter';
import MyHeader from './MyHeader';
const SellPage = () => {
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar backgroundColor={colors.primary} />
      <View style={styles.MenuWrapper}>
        <MyHeader />
        <MyBody />
        <MyFooter />
      </View>
    </SafeAreaView>
  );
};
export default SellPage;
