import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts} from 'assets/fonts';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  footerButton: {
    backgroundColor: colors.primary,
    padding: MetricSizes.P_10,
    borderRadius: 10,
    width: '48%',
    margin: MetricSizes.P_20,
  },
  footerButtonText: {
    color: colors.white,
    textAlign: 'center',
    fontFamily: fonts.SF_PRO_BOLD,
    fontWeight: 'bold',
  },
  footerWrapper: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    padding: MetricSizes.P_10 * 0.5,
    backgroundColor: colors.white,
  },
  greyFooterButton: {
    padding: MetricSizes.P_10,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.grey,
    width: '48%',
    margin: MetricSizes.P_20,
  },
});
export default styles;
