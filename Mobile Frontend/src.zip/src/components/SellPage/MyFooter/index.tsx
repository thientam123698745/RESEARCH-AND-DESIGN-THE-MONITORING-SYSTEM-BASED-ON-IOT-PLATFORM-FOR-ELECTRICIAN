import React from 'react';
const MyFooter = () => {
  return <></>;
};

export default MyFooter;
