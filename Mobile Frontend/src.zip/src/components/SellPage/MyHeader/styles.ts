import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  headerWrapper: {
    paddingHorizontal: 20,
    backgroundColor: colors.primary,
    borderBottomEndRadius: 20,
    borderBottomStartRadius: 20,
    alignItems: 'center',
    padding: MetricSizes.P_20,
    zIndex: 2,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  closeButton: {
    alignSelf: 'center',
    position: 'absolute',
    left: MetricSizes.P_20,
    // alignItems: 'center',
    // justifyContent: 'center',
  },
});
export default styles;
