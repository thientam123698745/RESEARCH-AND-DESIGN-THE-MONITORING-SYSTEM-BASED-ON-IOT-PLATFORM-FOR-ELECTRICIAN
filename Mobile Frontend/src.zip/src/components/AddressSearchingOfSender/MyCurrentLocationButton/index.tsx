import {Image, TouchableOpacity} from 'react-native';

import React from 'react';

import styles from './styles';

import {Images} from '@assets/constants/images';
import {routers} from '@assets/constants/routers';
import useNavigate from '@hooks/useNavigate';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';

const MyCurrentLocationButton = () => {
  const navigation = useNavigate();
  const handleNavigate = () => {
    navigation.navigate(routers.ADDRESS_LOCATION_OF_SENDER);
  };
  return (
    <TouchableOpacity onPress={handleNavigate} style={styles.container}>
      <Image style={styles.locationDot} source={Images.LOCATION_DOT2} />
      <Text type="small" isCenter color={colors.primary} isBold>
        address_form.location_sender
      </Text>
    </TouchableOpacity>
  );
};

export default MyCurrentLocationButton;
