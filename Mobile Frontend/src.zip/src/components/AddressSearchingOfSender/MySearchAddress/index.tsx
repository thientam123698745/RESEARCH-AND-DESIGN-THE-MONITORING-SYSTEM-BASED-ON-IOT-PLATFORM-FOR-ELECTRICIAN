import React from 'react';

import {
  Image,
  ImageBackground,
  TextInput,
  TouchableOpacity,
  View,
  Text as RNText,
} from 'react-native';

import {Images} from '@assets/constants/images';

import styles from './styles';
import _ from 'lodash';
import {colors} from '@assets/colors';
import useNavigate from '@hooks/useNavigate';
import {SafeAreaView} from 'react-native-safe-area-context';
import {useDispatch, useSelector} from 'react-redux';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
// navigator.geolocation = require('react-native-geolocation-service');
import {
  selectSeachValue,
  selectSenderAddress,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
import {useTranslation} from 'react-i18next';
const MySearchAddress = () => {
  const {t} = useTranslation();
  const navigation = useNavigate();
  const handleGoBack = () => {
    navigation.goBack();
  };
  useBookingInjector();
  const dispatch = useDispatch();
  const searchValue = useSelector(selectSeachValue);
  const senderAddress = useSelector(selectSenderAddress);
  const index = senderAddress.length + 1;
  function handleClear() {
    dispatch(BookingTruckOrderSlice.actions.clearSearchValue());
  }
  function handleSearchValue(text: string) {
    _.debounce(function () {
      dispatch(BookingTruckOrderSlice.actions.searchingValue(text));
    }, 2000);
  }
  return (
    <ImageBackground
      style={styles.container}
      resizeMode="stretch"
      imageStyle={styles.img}
      source={Images.BG_BOOK_CAR}>
      <SafeAreaView style={styles.searchWrapper}>
        <View style={styles.titleWrapper}>
          <TouchableOpacity onPress={handleGoBack} style={styles.returnWrapper}>
            <Image style={styles.returnImage} source={Images.TT_RETURN} />
          </TouchableOpacity>
          <View style={styles.returnText}>
            <RNText>
              <Text type="small" color={colors.white}>
                address_form.sender_title
              </Text>
              <Text type="small" color={colors.white}>
                {` ${index}`}
              </Text>
            </RNText>
          </View>
        </View>
        <View style={styles.searchTextInputWrapper}>
          <View style={styles.searchTextInput}>
            <View style={styles.searchTextInputPositionDot}>
              <Image
                source={Images.LOCATION_DOT}
                style={styles.searchTextInputPositionDotImage}
              />
            </View>
            <TextInput
              style={styles.searchTextInputInput}
              placeholder={t('placeholder.location')}
              value={searchValue}
              onChangeText={handleSearchValue}
            />
            <TouchableOpacity
              onPress={handleClear}
              style={styles.searchTextInputCloseDot}>
              <Image
                source={Images.CLOSE_MODAL_BUTTON}
                style={styles.searchTextInputCloseDotImage}
              />
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </ImageBackground>
  );
};

export default MySearchAddress;
