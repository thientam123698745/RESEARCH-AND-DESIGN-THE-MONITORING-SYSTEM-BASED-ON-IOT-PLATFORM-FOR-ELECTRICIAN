import {View} from 'react-native';
import React from 'react';
import styles from './styles';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import MySearchAddress from './MySearchAddress';
import MyCurrentLocationButton from './MyCurrentLocationButton';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import MySearchResult from './MySearchResult/MySearchResult';
const AddressSearchingOfSender = () => {
  useBookingInjector();

  return (
    <View style={styles.container}>
      <TransStatusBar />
      <MySearchAddress />
      <MySearchResult />
      <MyCurrentLocationButton />
    </View>
  );
};
export default AddressSearchingOfSender;
