import {styles} from './styles';
import React from 'react';
import {Text, View} from 'react-native';

const MapComponent = () => {
  return (
    <View style={styles.container}>
      <Text>Coming Soon ...</Text>
    </View>
  );
};

export default MapComponent;
