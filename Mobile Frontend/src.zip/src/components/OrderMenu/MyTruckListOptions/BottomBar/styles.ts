import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  bottomWrapper: {
    borderTopRightRadius: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
    borderWidth: 1,
    borderColor: colors.grey,
    position: 'absolute',
    bottom: 0,
    width: '100%',
    height: '15%',
    paddingVertical: MetricSizes.P_20,
    alignItems: 'center',
    backgroundColor: colors.white,
  },
  textButton: {
    fontWeight: 'bold',
    color: colors.white,
    paddingHorizontal: MetricSizes.P_10,
  },
  imageWrapper: {},
  button: {
    padding: MetricSizes.P_10 * 1,
    width: '90%',
    justifyContent: 'center',
    flexDirection: 'row',
    backgroundColor: colors.primary,
    borderRadius: MetricSizes.P_10,
  },
  img: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    resizeMode: 'stretch',
  },
  header: {},
  body: {},
});
