import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectCheckedId,
  selectCheckedQuantity,
  selectPickedTrucks,
  selectTrucks,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {colors} from '@assets/colors';
const BottomBar = () => {
  useBookingInjector();
  const dispatch = useDispatch();
  const checked = useSelector(selectCheckedId);
  const quantity = useSelector(selectCheckedQuantity);
  const trucks = useSelector(selectTrucks);
  const pickedTrucks = useSelector(selectPickedTrucks);
  function configData() {
    const index = trucks.findIndex(item => item.id === checked);
    return {
      trucks,
      selectedTruck: {
        id: checked,
        truck: trucks[index],
        quantity,
      },
      pickedTrucks,
    };
  }
  function handleAddTruck() {
    dispatch(BookingTruckOrderSlice.actions.addSelectedTruck(configData()));
  }
  return (
    <View style={styles.bottomWrapper}>
      <TouchableOpacity
        onPress={handleAddTruck}
        style={[
          styles.button,
          {backgroundColor: trucks.length === 0 ? colors.grey : colors.primary},
        ]}
        disabled={trucks.length === 0}>
        <View style={styles.imageWrapper}>
          <Image source={Images.PLUS} style={styles.img} />
        </View>
        <Text style={styles.textButton}>Thêm Xe Vận Chuyển</Text>
      </TouchableOpacity>
    </View>
  );
};

export default BottomBar;
