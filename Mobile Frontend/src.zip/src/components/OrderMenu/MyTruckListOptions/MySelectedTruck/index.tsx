import {View, Image, TouchableOpacity} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import MetricSizes from '@assets/constants/MetricSizes';
import Text from '@components/common/Texts/Text';
const MySelectedTruck = ({
  item,
  min,
  max,
  setQuantity,
  handleDelete,
}: {
  item: any;
  min?: number;
  max?: number;
  setQuantity: Function;
  handleDelete: Function;
}) => {
  const quantity = item.quantity;
  const id = item.truck.id;
  const [isEdited, setIsEdited] = useState(false);

  const handlePlus = () => {
    if (quantity < max) {
      setQuantity(quantity + 1, id);
    }
  };
  const handleMinus = () => {
    if (quantity > min) {
      setQuantity(quantity - 1, id);
    }
  };
  const isQuantityMin = min === quantity;
  const isQuantityMax = max === quantity;
  const handleVisibleEditQuantity = () => {
    setIsEdited(!isEdited);
  };
  return (
    <View
      style={{
        paddingHorizontal: MetricSizes.P_20,
        paddingVertical: MetricSizes.P_10,
        borderTopWidth: 1,
        borderTopColor: isEdited ? colors.primary : colors.grey,
      }}>
      <View style={styles.text}>
        <Text type="small" color={colors.blackText} isBold>
          shipment_truck
        </Text>
      </View>
      <View style={styles.modalContainer}>
        <View style={styles.imgWrapper}>
          <Image style={styles.img} source={Images.TRUCK_ICON} />
        </View>
        <View style={styles.textWrapper}>
          <View>
            <Text type="small" color={colors.blackText} isBold>
              {item.truck.name}
            </Text>
          </View>
          <View style={styles.descWrapper}>
            <View>
              <Text type="tiny" color={colors.blackText} isTruncated={false}>
                {`${item.truck.description} . ${item.truck.weight}`}
              </Text>
            </View>
          </View>
          {isEdited ? (
            <View style={styles.quantityWrapper}>
              <Text type="small">Số lượng</Text>
              <View style={styles.quantityInputWrapper}>
                <TouchableOpacity
                  disabled={isQuantityMin}
                  onPress={handleMinus}
                  style={[
                    styles.minus,
                    {
                      backgroundColor: isQuantityMin
                        ? colors.borderGray
                        : colors.primary,
                    },
                  ]}>
                  <Text type="small" style={{color: colors.blackText}}>
                    -
                  </Text>
                </TouchableOpacity>
                <View style={styles.quantity}>
                  <Text type="small">{quantity}</Text>
                </View>
                <TouchableOpacity
                  disabled={isQuantityMax}
                  onPress={handlePlus}
                  style={[
                    styles.plus,
                    {
                      backgroundColor: isQuantityMax
                        ? colors.grey
                        : colors.primary,
                    },
                  ]}>
                  <Text type="small" style={{color: colors.white}}>
                    +
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : (
            <View style={styles.quantityWrapper}>
              <Text type="small">Số lượng</Text>
              <View style={styles.quantityInputWrapper}>
                <View style={styles.quantity}>
                  <Text type="small">{quantity}</Text>
                </View>
              </View>
            </View>
          )}
        </View>
        <View style={styles.selection}>
          <TouchableOpacity onPress={handleVisibleEditQuantity}>
            <Text type="small" color={colors.primary}>
              edit
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => handleDelete(id)}>
            <Text type="small" color={colors.red}>
              delete
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

export default MySelectedTruck;
