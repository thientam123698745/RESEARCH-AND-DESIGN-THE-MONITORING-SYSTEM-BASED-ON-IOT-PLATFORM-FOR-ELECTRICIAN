import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  text: {},
  imgWrapper: {
    width: '20%',
    // borderWidth: 1,
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
  },
  img: {
    width: MetricSizes.P_40,
    height: undefined,
    aspectRatio: 3 / 2,
    resizeMode: 'stretch',
  },
  descWrapper: {
    flexDirection: 'row',
  },
  modalContainer: {
    // paddingHorizontal: MetricSizes.P_20,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  textWrapper: {
    width: '60%',
    justifyContent: 'space-around',
    // borderWidth: 1,
  },
  selection: {
    width: '20%',
    justifyContent: 'space-around',
    alignItems: 'flex-end',
    // borderWidth: 1,
  },
  quantityWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  minus: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    // borderWidth: 1,
    margin: MetricSizes.P_10,
  },
  quantity: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  plus: {
    width: MetricSizes.P_20,
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    borderRadius: 5,
    margin: MetricSizes.P_10,
  },
  quantityInputWrapper: {
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_10,
  },
});
