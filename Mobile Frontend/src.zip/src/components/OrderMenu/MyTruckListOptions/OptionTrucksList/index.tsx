import {View} from 'react-native';

import React from 'react';

import {styles} from './styles';

import {colors} from '@assets/colors';

import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';

import {useDispatch, useSelector} from 'react-redux';

import {
  selectCheckedId,
  selectCheckedQuantity,
  selectTrucks,
} from '@store/bookingTruckOrder/shared/selector';

import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';

import MyTruckOption from '../MyTruckOption';
import Text from '@components/common/Texts/Text';

const OptionTruckList = () => {
  useBookingInjector();
  const dispatch = useDispatch();
  const trucks = useSelector(selectTrucks);
  const checkedQuantity = useSelector(selectCheckedQuantity);
  const checkedId = useSelector(selectCheckedId);
  function onChecked(id: number) {
    dispatch(BookingTruckOrderSlice.actions.setCheckedId(id));
  }
  function onChangeQuantity(quantity: number) {
    dispatch(BookingTruckOrderSlice.actions.setCheckedQuantity(quantity));
  }
  const _renderItems = (item: any, index: number) => {
    return !item.isSelected ? (
      <MyTruckOption
        key={index}
        item={item}
        checked={checkedId}
        min={1}
        max={item.quantity}
        quantity={checkedQuantity}
        setQuantity={onChangeQuantity}
        onChecked={onChecked}
      />
    ) : (
      <></>
    );
  };

  return trucks.length === 0 ? (
    <></>
  ) : (
    <View style={styles.wrapper}>
      <View style={styles.text}>
        <Text type="small" color={colors.blackText} isBold>
          truck_list
        </Text>
      </View>
      {trucks.map((item: any, index: number) => _renderItems(item, index))}
    </View>
  );
};

export default OptionTruckList;
