import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  wrapper: {
    paddingVertical: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
    borderTopRightRadius: MetricSizes.P_20,
    backgroundColor: colors.white,
    flexGrow: 1,
  },
  text: {
    paddingHorizontal: MetricSizes.P_20,
  },
});
