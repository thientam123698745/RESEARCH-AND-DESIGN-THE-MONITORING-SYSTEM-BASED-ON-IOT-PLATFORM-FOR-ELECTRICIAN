import {View, Modal, ScrollView} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import OptionTruckList from './OptionTrucksList';
import BottomBar from './BottomBar';
import PickedTrucksList from './PickedTrucksList';

const MyTruckListOptions = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: Function;
}) => {
  const handleClose = () => {
    setVisible(!visible);
  };

  return (
    <Modal
      statusBarTranslucent
      transparent
      visible={visible}
      onRequestClose={handleClose}>
      <View style={styles.container}>
        <MediumLogoHeader
          text="Chọn loại xe vận chuyển"
          onPress={handleClose}
        />
        <View style={styles.truckWrapper}>
          <ScrollView>
            <PickedTrucksList />
            <OptionTruckList />
          </ScrollView>
        </View>
        <BottomBar />
      </View>
    </Modal>
  );
};

export default MyTruckListOptions;
