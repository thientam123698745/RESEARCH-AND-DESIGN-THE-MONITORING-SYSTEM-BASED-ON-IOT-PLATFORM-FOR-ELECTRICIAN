import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import {RadioButton} from 'react-native-paper';
import Text from '@components/common/Texts/Text';
const MyTruckOption = ({
  item,
  checked,
  min,
  max,
  onChecked,
  quantity,
  setQuantity,
}: {
  item: any;
  checked: number;
  min?: number;
  max?: number;
  onChecked: Function;
  quantity: number;
  setQuantity: Function;
}) => {
  const handleChecked = () => {
    onChecked(item.id);
  };
  const handlePlus = () => {
    if (quantity < max) {
      setQuantity(quantity + 1);
    }
  };
  const handleMinus = () => {
    if (quantity > min) {
      setQuantity(quantity - 1);
    }
  };
  const isQuantityMin = min === quantity;
  const isQuantityMax = max === quantity;
  const isChecked = checked === item.id ? 'checked' : 'unchecked';
  return (
    <View
      style={[
        styles.modalContainer,
        {
          borderBottomColor: checked === item.id ? colors.primary : colors.grey,
        },
      ]}>
      <View style={styles.imgWrapper}>
        <Image style={styles.img} source={Images.TRUCK_ICON} />
      </View>
      <View style={styles.textWrapper}>
        <View>
          <Text type="small" color={colors.blackText} isBold>
            {item.name}
          </Text>
        </View>
        <View style={styles.descWrapper}>
          <View>
            <Text
              type="tiny"
              color={colors.blackText}
              isTruncated={
                false
              }>{`${item.description} . ${item.weight}`}</Text>
          </View>
        </View>
        {checked === item.id ? (
          <View style={styles.quantityWrapper}>
            <Text type="small">Số lượng</Text>
            <View style={styles.quantityInputWrapper}>
              <TouchableOpacity
                disabled={isQuantityMin}
                onPress={handleMinus}
                style={[
                  styles.minus,
                  {
                    backgroundColor: isQuantityMin
                      ? colors.borderGray
                      : colors.primary,
                  },
                ]}>
                <Text
                  type="small"
                  style={{
                    color: isQuantityMin ? colors.blackText : colors.white,
                  }}>
                  -
                </Text>
              </TouchableOpacity>
              <View style={styles.quantity}>
                <Text type="small">{quantity}</Text>
              </View>
              <TouchableOpacity
                disabled={isQuantityMax}
                onPress={handlePlus}
                style={[
                  styles.plus,
                  {
                    backgroundColor: isQuantityMax
                      ? colors.grey
                      : colors.primary,
                  },
                ]}>
                <Text
                  type="small"
                  style={{
                    color: isQuantityMax ? colors.blackText : colors.white,
                  }}>
                  +
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <></>
        )}
      </View>
      <View style={styles.selection}>
        <RadioButton
          color={colors.primary}
          value={item.id}
          status={isChecked}
          onPress={handleChecked}
        />
      </View>
    </View>
  );
};

export default MyTruckOption;
