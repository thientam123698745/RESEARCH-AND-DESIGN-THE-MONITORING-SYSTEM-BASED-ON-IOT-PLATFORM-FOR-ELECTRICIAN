import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectPickedTrucks,
  selectTrucks,
} from '@store/bookingTruckOrder/shared/selector';
import MySelectedTruck from '../MySelectedTruck';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
const PickedTrucksList = () => {
  useBookingInjector();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const trucks = useSelector(selectTrucks);
  const _renderSelectedItems = (item: any, index: number) => {
    return (
      <View style={styles.wrapper}>
        <MySelectedTruck
          key={index}
          setQuantity={setQuantity}
          handleDelete={deletePickedTruck}
          item={item}
          min={1}
          max={item.truck.quantity}
        />
      </View>
    );
  };
  const dispatch = useDispatch();
  function setQuantity(quantity: number, id: number) {
    dispatch(
      BookingTruckOrderSlice.actions.setPickedQuantity({
        quantity,
        id,
        pickedTrucks,
      }),
    );
  }
  function deletePickedTruck(id: number) {
    dispatch(
      BookingTruckOrderSlice.actions.deletePickedTruck({
        id,
        pickedTrucks,
        trucks,
      }),
    );
  }
  return pickedTrucks.length === 0 ? (
    <></>
  ) : (
    <View style={styles.container}>
      {pickedTrucks.map((item: any, index: number) => {
        return _renderSelectedItems(item, index);
      })}
    </View>
  );
};

export default PickedTrucksList;
