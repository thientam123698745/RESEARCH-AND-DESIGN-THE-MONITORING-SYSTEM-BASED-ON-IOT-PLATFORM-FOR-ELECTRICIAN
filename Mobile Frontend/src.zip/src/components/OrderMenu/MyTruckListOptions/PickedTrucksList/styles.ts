import {colors} from '@assets/colors/index';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  text: {
    paddingHorizontal: MetricSizes.P_20,
  },
  container: {
    borderBottomLeftRadius: MetricSizes.P_20,
    borderBottomRightRadius: MetricSizes.P_20,
    marginBottom: MetricSizes.P_20,
    paddingBottom: MetricSizes.P_20,
    backgroundColor: colors.white,
  },
  wrapper: {
    paddingTop: MetricSizes.P_10,
    // borderBottomWidth: 1,
  },
});
