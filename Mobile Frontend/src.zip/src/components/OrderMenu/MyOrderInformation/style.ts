import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    minHeight: WINDOW_HEIGHT * 0.15,
    marginTop: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
    flex: 1,
  },
});
export default styles;
