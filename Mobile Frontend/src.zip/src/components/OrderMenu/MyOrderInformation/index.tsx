import {View} from 'react-native';
import React from 'react';
import styles from './style';
import MyOptionDelivery from '@components/common/MyOptionDelivery';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {
  selectHeight,
  selectImageType,
  selectLong,
  selectOption,
  selectPickedTrucks,
  selectTime,
  selectType,
  selectWeight,
  selectWidth,
} from '@store/bookingTruckOrder/shared/selector';
import {KIND_DATA} from '@assets/data';
import {useTranslation} from 'react-i18next';

const MyOrderInformation = ({
  disabled,
  handleTime,
  handleCategories,
  handleWeight,
  handleTruck,
}: {
  disabled?: boolean;
  handleTime?: any;
  handleCategories?: any;
  handleWeight?: any;
  handleTruck?: any;
}) => {
  useBookingInjector();
  const {t} = useTranslation();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const item = KIND_DATA;
  const time = useSelector(selectTime);
  const type = useSelector(selectType);
  const option = useSelector(selectOption);
  const weight = useSelector(selectWeight);
  const height = useSelector(selectHeight);
  const long = useSelector(selectLong);
  const width = useSelector(selectWidth);
  const typeImage = useSelector(selectImageType);
  function getTimeContent() {
    const hours = `${time.getHours() < 10 ? '0' : ''}${time.getHours()}`;
    const minutes = `${time.getMinutes() < 10 ? '0' : ''}${time.getMinutes()} `;
    return `${t('order_menu.time_sender')} ${hours}:${minutes}`;
  }
  function getWeightContent() {
    return !weight
      ? t(item[2].content)
      : `${weight} ${t('order_menu.ton')}. ${height} x ${width} x ${long} ${t(
          'order_menu.metter',
        )}`;
  }
  function isValue() {
    return (
      !disabled &&
      type !== '' &&
      option !== '' &&
      weight !== 0 &&
      height !== 0 &&
      long !== 0 &&
      width !== 0
    );
  }
  return (
    <View style={styles.container}>
      <MyOptionDelivery
        disabled={disabled}
        onClick={handleTime}
        key={item[0].id}
        image={item[0].image}
        title={item[0].title}
        content={getTimeContent()}
      />
      <MyOptionDelivery
        disabled={disabled}
        onClick={handleCategories}
        key={item[1].id}
        image={typeImage ? typeImage : item[1].image}
        title={type ? type : t('order_menu.type_null')}
        content={option ? option : t('order_menu.option_null')}
      />
      <MyOptionDelivery
        disabled={disabled}
        onClick={handleWeight}
        key={item[2].id}
        image={item[2].image}
        title={item[2].title}
        content={getWeightContent()}
      />
      {pickedTrucks.length === 0 ? (
        <MyOptionDelivery
          disabled={!isValue()}
          onClick={handleTruck}
          key={item[3].id}
          image={item[3].image}
          title={item[3].title}
          content={item[3].content}
        />
      ) : (
        pickedTrucks.map((truck: any) => (
          <MyOptionDelivery
            disabled={disabled}
            key={truck.id}
            onClick={handleTruck}
            image={item[3].image}
            title={truck.truck.name}
            content={truck.truck.description}
          />
        ))
      )}
    </View>
  );
};

export default MyOrderInformation;
