import {Image, ScrollView, StatusBar, View} from 'react-native';
import React, {useState} from 'react';
import styles from './style';
import MyNavigationBar from './MyNavigationBar';
import MyLocationList from './MyLocationList';
import {Images} from '@assets/constants/images';
import MyOrderInformation from './MyOrderInformation';
import MyButton from './MyButton';
import MyTimesOptions from './MyTimesOptions';
import MyCategoriesOptions from './MyCategoriesOptions';
import MyWeightOptions from './MyWeightOptions';
import MyTruckListOptions from './MyTruckListOptions';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import Vouchers from '@components/BillingDetail/Vouchers';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
const BookingFilledMultiTruck = () => {
  useBookingInjector();
  const navigation = useNavigate();
  const [visible, setVisible] = useState(false);
  const [timeSelectorVisible, setTimeSelectorVisible] =
    useState<boolean>(false);
  const [categoriesVisible, setCategoriesVisible] = useState<boolean>(false);
  const [weightSelectorVisible, setWeightSelectorVisible] =
    useState<boolean>(false);
  const [truckSelectorVisible, setTruckSelectorVisible] =
    useState<boolean>(false);

  function handleSelectTime(): void {
    setTimeSelectorVisible(true);
  }
  function handleCategories(): void {
    setCategoriesVisible(true);
  }
  function handleWeight(): void {
    setWeightSelectorVisible(true);
  }
  function handleTruck(): void {
    setTruckSelectorVisible(true);
  }
  function handleVisible(): void {
    setVisible(!visible);
  }
  function handleContinue() {
    navigation.navigate(routers.BILLING_DETAIL);
  }
  return (
    <View style={styles.container}>
      <StatusBar translucent backgroundColor={'transparent'} />
      <ScrollView
        style={styles.container2}
        showsVerticalScrollIndicator={false}>
        <Image source={Images.BG_BOOKING_FILLED} style={styles.background} />
        <View style={styles.view}>
          <MyNavigationBar />
          <MyLocationList />
          <View style={styles.optionView}>
            <MyOrderInformation
              disabled={false}
              handleTime={handleSelectTime}
              handleCategories={handleCategories}
              handleWeight={handleWeight}
              handleTruck={handleTruck}
            />
          </View>
        </View>
      </ScrollView>
      <MyTimesOptions
        visible={timeSelectorVisible}
        setVisible={setTimeSelectorVisible}
      />
      <MyCategoriesOptions
        visible={categoriesVisible}
        setVisible={setCategoriesVisible}
      />
      <MyWeightOptions
        visible={weightSelectorVisible}
        setVisible={setWeightSelectorVisible}
      />
      <MyTruckListOptions
        visible={truckSelectorVisible}
        setVisible={setTruckSelectorVisible}
      />
      <MyButton handleVisible={handleVisible} handleContinue={handleContinue} />
      <Vouchers visible={visible} setVisible={setVisible} />
    </View>
  );
};

export default BookingFilledMultiTruck;
