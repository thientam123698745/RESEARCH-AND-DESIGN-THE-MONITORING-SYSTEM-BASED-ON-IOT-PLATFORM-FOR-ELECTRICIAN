import {colors} from '@assets/colors';
import {WINDOW_HEIGHT} from '@assets/constants';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';
const styles = StyleSheet.create({
  cateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: MetricSizes.P_20,
  },
  img: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  container: {
    borderWidth: 1,
  },
  container2: {
    height: '100%',
  },
  background: {
    resizeMode: 'stretch',
    width: '100%',
    height: WINDOW_HEIGHT * 0.25,
    position: 'absolute',
    top: 0,
  },
  view: {
    paddingHorizontal: MetricSizes.big,
    paddingBottom: MetricSizes.P_40 * 6,
    marginBottom: MetricSizes.P_20,
  },
  optionView: {
    paddingHorizontal: MetricSizes.regular,
    backgroundColor: colors.white,
    marginVertical: MetricSizes.regular,
    borderRadius: MetricSizes.big,
  },
  modal1: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: '50%',
    backgroundColor: colors.white,
    borderTopRightRadius: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
    padding: MetricSizes.P_20,
  },
  navBar: {
    width: '100%',
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingBottom: MetricSizes.P_20,
  },
  dayBar: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  optionDay: {
    justifyContent: 'center',
    alignItems: 'center',
    // borderWidth: 1,
    width: MetricSizes.P_40 * 2,
    height: MetricSizes.P_40 * 2,
  },
  dateText: {
    color: colors.primary,
  },
  dateText1: {
    color: colors.blackText,
  },
  dateNumber_active: {
    fontFamily: fonts.SF_PRO_BOLD,
    color: colors.primary,
    // backgroundColor: colors.primary,
  },
  dateNumber: {
    fontFamily: fonts.SF_PRO_BOLD,
    color: colors.blackText,
    // backgroundColor: colors.primary,
  },
  view1_active: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.lightBlue,
    borderRadius: MetricSizes.P_40 * 0.6,
    width: MetricSizes.P_40 * 1.2,
    height: MetricSizes.P_40 * 1.2,
  },
  view1: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.greyLine,
    borderRadius: MetricSizes.P_40 * 0.6,
    width: MetricSizes.P_40 * 1.2,
    height: MetricSizes.P_40 * 1.2,
  },
  view2: {
    width: '100%',
    height: '30%',
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  view3: {
    width: '100%',
    height: '70%',
    // borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  timeBar: {
    paddingBottom: MetricSizes.P_40 * 3,
    paddingTop: MetricSizes.P_20,
  },
  image: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  timeOption: {
    paddingVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
  },
  text_active: {
    fontFamily: fonts.SF_PRO_BOLD,
  },
  timeOption1: {
    borderRadius: MetricSizes.P_10,
    borderWidth: 2,
    paddingVertical: MetricSizes.P_10,
    paddingHorizontal: MetricSizes.P_20,
    backgroundColor: colors.lightBlue,
    borderColor: colors.primary,
  },
  header: {
    height: '15%',
    // borderWidth: 1,
    backgroundColor: colors.primary,
    borderBottomLeftRadius: MetricSizes.P_20,
    borderBottomRightRadius: MetricSizes.P_20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  label: {
    color: colors.white,
    fontFamily: fonts.SF_PRO_REGULAR,
  },
  kind: {
    height: '35%',
    // borderWidth: 1,
    justifyContent: 'center',
    padding: MetricSizes.P_20,
  },
  tutor: {
    height: '35%',
    // borderWidth: 1,
    padding: MetricSizes.P_20,
    justifyContent: 'center',
  },
  button: {
    height: '15%',
    // borderWidth: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  button_close: {
    position: 'absolute',
    left: 0,
    padding: MetricSizes.P_20,
  },
  icon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  icon_kind: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  radioView: {
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignItems: 'center',
    // paddingVertical: MetricSizes.P_10 * 0.2,
    // paddingHorizontal: MetricSizes.P_20,
  },
  text: {
    flexGrow: 1,
    paddingHorizontal: MetricSizes.P_10,
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
  },
  title: {
    fontSize: fontSize.FS_16,
    fontFamily: fonts.SF_PRO_BOLD,
    paddingVertical: MetricSizes.P_10,
  },
  button_inactive: {
    width: '40%',
    padding: MetricSizes.P_10,
    borderRadius: MetricSizes.P_10,
    borderWidth: 1,
    borderColor: colors.grey,
    justifyContent: 'center',
  },
  button_active: {
    justifyContent: 'center',
    width: '40%',
    padding: MetricSizes.P_10,
    backgroundColor: colors.primary,
    borderRadius: MetricSizes.P_10,
  },
  text_button: {
    textAlign: 'center',
  },
});
export default styles;
