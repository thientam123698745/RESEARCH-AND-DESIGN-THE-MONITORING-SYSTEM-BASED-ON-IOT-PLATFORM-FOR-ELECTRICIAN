import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import styles from './style';
import {Images} from '@assets/constants/images';

import useNavigate from '@hooks/useNavigate';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyNavigationBar = () => {
  const navigation = useNavigate();
  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={styles.button}>
        <Image source={Images.TT_RETURN} style={styles.image} />
      </TouchableOpacity>
      <View style={styles.view2}>
        <Text type="small" isBold color={colors.white}>
          order_menu.prices
        </Text>
      </View>
    </View>
  );
};

export default MyNavigationBar;
