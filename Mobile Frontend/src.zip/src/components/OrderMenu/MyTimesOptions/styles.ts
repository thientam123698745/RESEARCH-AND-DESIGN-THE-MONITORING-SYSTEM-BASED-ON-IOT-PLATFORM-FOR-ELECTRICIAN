import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
import {WINDOW_WIDTH} from '@assets/constants';

export const styles = StyleSheet.create({
  view: {
    backgroundColor: colors.modal,
    justifyContent: 'flex-end',
    flex: 1,
  },
  date: {
    margin: MetricSizes.P_10,
    alignItems: 'center',
  },
  dateCircle: {
    marginTop: MetricSizes.P_10 * 0.5,
    width: MetricSizes.P_40 * 1.5,
    borderRadius: MetricSizes.P_40 * 0.75,
    height: undefined,
    aspectRatio: 1 / 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  timeText: {fontWeight: 'bold'},
  item: {
    padding: MetricSizes.P_10,
  },
  pickingTime: {
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    padding: MetricSizes.P_10,
    borderRadius: 10,
    borderColor: colors.primary,
    backgroundColor: colors.lightBlue,
  },
  pickingTimeHour: {
    flexDirection: 'row',
  },
  pickTimeWrapper: {},
  pickMonthWrapper: {},
  pickDateWrapper: {},
  datePicker: {width: WINDOW_WIDTH * 0.5},
  btHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  btContainer: {
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
    backgroundColor: colors.white,
    borderTopLeftRadius: MetricSizes.P_20,
    borderTopRightRadius: MetricSizes.P_20,
  },
  img: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  pickingTimeItem: {
    width: '50%',
  },
});
