import {View, FlatList, Image, TouchableOpacity, Modal} from 'react-native';
import React, {useEffect, useRef, useState} from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import {fontSize} from '@assets/fonts';
import DatePicker from 'react-native-date-picker';
import {MONTHS} from '@assets/constants';
import {getDays} from 'src/utils/getDays';
import {useDispatch, useSelector} from 'react-redux';
import {selectTime} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
const MyTimesOptions = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: any;
}) => {
  const TODAY = new Date();
  //use state
  const [pickMonth, setPickMonth] = useState({
    index: 0,
    month: TODAY.getMonth(),
  });
  const [pickDate, setPickDate] = useState({
    id: 0,
    month: TODAY.getMonth(),
    date: TODAY.getDate(),
  });
  const time = useSelector(selectTime);
  const dispatch = useDispatch();
  function setTime(date: Date) {
    dispatch(BookingTruckOrderSlice.actions.setTime(date));
  }
  //use REF
  const dateRef = useRef(null);
  const monthRef = useRef(null);
  useEffect(() => {
    if (monthRef.current != null && dateRef.current != null) {
      monthRef.current.scrollToIndex({
        animated: true,
        index: pickMonth.index,
      });
      if (pickMonth.month === pickDate.month) {
        dateRef.current.scrollToIndex({
          animated: true,
          index: pickDate.id,
        });
      } else {
        dateRef.current.scrollToIndex({
          animated: true,
          index: 0,
        });
      }
    }
  }, [pickDate, pickMonth]);
  // variables
  const days = getDays(pickMonth.month, 2022);
  const months = MONTHS.filter((item: any) => item.id >= TODAY.getMonth());
  const minimumTime =
    pickDate.date === TODAY.getDate() && pickDate.month === TODAY.getMonth()
      ? TODAY
      : null;
  const addMinuteDate = new Date(time.getTime());
  addMinuteDate.setMinutes(addMinuteDate.getMinutes() + 30);
  let displayTimeText = `${
    time.getHours() < 10 ? '0' : ''
  }${time.getHours()} : ${
    time.getMinutes() < 10 ? '0' : ''
  }${time.getMinutes()} - ${
    addMinuteDate.getHours() < 10 ? '0' : ''
  }${addMinuteDate.getHours()} : ${
    addMinuteDate.getMinutes() < 10 ? '0' : ''
  }${addMinuteDate.getMinutes()} (trong vòng 30 phút)`;
  if (time) {
    const tmp_time = new Date();
    if (
      time.getHours() === tmp_time.getHours() &&
      time.getMinutes() === tmp_time.getMinutes() &&
      time.getDate() === tmp_time.getDate() &&
      time.getMonth() === tmp_time.getMonth()
    ) {
      displayTimeText = 'Bây giờ (trong vòng 30 phút)';
    }
  }
  //handle functions
  const handleOnDateChange = (date: any) => {
    setTime(date);
  };
  const handlePickMonth = (index: number, month: number) => {
    setPickMonth({
      index: index,
      month: month,
    });
  };
  const handlePickDate = (index: number, date: number) => {
    setPickDate({
      id: index,
      month: pickMonth.month,
      date: date,
    });

    if (
      date === TODAY.getDate() &&
      time.getMinutes() + time.getHours() * 60 <
        TODAY.getMinutes() + TODAY.getHours() * 60
    ) {
      time.setHours(TODAY.getHours());
      time.setMinutes(TODAY.getMinutes());
    }
  };
  const handleTextDate = (date: number) => {
    const textDate = ['CN', 'Th 2', 'Th 3', 'Th 4', 'Th 5', 'Th 6', 'Th 7'];
    return textDate[date];
  };
  //render item
  const _renderDateItems = (item: any) => {
    return (
      <TouchableOpacity
        onPress={() => handlePickDate(item.index, item.item.date)}
        style={styles.date}>
        <Text
          type="small"
          style={{
            color:
              pickDate.date === item.item.date &&
              pickDate.month === pickMonth.month
                ? colors.primary
                : colors.blackText,
          }}>
          {item.item.date === TODAY.getDate() &&
          item.item.month === TODAY.getMonth()
            ? 'Hôm nay'
            : handleTextDate(item.item.text)}
        </Text>
        <View
          style={[
            styles.dateCircle,
            {
              backgroundColor:
                pickDate.date === item.item.date &&
                pickDate.month === pickMonth.month
                  ? colors.lightBlue
                  : colors.greyLine,
            },
          ]}>
          <Text
            type="small"
            style={{
              fontSize: fontSize.FS_24,
              fontWeight: '500',
              color:
                pickDate.date === item.item.date &&
                pickDate.month === pickMonth.month
                  ? colors.primary
                  : colors.blackText,
            }}>
            {item.item.date}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };
  const _renderMonthItems = (item: any) => {
    return (
      <TouchableOpacity
        onPress={() => handlePickMonth(item.index, item.item.id)}
        style={styles.item}>
        <Text
          type="regular"
          style={{
            fontWeight: pickMonth.month === item.item.id ? 'bold' : 'normal',
            color:
              pickMonth.month === item.item.id ? colors.blackText : colors.grey,
          }}>
          {item.item.abbreviation}
        </Text>
      </TouchableOpacity>
    );
  };

  const handleCloseBottomSheet = () => {
    setVisible(!visible);
  };
  function addMinutes(date: Date, minutes: number) {
    return new Date(date.getTime() + minutes * 60000);
  }
  return (
    <Modal
      visible={visible}
      transparent
      statusBarTranslucent
      animationType="fade">
      <View style={styles.view}>
        <View style={styles.btContainer}>
          <View style={styles.btHeader}>
            <Text type="small" isBold color={colors.blackText}>
              get_shipment_time
            </Text>
            <TouchableOpacity onPress={handleCloseBottomSheet}>
              <Image style={styles.img} source={Images.CLOSE_BUTTON} />
            </TouchableOpacity>
          </View>
          <View style={styles.pickMonthWrapper}>
            <FlatList
              ref={monthRef}
              showsHorizontalScrollIndicator={false}
              horizontal
              data={months}
              renderItem={_renderMonthItems}
              keyExtractor={item => item.id + ''}
            />
          </View>
          <View style={styles.pickDateWrapper}>
            <FlatList
              ref={dateRef}
              data={days}
              renderItem={_renderDateItems}
              keyExtractor={item => item.id + ''}
              showsHorizontalScrollIndicator={false}
              horizontal
            />
          </View>
          <View style={styles.pickTimeWrapper}>
            <View style={styles.pickingTime}>
              <Text type="small" style={styles.timeText}>
                {displayTimeText}
              </Text>
            </View>
            <View style={styles.pickingTimeHour}>
              <View style={styles.pickingTimeItem}>
                <DatePicker
                  style={styles.datePicker}
                  minuteInterval={15}
                  modal={false}
                  is24hourSource={'locale'}
                  mode="time"
                  date={time}
                  minimumDate={minimumTime}
                  onDateChange={handleOnDateChange}
                />
              </View>
              <View style={styles.pickingTimeItem}>
                <DatePicker
                  accessible={false}
                  style={styles.datePicker}
                  minuteInterval={15}
                  is24hourSource={'locale'}
                  modal={false}
                  mode="time"
                  date={addMinutes(time, 30)}
                  minimumDate={minimumTime}
                />
              </View>
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default MyTimesOptions;
