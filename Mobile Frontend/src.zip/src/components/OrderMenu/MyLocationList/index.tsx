import {Image, View} from 'react-native';
import React, {useState} from 'react';
import styles from './style';
import {Text} from '@react-native-material/core';
import {Images} from '@assets/constants/images';

import MyTextInput from '@components/common/MyTextInput';
import useNavigate from '@hooks/useNavigate';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectRecipients,
  selectSenderAddress,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {routers} from '@assets/constants/routers';
import {useTranslation} from 'react-i18next';
import {TouchableRipple} from 'react-native-paper';
import {colors} from '@assets/colors';
const MyLocationList = () => {
  useBookingInjector();
  const [isEditable, setIsEditable] = useState(false);
  const data = useSelector(selectRecipients);
  const senderAddress = useSelector(selectSenderAddress);
  const navigation = useNavigate();
  const length = data.length;
  const dispatch = useDispatch();
  const {t} = useTranslation();
  const onClose = (index: number) => {
    dispatch(
      BookingTruckOrderSlice.actions.removeAddress({
        recipientAddresses: data,
        index: index,
      }),
    );
  };
  function handleEditable() {
    setIsEditable(!isEditable);
  }
  function handleUpdateRecipientAddress(index: number) {
    dispatch(BookingTruckOrderSlice.actions.setUpUpdateRecipientAddress(index));
    navigation.navigate(routers.ADDRESS_LOCATION_UPDATE_OF_RECEIVER);
  }
  function handleUpdateSenderAddress(index: number) {
    dispatch(BookingTruckOrderSlice.actions.setUpUpdateSenderAddress(index));
    navigation.navigate(routers.ADDRESS_LOCATION_UPDATE_OF_RECEIVER);
  }
  function handleAddRecipient() {
    navigation.navigate(routers.BOTTOM_TABS);
  }
  function handleAddSender() {
    navigation.navigate(routers.ADDRESS_SEARCHING_OF_SENDER);
  }
  return (
    <View style={styles.container}>
      <View style={styles.container1}>
        <View style={styles.container3}>
          {senderAddress.map((item, index) => {
            return (
              <TouchableRipple
                rippleColor={colors.blackText}
                disabled={!isEditable}
                onPress={() => handleUpdateSenderAddress(index)}
                key={index}>
                <MyTextInput
                  disabled={true}
                  index={index}
                  isEditable={isEditable}
                  length={length}
                  isSenderAddress={true}
                  label={t('address_form.location_get_shipment')}
                  address={item}
                  onClose={onClose}
                />
              </TouchableRipple>
            );
          })}
          {data.map((item, index) => {
            return (
              <TouchableRipple
                rippleColor={colors.blackText}
                disabled={!isEditable}
                onPress={() => handleUpdateRecipientAddress(index)}
                key={index}>
                <MyTextInput
                  disabled={true}
                  isEditable={isEditable}
                  index={index}
                  length={length}
                  isSenderAddress={false}
                  label={t('address_form.location_destination')}
                  address={item}
                  onClose={onClose}
                />
              </TouchableRipple>
            );
          })}
        </View>
      </View>
      {isEditable ? (
        <>
          <TouchableRipple
            rippleColor={colors.blackText}
            onPress={handleAddRecipient}
            style={styles.button}>
            <Text style={styles.buttonText}>{t('recipient.button')}</Text>
          </TouchableRipple>
          <TouchableRipple
            rippleColor={colors.blackText}
            onPress={handleAddSender}
            style={styles.button}>
            <Text style={styles.buttonText}>{t('sender.button')}</Text>
          </TouchableRipple>
        </>
      ) : (
        <></>
      )}
      <TouchableRipple
        rippleColor={colors.blackText}
        onPress={handleEditable}
        style={styles.button}>
        <>
          <Image style={styles.icon} source={Images.UPDATE_LOCATION} />
          <Text style={styles.text}>
            {t('order_menu.update_address_button')}
          </Text>
        </>
      </TouchableRipple>
    </View>
  );
};

export default MyLocationList;
