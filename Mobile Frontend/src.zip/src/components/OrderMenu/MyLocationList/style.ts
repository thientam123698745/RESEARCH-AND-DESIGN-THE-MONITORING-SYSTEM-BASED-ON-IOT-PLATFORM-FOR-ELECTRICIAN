import MetricSizes from '@assets/constants/MetricSizes';
import {colors} from '@assets/colors';
import {StyleSheet} from 'react-native';
import {WINDOW_HEIGHT} from '@assets/constants';
import {fonts} from '@assets/fonts';
const styles = StyleSheet.create({
  container: {
    minHeight: WINDOW_HEIGHT * 0.15,
    backgroundColor: colors.white,
    borderRadius: MetricSizes.P_20,
    flex: 1,
    paddingTop: MetricSizes.P_10 * 1.4,
  },
  icon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
    marginRight: MetricSizes.P_10,
  },
  text: {
    color: colors.red,
    fontFamily: fonts.SF_PRO_BOLD,
  },
  button: {
    padding: MetricSizes.P_20,
    borderColor: colors.grey,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: MetricSizes.P_20,
    marginTop: -MetricSizes.P_10 * 0.2,
  },
  buttonText: {
    color: colors.primary,
    fontFamily: fonts.SF_PRO_BOLD,
  },
  textInput: {
    backgroundColor: colors.white,
  },
  textInput1: {
    backgroundColor: colors.white,
    // borderRadius: MetricSizes.P_20,
  },
  container1: {
    flexDirection: 'row',
  },
  container2: {
    flex: 1,
  },
  container3: {
    flex: 5,
  },
});
export default styles;
