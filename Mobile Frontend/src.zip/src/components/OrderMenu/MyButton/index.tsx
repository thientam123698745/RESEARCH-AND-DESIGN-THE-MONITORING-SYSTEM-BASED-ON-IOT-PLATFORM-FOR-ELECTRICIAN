import {View, TouchableOpacity} from 'react-native';
import React from 'react';
import styles from './style';
import Body from './Body';
import Header from './Header';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {
  selectHeight,
  selectLong,
  selectOption,
  selectPickedTrucks,
  selectType,
  selectWeight,
  selectWidth,
} from '@store/bookingTruckOrder/shared/selector';
import {colors} from '@assets/colors';
import Text from '@components/common/Texts/Text';

const MyButton = ({
  handleVisible,
  handleContinue,
}: {
  handleVisible: Function;
  handleContinue: any;
}) => {
  useBookingInjector();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const type = useSelector(selectType);
  const option = useSelector(selectOption);
  const weight = useSelector(selectWeight);
  const height = useSelector(selectHeight);
  const width = useSelector(selectWidth);
  const long = useSelector(selectLong);
  const isFillAllInformation =
    pickedTrucks.length !== 0 &&
    type !== '' &&
    option !== '' &&
    weight !== 0 &&
    height !== 0 &&
    long !== 0 &&
    width !== 0;
  return (
    <View style={styles.container}>
      {isFillAllInformation ? (
        <>
          <Header handleVisible={handleVisible} />
          <Body />
        </>
      ) : (
        <></>
      )}
      <TouchableOpacity
        onPress={handleContinue}
        style={[
          styles.button,
          {
            backgroundColor: isFillAllInformation
              ? colors.primary
              : colors.grey,
          },
        ]}
        disabled={!isFillAllInformation}>
        <Text
          type="small"
          isBold
          isCenter
          color={isFillAllInformation ? colors.white : colors.blackText}>
          button.continue
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default MyButton;
