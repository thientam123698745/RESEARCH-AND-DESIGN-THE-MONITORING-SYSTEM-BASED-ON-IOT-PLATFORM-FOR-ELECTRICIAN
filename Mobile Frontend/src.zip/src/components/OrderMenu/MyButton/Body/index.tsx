import {View, Image} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';
import {colors} from '@assets/colors';
import {TouchableOpacity} from 'react-native';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectPickedTrucks} from '@store/bookingTruckOrder/shared/selector';
import {FlatList} from 'react-native-gesture-handler';
import Text from '@components/common/Texts/Text';
import {t} from 'i18next';
import formatMoney from 'src/utils/formatMoney';
const Body = () => {
  useBookingInjector();
  const pickedTrucks = useSelector(selectPickedTrucks);
  const [visible, setVisible] = useState(false);
  const total =
    pickedTrucks.reduce(
      (pac: any, a: any) => pac + a.truck.price * a.quantity,
      0,
    ) * 1000;
  function handleVisible() {
    setVisible(!visible);
  }
  function _renderItem({item}: {item: any}) {
    return (
      <View style={styles.renderItem}>
        <Text type="small" style={styles.name}>
          {item.truck.name}
        </Text>

        <Text type="small" style={styles.money}>
          {formatMoney(item.truck.price * item.quantity * 1000) + ' đ'}
        </Text>
      </View>
    );
  }
  return (
    <View style={styles.wrapper}>
      {visible ? (
        <View>
          <FlatList
            data={pickedTrucks}
            keyExtractor={item => item.id}
            renderItem={_renderItem}
          />
        </View>
      ) : (
        <></>
      )}
      <TouchableOpacity onPress={handleVisible} style={styles.container}>
        <View style={styles.total}>
          <View style={styles.text}>
            <Text isBold type="small">
              booking_tracking_driver.total
            </Text>
          </View>
          <Image style={styles.img} source={Images.CARET_UP} />
        </View>

        <Text type="regular" color={colors.blackText}>
          {`${formatMoney(total)} ${t('booking_tracking_driver.vnd')}`}
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default Body;
