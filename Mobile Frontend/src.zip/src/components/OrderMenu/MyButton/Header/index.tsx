import {View, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {Images} from '@assets/constants/images';
import {styles} from './styles';
import {colors} from '@assets/colors';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import {useBookingInjector} from '@hooks/useInjector/useBookingInjector';
import {useSelector} from 'react-redux';
import {selectPaymentMethod} from '@store/bookingTruckOrder/shared/selector';
import Text from '@components/common/Texts/Text';
const Header = ({handleVisible}: {handleVisible: any}) => {
  const navigation = useNavigate();
  useBookingInjector();
  const paymentMethod = useSelector(selectPaymentMethod);
  function handlePayment() {
    navigation.navigate(routers.PAYMENT_METHOD);
  }
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handlePayment} style={styles.payment}>
        <Image style={styles.img} source={Images.WALLET_MIN} />
        <View style={styles.text}>
          <Text type="small" color={colors.blackText} isBold>
            {paymentMethod}
          </Text>
        </View>
        <Image style={styles.img} source={Images.CARET_LEFT} />
      </TouchableOpacity>
      <TouchableOpacity onPress={handleVisible} style={styles.voucher}>
        <Image style={styles.img} source={Images.STAR_VOUCHER} />
        <Text type="small" isBold color={colors.blackText}>
          use_voucher
        </Text>
      </TouchableOpacity>
    </View>
  );
};

export default Header;
