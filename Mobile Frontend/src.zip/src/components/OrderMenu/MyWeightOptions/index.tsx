import {View, Image, TouchableOpacity, Modal} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import {colors} from '@assets/colors';
import {Images} from '@assets/constants/images';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectHeight,
  selectLong,
  selectWeight,
  selectWidth,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import Text from '@components/common/Texts/Text';
import TextInput from '@components/common/TextInput/TextInput';
const MyWeightOptions = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: Function;
}) => {
  const weights = [
    {
      id: 0,
      weight: 2,
      height: 2,
      long: 1.4,
      width: 1.6,
    },
    {
      id: 1,
      weight: 3,
      height: 2.3,
      long: 1.6,
      width: 1.8,
    },
    {
      id: 2,
      weight: 4,
      height: 2.5,
      long: 1.7,
      width: 1.9,
    },
  ];

  const [otherOption, setOtherOption] = useState(false);
  const weight = useSelector(selectWeight);
  const height = useSelector(selectHeight);
  const long = useSelector(selectLong);
  const width = useSelector(selectWidth);
  const dispatch = useDispatch();
  function setWeight(text: string) {
    const data = parseFloat(text);
    dispatch(BookingTruckOrderSlice.actions.setWeight(data));
  }
  function setHeight(text: string) {
    const data = parseFloat(text);
    dispatch(BookingTruckOrderSlice.actions.setHeight(data));
  }
  function setWidth(text: string) {
    const data = parseFloat(text);
    dispatch(BookingTruckOrderSlice.actions.setWidth(data));
  }
  function setLong(text: string) {
    const data = parseFloat(text);
    dispatch(BookingTruckOrderSlice.actions.setLong(data));
  }
  const handleOtherOptionVisible = () => {
    setOtherOption(!otherOption);
  };
  function handleClose() {
    handleGuestTruck();
    setVisible(!visible);
  }
  function handleChooseOption(item: any) {
    setWeight(item.weight);
    setHeight(item.height);
    setLong(item.long);
    setWidth(item.width);
  }
  function handleGuestTruck() {
    if (weight !== 0 && height !== 0 && long !== 0 && width !== 0) {
      const data = {
        weight,
        height,
        length: long,
        width,
      };
      dispatch(BookingTruckOrderSlice.actions.getSuggestTrucks(data));
    }
  }
  return (
    <Modal
      statusBarTranslucent
      transparent
      animationType="fade"
      visible={visible}>
      <View style={styles.view}>
        <View style={styles.btContainer}>
          <View style={styles.btHeader}>
            <Text type="small" isBold color={colors.blackText}>
              total_weight
            </Text>
            <TouchableOpacity onPress={handleClose}>
              <Image style={styles.img} source={Images.CLOSE_BUTTON} />
            </TouchableOpacity>
          </View>
          <View>
            {weights.map(item => (
              <TouchableOpacity
                onPress={() => handleChooseOption(item)}
                key={item.id}
                style={styles.weightOption}>
                <Text type="tiny" style={styles.weightText}>
                  {` ${item.weight} Tấn .`}
                </Text>
                <Text type="tiny" style={styles.weightText}>
                  {`${item.long} x ${item.width} x ${item.height} Mét`}
                </Text>
              </TouchableOpacity>
            ))}
            <TouchableOpacity
              onPress={handleOtherOptionVisible}
              style={styles.weightOption}>
              <Text type="tiny" style={styles.weightText}>
                setting_option
              </Text>
            </TouchableOpacity>
            {otherOption ? (
              <>
                <View style={styles.selectOption}>
                  <View style={styles.inputText}>
                    <TextInput
                      onChangeText={setWeight}
                      value={weight !== 0 ? weight + '' : null}
                      keyboardType="number-pad"
                      placeholder="trọng lượng"
                    />
                  </View>
                  <Text type="tiny" style={styles.textWeight}>
                    ton
                  </Text>
                </View>
                <View style={styles.selectGroup}>
                  <View style={styles.selectOption}>
                    <View style={styles.inputText}>
                      <TextInput
                        value={long !== 0 ? long + '' : null}
                        onChangeText={setLong}
                        keyboardType="decimal-pad"
                        placeholder="chiều dài"
                      />
                    </View>
                    <Text type="tiny" style={styles.textWeight}>
                      {' x '}
                    </Text>
                  </View>
                  <View style={styles.selectOption}>
                    <View style={styles.inputText}>
                      <TextInput
                        value={width !== 0 ? width + '' : null}
                        onChangeText={setWidth}
                        keyboardType="decimal-pad"
                        placeholder="chiều rộng"
                      />
                    </View>
                    <Text type="tiny" style={styles.textWeight}>
                      {' x '}
                    </Text>
                  </View>
                  <View style={styles.selectOption}>
                    <View style={styles.inputText}>
                      <TextInput
                        value={height !== 0 ? height + '' : null}
                        onChangeText={setHeight}
                        keyboardType="decimal-pad"
                        placeholder="chiều cao"
                      />
                    </View>
                    <Text type="tiny" style={styles.textWeight}>
                      metter
                    </Text>
                  </View>
                </View>
              </>
            ) : (
              <></>
            )}
          </View>
        </View>
      </View>
    </Modal>
  );
};

export default MyWeightOptions;
