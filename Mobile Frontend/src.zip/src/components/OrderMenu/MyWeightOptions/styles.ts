import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  view: {
    backgroundColor: colors.modal,
    flex: 1,
    justifyContent: 'flex-end',
  },
  btHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: MetricSizes.P_20,
    paddingVertical: MetricSizes.P_10,
  },
  btContainer: {
    backgroundColor: colors.white,
    borderTopLeftRadius: MetricSizes.P_10,
    borderTopRightRadius: MetricSizes.P_10,
  },
  img: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  weightOption: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    padding: MetricSizes.P_10 * 1.5,
    borderBottomWidth: 1,
    borderColor: colors.grey,
  },
  weightText: {
    color: colors.blackText,
    fontSize: fontSize.FS_14,
    fontFamily: fonts.SF_PRO_REGULAR,
  },
  selectOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputText: {
    borderBottomWidth: 1,
  },
  textWeight: {
    fontWeight: 'bold',
  },
  selectGroup: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
