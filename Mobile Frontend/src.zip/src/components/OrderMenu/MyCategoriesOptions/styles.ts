import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';
import {colors} from '@assets/colors';

export const styles = StyleSheet.create({
  typeWrapper: {
    paddingHorizontal: MetricSizes.P_10,
  },
  textOption: {
    flexGrow: 1,
    paddingHorizontal: MetricSizes.P_10,
    // fontWeight: 'bold',
    color: colors.blackText,
  },
  container: {
    height: '100%',
    justifyContent: 'space-between',
  },
  selectOption: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: MetricSizes.P_10 * 0.5,
    alignItems: 'center',
  },
  img: {
    width: MetricSizes.P_20 * 1.5,
    height: MetricSizes.P_20 * 1.5,
  },
  textOptionWrapper: {
    flexGrow: 1,
  },
  selectWrapper: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingHorizontal: MetricSizes.P_10,
  },
  buttonGroup: {
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    height: '10%',
    paddingHorizontal: MetricSizes.P_20,
  },
  btnEdit: {
    borderWidth: 1,
    width: '48%',
    borderRadius: MetricSizes.P_10,
    height: '60%',
    justifyContent: 'center',
    alignItems: 'center',
    borderColor: colors.grey,
  },
  editText: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: colors.grey,
  },
  btnSubmit: {
    width: '48%',
    borderRadius: MetricSizes.P_10,
    height: '60%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: colors.primary,
  },
  submitText: {
    textAlign: 'center',
    fontWeight: 'bold',
    color: colors.white,
  },
});
