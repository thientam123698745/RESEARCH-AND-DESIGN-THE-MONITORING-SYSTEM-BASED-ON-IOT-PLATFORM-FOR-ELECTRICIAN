import {View, Modal, SafeAreaView, Image} from 'react-native';
import React, {useState} from 'react';
import {styles} from './styles';
import MediumLogoHeader from '@components/Header/MediumLogoHeader';
import {RadioButton, TouchableRipple} from 'react-native-paper';
import {MANUAL, TYPE_OF_SHIPMENT} from '@assets/data';
import {useDispatch, useSelector} from 'react-redux';
import {
  selectOption,
  selectType,
} from '@store/bookingTruckOrder/shared/selector';
import * as BookingTruckOrderSlice from '@store/bookingTruckOrder/shared/slice';
import {useTranslation} from 'react-i18next';
import Text from '@components/common/Texts/Text';
import {colors} from '@assets/colors';
const MyCategoriesOptions = ({
  visible,
  setVisible,
}: {
  visible: boolean;
  setVisible: Function;
}) => {
  const {t} = useTranslation();
  const type = useSelector(selectType);
  const option = useSelector(selectOption);
  const dispatch = useDispatch();
  function setType(tmpType: string) {
    dispatch(BookingTruckOrderSlice.actions.setType(tmpType));
  }
  function setImageType(tmpImageType: any) {
    dispatch(BookingTruckOrderSlice.actions.setImageType(tmpImageType));
  }
  function setOption(tmpOption: string) {
    dispatch(BookingTruckOrderSlice.actions.setOption(tmpOption));
  }
  const [tmpType, setTmpType] = useState(type);
  const [tmpOption, setTmpOption] = useState(option);
  const handleOnPress = () => {
    setVisible(false);
  };
  const handleOnEdit = () => {
    setType('');
    setOption('');
  };
  const handleOnSubmit = () => {
    if (tmpType !== '' && tmpOption !== '') {
      setType(tmpType);
      let tmpIndex = 0;
      TYPE_OF_SHIPMENT.map((item, index) => {
        if (item.text === tmpType) {
          tmpIndex = index;
        }
      });

      setImageType(TYPE_OF_SHIPMENT[tmpIndex].image);
      setOption(tmpOption);
      setVisible(false);
    }
  };
  return (
    <Modal visible={visible} statusBarTranslucent animationType="fade">
      <SafeAreaView style={styles.container}>
        <MediumLogoHeader
          text={t('order_menu.title')}
          onPress={handleOnPress}
        />
        <View style={styles.selectWrapper}>
          <View style={styles.typeWrapper}>
            <Text type="regular" isCenter={false} isBold>
              order_menu.type_of_shipment
            </Text>
          </View>
          <View>
            <RadioButton.Group
              onValueChange={newValue => setTmpType(newValue)}
              value={tmpType}>
              {TYPE_OF_SHIPMENT.map((item, index) => {
                return (
                  <TouchableRipple
                    rippleColor={colors.blackText}
                    onPress={() => setTmpType(item.text)}
                    key={index}>
                    <View style={styles.selectOption}>
                      <View>
                        <Image style={styles.img} source={item.image} />
                      </View>
                      <View style={styles.textOptionWrapper}>
                        <Text
                          type="tiny"
                          isCenter={false}
                          style={styles.textOption}>
                          {item.text}
                        </Text>
                      </View>
                      <RadioButton value={item.text} />
                    </View>
                  </TouchableRipple>
                );
              })}
            </RadioButton.Group>
          </View>
        </View>
        <View style={styles.selectWrapper}>
          <View style={styles.typeWrapper}>
            <Text type="regular" isCenter={false} isBold>
              order_menu.manual
            </Text>
          </View>
          <View>
            <RadioButton.Group
              onValueChange={newValue => setTmpOption(newValue)}
              value={tmpOption}>
              {MANUAL.map((item, index) => {
                return (
                  <TouchableRipple
                    rippleColor={colors.blackText}
                    onPress={() => setTmpOption(item.text)}
                    key={index}>
                    <View style={styles.selectOption}>
                      <View>
                        <Image style={styles.img} source={item.image} />
                      </View>
                      <View style={styles.textOptionWrapper}>
                        <Text
                          type="tiny"
                          isCenter={false}
                          style={styles.textOption}>
                          {item.text}
                        </Text>
                      </View>
                      <RadioButton value={item.text} />
                    </View>
                  </TouchableRipple>
                );
              })}
            </RadioButton.Group>
          </View>
        </View>
        <View style={styles.buttonGroup}>
          <TouchableRipple
            rippleColor={colors.blackText}
            style={styles.btnEdit}
            onPress={handleOnEdit}>
            <Text type="small" style={styles.editText}>
              button.edit
            </Text>
          </TouchableRipple>
          <TouchableRipple
            rippleColor={colors.blackText}
            style={styles.btnSubmit}
            onPress={handleOnSubmit}>
            <Text type="small" color={colors.white} style={styles.submitText}>
              button.save
            </Text>
          </TouchableRipple>
        </View>
      </SafeAreaView>
    </Modal>
  );
};

export default MyCategoriesOptions;
