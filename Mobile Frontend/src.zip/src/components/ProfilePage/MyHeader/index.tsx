import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MySettingWrapper from './MySettingWrapper';
import MyInfoBar from './MyInfoBar';
const MyHeader = () => {
  return (
    <View style={styles.container}>
      <MySettingWrapper />
      <MyInfoBar />
    </View>
  );
};

export default MyHeader;
