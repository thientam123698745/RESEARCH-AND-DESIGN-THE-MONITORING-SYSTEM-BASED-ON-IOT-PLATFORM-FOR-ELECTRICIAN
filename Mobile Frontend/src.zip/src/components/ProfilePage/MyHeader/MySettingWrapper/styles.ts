import {fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  headerSettingEmpty: {
    width: '70%',
    // borderWidth: 1,
    height: '100%',
  },
  headerSettingBarWrapper: {
    width: '30%',
    // position: 'relative',
    // right: 0,
    flexDirection: 'row',
    justifyContent: 'space-evenly',
    alignContent: 'center',
    // borderWidth: 1,
    height: '100%',
    // paddingHorizontal: MetricSizes.P_10,
  },
  headerSettingBar: {
    flex: 1,
    flexDirection: 'row',
    // justifyContent: 'flex-end',
  },
  headerSettingButton: {
    // borderWidth: 1,
    // paddingHorizontal: MetricSizes.P_10,
    justifyContent: 'center',
  },
  headerSettingButtonImage: {
    width: fontSize.FS_32 * 0.8,
    height: fontSize.FS_32 * 0.8,
    resizeMode: 'stretch',
  },
});
