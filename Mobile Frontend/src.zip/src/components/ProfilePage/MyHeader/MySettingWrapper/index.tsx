import {View, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';
import {RouterParamList} from 'src/types/RouterParamList';
type routerProps = NativeStackNavigationProp<RouterParamList>;
const MySettingWrapper = () => {
  const navigation = useNavigation<routerProps>();
  const handleSettingButton = () => {
    navigation.navigate('SettingAccount');
  };
  const handleVoucher = () => {};
  return (
    <View style={styles.headerSettingBar}>
      <View style={styles.headerSettingEmpty} />
      <View style={styles.headerSettingBarWrapper}>
        <TouchableOpacity
          onPress={handleSettingButton}
          style={styles.headerSettingButton}>
          <Image
            source={Images.SETTING}
            style={styles.headerSettingButtonImage}
          />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleVoucher}
          style={styles.headerSettingButton}>
          <Image source={Images.CART} style={styles.headerSettingButtonImage} />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default MySettingWrapper;
