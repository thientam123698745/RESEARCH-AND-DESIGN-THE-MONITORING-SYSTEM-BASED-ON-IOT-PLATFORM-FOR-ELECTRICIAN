import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {fonts, fontSize} from '@assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  headerInfoBar: {flex: 3, flexDirection: 'row'},
  headerInfoBarNameWrapper: {
    width: '70%',
    justifyContent: 'center',
    alignContent: 'center',
    // borderWidth: 1,
    padding: MetricSizes.P_20,
  },
  headerInfoBarFullNameWrapper: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  headerInfoBarFullNameText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_24,
    color: colors.white,
  },
  headerInfoBarFullNameIcon: {},
  headerInfoBarNickname: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_16,
    color: colors.white,
    paddingLeft: MetricSizes.P_10,
  },
  headerInfoBarAvatarWrapper: {
    width: '30%',
    justifyContent: 'center',
    alignContent: 'center',
    // borderWidth: 1,
  },
  headerSettingPlusButtonImage: {
    width: fontSize.FS_16,
    height: fontSize.FS_16,
    resizeMode: 'stretch',
  },
  headerInfoBarNickNameWrapper: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    paddingTop: MetricSizes.P_10,
  },
  avtIcon: {
    width: MetricSizes.P_40 * 2,
    height: MetricSizes.P_40 * 2,
    borderRadius: MetricSizes.P_40,
    resizeMode: 'stretch',
  },
  avtWrapper: {
    width: '100%',
    // padding: MetricSizes.P_20,
  },
  headerSettingButtonImage: {
    width: fontSize.FS_32 * 0.8,
    height: fontSize.FS_32 * 0.8,
    resizeMode: 'stretch',
  },
});
