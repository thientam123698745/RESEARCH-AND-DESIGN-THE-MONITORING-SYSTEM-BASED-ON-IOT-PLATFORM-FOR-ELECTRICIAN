import {
  View,
  Text,
  Image,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

import {useSelector} from 'react-redux';
import * as ProfileSelector from '@store/profile/shared/selector';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {colors} from '@assets/colors';
import {RouterParamList} from 'src/types/RouterParamList';
import useNavigate from '@hooks/useNavigate';
import {routers} from '@assets/constants/routers';
import {useProfileInjector} from '@hooks/useInjector/useProfileInjector';
// import {useNavigation} from '@react-navigation/native';
type routerProps = NativeStackNavigationProp<RouterParamList>;
const MyInfoBar = () => {
  const navigation = useNavigate();
  useProfileInjector();
  const handleChangeName = () => {
    navigation.navigate(routers.CHANGE_FULL_NAME);
  };
  const handleChangeNickName = () => {
    navigation.navigate(routers.CHANGE_NICK_NAME);
  };
  const full_name = useSelector(ProfileSelector.selectFullName);
  const nick_name = useSelector(ProfileSelector.selectNickName);
  const avatar = useSelector(ProfileSelector.selectAvatar);
  return (
    <View style={styles.headerInfoBar}>
      <View style={styles.headerInfoBarNameWrapper}>
        <TouchableOpacity
          onPress={handleChangeName}
          style={styles.headerInfoBarFullNameWrapper}>
          {full_name ? (
            <Text style={styles.headerInfoBarFullNameText}>{full_name}</Text>
          ) : (
            <View>
              <ActivityIndicator color={colors.white} />
              <Text style={styles.headerInfoBarFullNameText}>
                Your Full Name
              </Text>
            </View>
          )}
          <View style={styles.headerInfoBarFullNameIcon}>
            <Image
              style={styles.headerSettingButtonImage}
              source={Images.CARET_LEFT}
            />
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleChangeNickName}
          style={styles.headerInfoBarNickNameWrapper}>
          <View style={styles.headerInfoBarFullNameIcon}>
            <Image
              style={styles.headerSettingPlusButtonImage}
              source={Images.PLUS}
            />
          </View>
          <Text style={styles.headerInfoBarNickname}>
            {nick_name ? nick_name : 'Them nickname'}
          </Text>
        </TouchableOpacity>
      </View>
      <View style={styles.headerInfoBarAvatarWrapper}>
        <View style={styles.avtWrapper}>
          <Image style={styles.avtIcon} source={{uri: avatar}} />
        </View>
      </View>
    </View>
  );
};

export default MyInfoBar;
