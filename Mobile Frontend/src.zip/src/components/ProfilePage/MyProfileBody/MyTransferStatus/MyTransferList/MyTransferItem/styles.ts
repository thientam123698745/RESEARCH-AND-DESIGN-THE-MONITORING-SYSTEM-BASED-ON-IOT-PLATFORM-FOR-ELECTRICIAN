import {WINDOW_WIDTH} from 'assets/constants';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts, fontSize} from 'assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    // borderWidth: 1,
    width: '15%',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  icon: {
    width: WINDOW_WIDTH * 0.15,
    height: WINDOW_WIDTH * 0.15,
    resizeMode: 'stretch',
  },
  text: {
    textAlign: 'center',
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
    paddingTop: MetricSizes.P_10,
  },
});
