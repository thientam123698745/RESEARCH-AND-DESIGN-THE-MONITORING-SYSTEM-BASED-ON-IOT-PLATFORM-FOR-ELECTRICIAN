import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';

const MyTransferItem = ({name, img}: {name: any; img: any}) => {
  const handleVoucher = () => {};
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={handleVoucher}>
        <Image style={styles.icon} source={img} />
      </TouchableOpacity>
      <Text style={styles.text}>{name}</Text>
    </View>
  );
};

export default MyTransferItem;
