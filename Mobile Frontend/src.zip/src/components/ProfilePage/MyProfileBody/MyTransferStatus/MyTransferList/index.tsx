import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MyTransferItem from './MyTransferItem';

const MyTransferList = () => {
  const data = [
    {
      img: require('assets/images/transferProgress-min.png'),
      name: 'Đang xử lý',
    },
    {
      img: require('assets/images/transferProgress1-min.png'),
      name: 'Đang vận chuyển',
    },
    {
      img: require('assets/images/transferProgress2-min.png'),
      name: 'Đánh giá',
    },
    {
      img: require('assets/images/transferProgress3-min.png'),
      name: 'Thanh Toán',
    },
    {
      img: require('assets/images/transferProgress4-min.png'),
      name: 'Ký Tên',
    },
  ];
  return (
    <View style={styles.container}>
      {data.map((item, index) => {
        return <MyTransferItem key={index} name={item.name} img={item.img} />;
      })}
    </View>
  );
};

export default MyTransferList;
