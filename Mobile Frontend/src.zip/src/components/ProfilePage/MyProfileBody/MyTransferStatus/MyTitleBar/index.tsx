import {View, Text, TouchableOpacity, Image} from 'react-native';
import React from 'react';
import {styles} from './style';
import {Images} from '@assets/constants/images';

const MyTitleBar = () => {
  const handleVoucher = () => {};
  return (
    <View style={styles.container}>
      <View style={styles.label}>
        <Text style={styles.labelText}>Trang thai giao dich</Text>
      </View>
      <TouchableOpacity onPress={handleVoucher} style={styles.button}>
        <View style={styles.historyText}>
          <Text style={styles.text}>Xem lich su </Text>
        </View>
        <View style={styles.historyIcon}>
          <Image style={styles.icon} source={Images.CARET_LEFT} />
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default MyTitleBar;
