import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts, fontSize} from 'assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    // flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    padding: MetricSizes.P_10 * 1.5,
  },
  label: {
    justifyContent: 'center',
    alignContent: 'center',
  },
  labelText: {
    fontFamily: fonts.SF_PRO_BOLD,
    fontSize: fontSize.FS_16,
    color: colors.blackText,
  },
  button: {
    flexDirection: 'row',
    alignContent: 'center',
    justifyContent: 'center',
    // borderWidth: 1,
  },
  historyText: {},
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    color: colors.primary,
  },
  historyIcon: {},
  icon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
  },
});
