import {View} from 'react-native';
import React from 'react';
import MyTitleBar from './MyTitleBar';
import MyTransferList from './MyTransferList';
import {styles} from './styles';

const MyTransferStatus = () => {
  return (
    <View style={styles.container}>
      <MyTitleBar />
      <MyTransferList />
    </View>
  );
};

export default MyTransferStatus;
