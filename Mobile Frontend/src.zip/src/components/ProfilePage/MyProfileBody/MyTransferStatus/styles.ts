import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.white,
    borderTopRightRadius: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
    paddingBottom: MetricSizes.P_10,
  },
});
