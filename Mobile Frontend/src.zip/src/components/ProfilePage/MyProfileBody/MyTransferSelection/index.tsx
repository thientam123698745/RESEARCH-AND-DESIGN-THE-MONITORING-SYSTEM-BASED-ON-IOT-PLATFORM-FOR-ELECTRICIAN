import {View} from 'react-native';
import React from 'react';
import MyWallet from './MyWallet';
import MyOtherSelection from './MyOtherSelection';

const MyTransferSelection = () => {
  return (
    <View>
      <MyWallet />
      <MyOtherSelection />
    </View>
  );
};

export default MyTransferSelection;
