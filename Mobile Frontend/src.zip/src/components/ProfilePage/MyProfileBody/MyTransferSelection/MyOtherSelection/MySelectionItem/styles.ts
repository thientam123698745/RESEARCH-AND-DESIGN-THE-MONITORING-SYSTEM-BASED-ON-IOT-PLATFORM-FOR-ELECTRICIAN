import {colors} from 'assets/colors';
import MetricSizes from 'assets/constants/MetricSizes';
import {fonts, fontSize} from 'assets/fonts';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    // marginTop: MetricSizes.P_10,
    backgroundColor: colors.white,
    // justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: MetricSizes.P_10,
    paddingVertical: MetricSizes.P_20,
  },
  iconWrapper: {
    width: '10%',
  },
  icon: {
    width: MetricSizes.P_20,
    height: MetricSizes.P_20,
    resizeMode: 'stretch',
  },
  textWrapper: {
    width: '55%',
  },
  text: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_16,
    color: colors.blackText,
  },
  moneyWrapper: {
    flexDirection: 'row',
    width: '30%',
    justifyContent: 'flex-end',
  },
  moneyText: {
    fontFamily: fonts.SF_PRO_REGULAR,
    color: colors.primary,
  },
  moneyButton: {
    width: '5%',
  },
  sub_title: {
    fontFamily: fonts.SF_PRO_REGULAR,
    fontSize: fontSize.FS_10,
  },
});
