import {View} from 'react-native';
import React from 'react';
import MySelectionItem from './MySelectionItem';
import {styles} from './styles';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import {useNavigation} from '@react-navigation/native';
import {RouterParamList} from 'src/types/RouterParamList';
import {routers} from '@assets/constants/routers';
type routerProps = NativeStackNavigationProp<RouterParamList>;
const MyOtherSelection = () => {
  const navigation = useNavigation<routerProps>();
  const handleHelpCenterNavigate = () => {
    navigation.navigate(routers.HELP_CENTER);
  };
  const handleSecurityCenter = () => {
    navigation.navigate(routers.SECURITY_CENTER);
  };
  const handleSettingButton = () => {
    navigation.navigate(routers.DETAIL_USER_ACCOUNT);
  };
  const handleIntroduceFriends = () => {
    navigation.navigate(routers.INTRODUCE_FRIENDS);
  };
  const data = [
    {
      img: require('assets/images/selection_1-min.png'),
      title: 'Thông tin tài khoản',
      onPress: handleSettingButton,
      sub_title: '',
    },
    {
      img: require('assets/images/selection_2-min.png'),
      title: 'Trung tâm trợ giúp',
      onPress: handleHelpCenterNavigate,
      sub_title: '',
    },
    {
      img: require('assets/images/selection_3-min.png'),
      title: 'Chính sách bảo mật',
      onPress: handleSecurityCenter,
      sub_title: '',
    },
    {
      img: require('assets/images/selection_4-min.png'),
      title: 'Giới thiệu bạn bè',
      sub_title: 'Mời bạn, nhận ưu đãi',
      onPress: handleIntroduceFriends,
    },
  ];
  return (
    <View style={styles.container}>
      {data.map((item, index) => {
        return (
          <MySelectionItem
            key={index}
            onPress={item.onPress}
            img={item.img}
            title={item.title}
            sub_title={item.sub_title}
          />
        );
      })}
    </View>
  );
};

export default MyOtherSelection;
