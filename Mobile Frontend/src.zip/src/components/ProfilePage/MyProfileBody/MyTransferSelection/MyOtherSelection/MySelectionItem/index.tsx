import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './styles';
import {Images} from '@assets/constants/images';

const MySelectionItem = ({
  img,
  title,
  sub_title,
  onPress,
}: {
  img: any;
  title: any;
  sub_title: any;
  onPress: any;
}) => {
  return (
    <TouchableOpacity onPress={onPress} style={styles.container}>
      <View style={styles.iconWrapper}>
        <Image style={styles.icon} source={img} />
      </View>
      <View style={styles.textWrapper}>
        <Text style={styles.text}>{title}</Text>
      </View>
      <View style={styles.moneyWrapper}>
        <Text style={styles.sub_title}>{sub_title}</Text>
      </View>
      <View style={styles.moneyButton}>
        <Image source={Images.CARET_LEFT} style={styles.icon} />
      </View>
    </TouchableOpacity>
  );
};

export default MySelectionItem;
