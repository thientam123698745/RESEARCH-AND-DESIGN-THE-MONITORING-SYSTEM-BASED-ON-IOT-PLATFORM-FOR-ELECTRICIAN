import {View, Text, Image, TouchableOpacity} from 'react-native';
import React from 'react';
import {styles} from './style';
import {Images} from '@assets/constants/images';

const MyWallet = () => {
  const handleVoucher = () => {};
  return (
    <TouchableOpacity onPress={handleVoucher} style={styles.container}>
      <View style={styles.iconWrapper}>
        <Image style={styles.icon} source={Images.WALLET} />
      </View>
      <View style={styles.textWrapper}>
        <Text style={styles.text}>Vi dien tu 365 FDS Pay</Text>
      </View>
      <View style={styles.moneyWrapper}>
        <Text style={styles.moneyText}>đ 300.000.000</Text>
      </View>
      <View style={styles.moneyButton}>
        <Image source={Images.CARET_LEFT} style={styles.icon} />
      </View>
    </TouchableOpacity>
  );
};

export default MyWallet;
