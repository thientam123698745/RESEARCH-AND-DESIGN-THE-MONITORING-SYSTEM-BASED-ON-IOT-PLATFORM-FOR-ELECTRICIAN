import {colors} from '@assets/colors';
import MetricSizes from '@assets/constants/MetricSizes';
import {StyleSheet} from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 3,
    backgroundColor: colors.greyLine,
    borderTopRightRadius: MetricSizes.P_20,
    borderTopLeftRadius: MetricSizes.P_20,
    padding: MetricSizes.P_10,
  },
});
