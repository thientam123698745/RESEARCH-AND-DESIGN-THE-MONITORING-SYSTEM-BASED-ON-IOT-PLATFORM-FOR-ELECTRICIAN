import {View} from 'react-native';
import React from 'react';
import {styles} from './styles';
import MyTransferStatus from './MyTransferStatus';
import MyTransferSelection from './MyTransferSelection';

const MyProfileBody = () => {
  return (
    <View style={styles.container}>
      <MyTransferStatus />
      <MyTransferSelection />
    </View>
  );
};

export default MyProfileBody;
