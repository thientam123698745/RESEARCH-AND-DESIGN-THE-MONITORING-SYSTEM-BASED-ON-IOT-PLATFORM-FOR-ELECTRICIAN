import React from 'react';
import {styles} from './styles';
import MyHeader from './MyHeader';
import MyProfileBody from './MyProfileBody';
import TransStatusBar from '@components/common/StatusBar/TransStatusBar';
import {SafeAreaView} from 'react-native-safe-area-context';
const ProfilePage = () => {
  return (
    <SafeAreaView style={styles.container}>
      <TransStatusBar />
      <MyHeader />
      <MyProfileBody />
    </SafeAreaView>
  );
};

export default ProfilePage;
